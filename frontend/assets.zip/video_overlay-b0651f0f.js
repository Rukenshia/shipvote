import { S as SvelteComponent, i as init, s as safe_not_equal, e as ensure_array_like, a as element, b as space, c as attr, t as toggle_class, d as insert, f as append, l as listen, g as group_outros, h as transition_out, j as check_outros, k as transition_in, m as detach, n as destroy_each, r as run_all, o as component_subscribe, p as api, q as binding_callbacks, u as bind, v as create_component, w as mount_component, x as add_flush_callback, y as add_render_callback, z as create_in_transition, A as create_out_transition, B as destroy_component, C as text, D as set_data, E as noop, F as src_url_equal, G as derived, H as empty, I as onMount, J as onDestroy, K as vote, L as subscribe, M as warships, N as writable, O as set_store_value } from "./app.js";
import { S as ShipFilters, s as slide, P as PubSubHandler, h as handle_promise, u as update_await_block_branch, a as scale } from "./pubsub.js";
import { R as RemainingVoteTime, C as CreatorBanner } from "./RemainingVoteTime.js";
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[13] = list[i][0];
  child_ctx[14] = list[i][1];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[17] = list[i];
  return child_ctx;
}
function create_else_block(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      attr(div, "class", "flex-grow");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1$1(ctx) {
  let div;
  let remainingvotetime;
  let current;
  remainingvotetime = new RemainingVoteTime({
    props: {
      vertical_padding: 1,
      started_at: (
        /*vote*/
        ctx[0].created_at
      ),
      ends_at: (
        /*vote*/
        ctx[0].ends_at
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(remainingvotetime.$$.fragment);
      attr(div, "class", "flex-grow");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(remainingvotetime, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const remainingvotetime_changes = {};
      if (dirty & /*vote*/
      1)
        remainingvotetime_changes.started_at = /*vote*/
        ctx2[0].created_at;
      if (dirty & /*vote*/
      1)
        remainingvotetime_changes.ends_at = /*vote*/
        ctx2[0].ends_at;
      remainingvotetime.$set(remainingvotetime_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(remainingvotetime.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(remainingvotetime.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(remainingvotetime);
    }
  };
}
function create_if_block$1(ctx) {
  let div;
  let shipfilters;
  let updating_filteredShips;
  let div_intro;
  let div_outro;
  let current;
  function shipfilters_filteredShips_binding(value) {
    ctx[10](value);
  }
  let shipfilters_props = { ships: (
    /*votedShips*/
    ctx[5].map(func)
  ) };
  if (
    /*filteredShips*/
    ctx[2] !== void 0
  ) {
    shipfilters_props.filteredShips = /*filteredShips*/
    ctx[2];
  }
  shipfilters = new ShipFilters({ props: shipfilters_props });
  binding_callbacks.push(() => bind(shipfilters, "filteredShips", shipfilters_filteredShips_binding));
  return {
    c() {
      div = element("div");
      create_component(shipfilters.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(shipfilters, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const shipfilters_changes = {};
      if (!updating_filteredShips && dirty & /*filteredShips*/
      4) {
        updating_filteredShips = true;
        shipfilters_changes.filteredShips = /*filteredShips*/
        ctx2[2];
        add_flush_callback(() => updating_filteredShips = false);
      }
      shipfilters.$set(shipfilters_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(shipfilters.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(shipfilters.$$.fragment, local);
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(shipfilters);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_each_block_1(ctx) {
  let button;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let span;
  let t1_value = (
    /*ship*/
    ctx[17].name + ""
  );
  let t1;
  let mounted;
  let dispose;
  function click_handler_2() {
    return (
      /*click_handler_2*/
      ctx[11](
        /*ship*/
        ctx[17]
      )
    );
  }
  return {
    c() {
      button = element("button");
      img = element("img");
      t0 = space();
      span = element("span");
      t1 = text(t1_value);
      attr(img, "class", "h-6 w-auto");
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[17].name);
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[17].image))
        attr(img, "src", img_src_value);
      attr(span, "class", "flex-grow truncate text-xs sm:text-sm");
      attr(button, "class", "flex min-w-min items-end truncate rounded bg-cyan-700 pb-1 pr-2 transition-colors hover:bg-cyan-600");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, img);
      append(button, t0);
      append(button, span);
      append(span, t1);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_2);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*shipsByTier*/
      8 && img_alt_value !== (img_alt_value = /*ship*/
      ctx[17].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*shipsByTier*/
      8 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx[17].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*shipsByTier*/
      8 && t1_value !== (t1_value = /*ship*/
      ctx[17].name + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_each_block$1(ctx) {
  let div;
  let span1;
  let t0;
  let t1_value = romanize(
    /*tier*/
    ctx[13]
  ) + "";
  let t1;
  let t2;
  let span0;
  let t3;
  let t4;
  let each_value_1 = ensure_array_like(
    /*ships*/
    ctx[14]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  return {
    c() {
      div = element("div");
      span1 = element("span");
      t0 = text("Tier ");
      t1 = text(t1_value);
      t2 = space();
      span0 = element("span");
      t3 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t4 = space();
      attr(span0, "class", "flex-grow border-t");
      attr(span1, "class", "col-span-full flex items-center gap-2 text-xs font-bold text-cyan-100");
      attr(div, "class", "grid grid-cols-4 gap-2 sm:grid-cols-4 lg:grid-cols-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span1);
      append(span1, t0);
      append(span1, t1);
      append(span1, t2);
      append(span1, span0);
      append(div, t3);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      append(div, t4);
    },
    p(ctx2, dirty) {
      if (dirty & /*shipsByTier*/
      8 && t1_value !== (t1_value = romanize(
        /*tier*/
        ctx2[13]
      ) + ""))
        set_data(t1, t1_value);
      if (dirty & /*voteForShip, shipsByTier*/
      72) {
        each_value_1 = ensure_array_like(
          /*ships*/
          ctx2[14]
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, t4);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value_1.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let div1;
  let div0;
  let h2;
  let t1;
  let button0;
  let t4;
  let current_block_type_index;
  let if_block0;
  let t5;
  let button1;
  let t6;
  let t7;
  let current;
  let mounted;
  let dispose;
  const if_block_creators = [create_if_block_1$1, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*vote*/
      ctx2[0].ends_at
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  let if_block1 = (
    /*showFilters*/
    ctx[4] && create_if_block$1(ctx)
  );
  let each_value = ensure_array_like(
    /*shipsByTier*/
    ctx[3].entries()
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      h2 = element("h2");
      h2.textContent = "Cast your vote";
      t1 = space();
      button0 = element("button");
      button0.innerHTML = `<svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 01-.659 1.591l-5.432 5.432a2.25 2.25 0 00-.659 1.591v2.927a2.25 2.25 0 01-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 00-.659-1.591L3.659 7.409A2.25 2.25 0 013 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0112 3z"></path></svg> <span class="text-md">Filters</span>`;
      t4 = space();
      if_block0.c();
      t5 = space();
      button1 = element("button");
      button1.innerHTML = `<svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>`;
      t6 = space();
      if (if_block1)
        if_block1.c();
      t7 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(h2, "class", "text-lg font-bold");
      attr(button0, "class", "flex items-center gap-2 rounded bg-cyan-700 px-2 py-0.5 hover:bg-cyan-600");
      toggle_class(
        button0,
        "bg-cyan-600",
        /*showFilters*/
        ctx[4]
      );
      attr(button1, "class", "flex items-center rounded bg-cyan-700 px-2 py-0.5 hover:bg-cyan-600");
      attr(div0, "class", "flex items-center gap-4");
      attr(div1, "class", "flex flex-col gap-4 pr-4");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, h2);
      append(div0, t1);
      append(div0, button0);
      append(div0, t4);
      if_blocks[current_block_type_index].m(div0, null);
      append(div0, t5);
      append(div0, button1);
      append(div1, t6);
      if (if_block1)
        if_block1.m(div1, null);
      append(div1, t7);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            button0,
            "click",
            /*click_handler*/
            ctx[8]
          ),
          listen(
            button1,
            "click",
            /*click_handler_1*/
            ctx[9]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*showFilters*/
      16) {
        toggle_class(
          button0,
          "bg-cyan-600",
          /*showFilters*/
          ctx2[4]
        );
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block0 = if_blocks[current_block_type_index];
        if (!if_block0) {
          if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block0.c();
        } else {
          if_block0.p(ctx2, dirty);
        }
        transition_in(if_block0, 1);
        if_block0.m(div0, t5);
      }
      if (
        /*showFilters*/
        ctx2[4]
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*showFilters*/
          16) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block$1(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div1, t7);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
      if (dirty & /*shipsByTier, voteForShip, romanize*/
      72) {
        each_value = ensure_array_like(
          /*shipsByTier*/
          ctx2[3].entries()
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div1, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if_blocks[current_block_type_index].d();
      if (if_block1)
        if_block1.d();
      destroy_each(each_blocks, detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function romanize(tier) {
  return "I II III IV V VI VII VIII IX X".split(" ")[tier - 1];
}
const func = (vs) => vs.ship;
function instance$2($$self, $$props, $$invalidate) {
  let $api;
  component_subscribe($$self, api, ($$value) => $$invalidate(12, $api = $$value));
  let { vote: vote2 } = $$props;
  let { warships: warships2 } = $$props;
  let { close } = $$props;
  let filteredShips = vote2.ships.map((id) => warships2[`${id}`]).filter((ship) => ship !== void 0);
  let showFilters = false;
  let shipsByTier = /* @__PURE__ */ new Map();
  const votedShips = vote2.ships.map((id) => ({
    ship: warships2[`${id}`],
    votes: vote2.votes[id] || 0
  })).filter((vs) => vs.ship !== void 0);
  async function voteForShip(ship) {
    close();
    await $api.voteForShip(vote2.id, ship.id);
  }
  const click_handler = () => $$invalidate(4, showFilters = !showFilters);
  const click_handler_1 = () => close();
  function shipfilters_filteredShips_binding(value) {
    filteredShips = value;
    $$invalidate(2, filteredShips);
  }
  const click_handler_2 = (ship) => voteForShip(ship);
  $$self.$$set = ($$props2) => {
    if ("vote" in $$props2)
      $$invalidate(0, vote2 = $$props2.vote);
    if ("warships" in $$props2)
      $$invalidate(7, warships2 = $$props2.warships);
    if ("close" in $$props2)
      $$invalidate(1, close = $$props2.close);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*filteredShips, shipsByTier*/
    12) {
      {
        $$invalidate(3, shipsByTier = /* @__PURE__ */ new Map());
        filteredShips.forEach((ship) => {
          if (!shipsByTier.has(ship.tier)) {
            shipsByTier.set(ship.tier, []);
          }
          shipsByTier.get(ship.tier).push(ship);
        });
        $$invalidate(3, shipsByTier = new Map([...shipsByTier.entries()].sort((a, b) => a[0] - b[0])));
      }
    }
  };
  return [
    vote2,
    close,
    filteredShips,
    shipsByTier,
    showFilters,
    votedShips,
    voteForShip,
    warships2,
    click_handler,
    click_handler_1,
    shipfilters_filteredShips_binding,
    click_handler_2
  ];
}
class VoteForShip extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { vote: 0, warships: 7, close: 1 });
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[4] = list[i];
  return child_ctx;
}
function create_each_block(ctx) {
  let div2;
  let img;
  let img_src_value;
  let img_alt_value;
  let t0;
  let div0;
  let t1_value = (
    /*votedShip*/
    ctx[4].ship.name + ""
  );
  let t1;
  let t2;
  let div1;
  let t3_value = (
    /*votedShip*/
    ctx[4].votes + ""
  );
  let t3;
  let t4;
  return {
    c() {
      div2 = element("div");
      img = element("img");
      t0 = space();
      div0 = element("div");
      t1 = text(t1_value);
      t2 = space();
      div1 = element("div");
      t3 = text(t3_value);
      t4 = space();
      if (!src_url_equal(img.src, img_src_value = /*votedShip*/
      ctx[4].ship.image))
        attr(img, "src", img_src_value);
      attr(img, "alt", img_alt_value = /*votedShip*/
      ctx[4].ship.name);
      attr(img, "class", "h-6");
      attr(div0, "class", "flex-grow");
      attr(div1, "class", "text-cyan-200");
      attr(div2, "class", "bg-cyan-900/80 rounded pr-2 py-0.5 text-cyan-100 flex items-center gap-2 text-md");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, img);
      append(div2, t0);
      append(div2, div0);
      append(div0, t1);
      append(div2, t2);
      append(div2, div1);
      append(div1, t3);
      append(div2, t4);
    },
    p(ctx2, dirty) {
      if (dirty & /*$topThreeShips*/
      1 && !src_url_equal(img.src, img_src_value = /*votedShip*/
      ctx2[4].ship.image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$topThreeShips*/
      1 && img_alt_value !== (img_alt_value = /*votedShip*/
      ctx2[4].ship.name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*$topThreeShips*/
      1 && t1_value !== (t1_value = /*votedShip*/
      ctx2[4].ship.name + ""))
        set_data(t1, t1_value);
      if (dirty & /*$topThreeShips*/
      1 && t3_value !== (t3_value = /*votedShip*/
      ctx2[4].votes + ""))
        set_data(t3, t3_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let each_value = ensure_array_like(
    /*$topThreeShips*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "flex flex-col");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*$topThreeShips*/
      1) {
        each_value = ensure_array_like(
          /*$topThreeShips*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let $topThreeShips;
  let { vote: vote2 } = $$props;
  let { warships: warships2 } = $$props;
  let topThreeShips = derived(
    vote2,
    ($vote) => {
      if (!$vote || !$vote.votes) {
        return [];
      }
      return Object.entries($vote.votes).sort(([_, a], [__, b]) => b - a).slice(0, 3).map(([id, votes]) => {
        return { ship: warships2[`${id}`], votes };
      });
    },
    []
  );
  component_subscribe($$self, topThreeShips, (value) => $$invalidate(0, $topThreeShips = value));
  $$self.$$set = ($$props2) => {
    if ("vote" in $$props2)
      $$invalidate(2, vote2 = $$props2.vote);
    if ("warships" in $$props2)
      $$invalidate(3, warships2 = $$props2.warships);
  };
  return [$topThreeShips, topThreeShips, vote2, warships2];
}
class VoteProgressOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { vote: 2, warships: 3 });
  }
}
function create_if_block(ctx) {
  let await_block_anchor;
  let promise;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block,
    then: create_then_block,
    catch: create_catch_block,
    value: 4,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$warships*/
  ctx[4], info);
  return {
    c() {
      await_block_anchor = empty();
      info.block.c();
    },
    m(target, anchor) {
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$warships*/
      16 && promise !== (promise = /*$warships*/
      ctx[4]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(await_block_anchor);
      }
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function create_catch_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_then_block(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$vote*/
    ctx[3] && create_if_block_1(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[3]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$vote*/
    ctx[3].status === "open" && create_if_block_2(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[3].status === "open"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let voteprogressoverlay;
  let t;
  let if_block_anchor;
  let current;
  voteprogressoverlay = new VoteProgressOverlay({
    props: { vote, warships: (
      /*$warships*/
      ctx[4]
    ) }
  });
  let if_block = !/*hidden*/
  ctx[1] && create_if_block_3(ctx);
  return {
    c() {
      div = element("div");
      create_component(voteprogressoverlay.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "class", "fixed");
      toggle_class(
        div,
        "left-0",
        /*$channel*/
        ctx[2].overlay_position.endsWith("left")
      );
      toggle_class(
        div,
        "right-0",
        /*$channel*/
        ctx[2].overlay_position.endsWith("right")
      );
      toggle_class(
        div,
        "top-0",
        /*$channel*/
        ctx[2].overlay_position.startsWith("top")
      );
      toggle_class(
        div,
        "bottom-0",
        /*$channel*/
        ctx[2].overlay_position.startsWith("bottom")
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(voteprogressoverlay, div, null);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const voteprogressoverlay_changes = {};
      if (dirty & /*$warships*/
      16)
        voteprogressoverlay_changes.warships = /*$warships*/
        ctx2[4];
      voteprogressoverlay.$set(voteprogressoverlay_changes);
      if (!current || dirty & /*$channel*/
      4) {
        toggle_class(
          div,
          "left-0",
          /*$channel*/
          ctx2[2].overlay_position.endsWith("left")
        );
      }
      if (!current || dirty & /*$channel*/
      4) {
        toggle_class(
          div,
          "right-0",
          /*$channel*/
          ctx2[2].overlay_position.endsWith("right")
        );
      }
      if (!current || dirty & /*$channel*/
      4) {
        toggle_class(
          div,
          "top-0",
          /*$channel*/
          ctx2[2].overlay_position.startsWith("top")
        );
      }
      if (!current || dirty & /*$channel*/
      4) {
        toggle_class(
          div,
          "bottom-0",
          /*$channel*/
          ctx2[2].overlay_position.startsWith("bottom")
        );
      }
      if (!/*hidden*/
      ctx2[1]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*hidden*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(voteprogressoverlay.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(voteprogressoverlay.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(voteprogressoverlay);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let div5;
  let div4;
  let div2;
  let div1;
  let voteforship;
  let t0;
  let div0;
  let creatorbanner;
  let t1;
  let div3;
  let div5_intro;
  let div5_outro;
  let current;
  voteforship = new VoteForShip({
    props: {
      vote: (
        /*$vote*/
        ctx[3]
      ),
      warships: (
        /*$warships*/
        ctx[4]
      ),
      close: (
        /*func*/
        ctx[5]
      )
    }
  });
  creatorbanner = new CreatorBanner({});
  return {
    c() {
      div5 = element("div");
      div4 = element("div");
      div2 = element("div");
      div1 = element("div");
      create_component(voteforship.$$.fragment);
      t0 = space();
      div0 = element("div");
      create_component(creatorbanner.$$.fragment);
      t1 = space();
      div3 = element("div");
      attr(div0, "class", "mt-4 rounded-lg bg-cyan-950 px-2 py-1 text-xs opacity-50");
      attr(div1, "class", "max-h-64 overflow-y-auto");
      attr(div2, "class", "relative z-20 h-full rounded-xl bg-gradient-to-b from-cyan-800 to-cyan-950 p-4 pt-2 opacity-80 transition-all duration-300 hover:opacity-100");
      attr(div3, "class", "absolute -inset-1 z-10 rounded-md bg-gradient-to-br from-blue-500/50 via-sky-800/60 to-cyan-600/50 blur-md");
      attr(div4, "class", "relative w-full max-w-2xl text-white");
      attr(div5, "class", "flex h-full items-center justify-center overflow-hidden py-16");
    },
    m(target, anchor) {
      insert(target, div5, anchor);
      append(div5, div4);
      append(div4, div2);
      append(div2, div1);
      mount_component(voteforship, div1, null);
      append(div1, t0);
      append(div1, div0);
      mount_component(creatorbanner, div0, null);
      append(div4, t1);
      append(div4, div3);
      current = true;
    },
    p(ctx2, dirty) {
      const voteforship_changes = {};
      if (dirty & /*$vote*/
      8)
        voteforship_changes.vote = /*$vote*/
        ctx2[3];
      if (dirty & /*$warships*/
      16)
        voteforship_changes.warships = /*$warships*/
        ctx2[4];
      if (dirty & /*hidden*/
      2)
        voteforship_changes.close = /*func*/
        ctx2[5];
      voteforship.$set(voteforship_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(voteforship.$$.fragment, local);
      transition_in(creatorbanner.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div5_outro)
            div5_outro.end(1);
          div5_intro = create_in_transition(div5, scale, { duration: 300 });
          div5_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(voteforship.$$.fragment, local);
      transition_out(creatorbanner.$$.fragment, local);
      if (div5_intro)
        div5_intro.invalidate();
      if (local) {
        div5_outro = create_out_transition(div5, scale, { duration: 300 });
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div5);
      }
      destroy_component(voteforship);
      destroy_component(creatorbanner);
      if (detaching && div5_outro)
        div5_outro.end();
    }
  };
}
function create_pending_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_fragment(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$channel*/
    ctx[2] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*$channel*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$channel*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $channel, $$unsubscribe_channel = noop, $$subscribe_channel = () => ($$unsubscribe_channel(), $$unsubscribe_channel = subscribe(channel, ($$value) => $$invalidate(2, $channel = $$value)), channel);
  let $api;
  let $warships;
  let $vote;
  component_subscribe($$self, api, ($$value) => $$invalidate(7, $api = $$value));
  component_subscribe($$self, warships, ($$value) => $$invalidate(4, $warships = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(3, $vote = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_channel());
  let channel = writable();
  $$subscribe_channel();
  let hidden = false;
  let gameIsWows = false;
  const pubSubHandler = new PubSubHandler();
  onMount(() => {
    pubSubHandler.init();
    let loadingChannel = false;
    let hasContext = false;
    api.subscribe(async ($api2) => {
      if (!$api2) {
        return;
      }
      if (loadingChannel) {
        return;
      }
      if (hasContext && !gameIsWows) {
        console.log("game is not wows, not getting channel info");
        return;
      }
      loadingChannel = true;
      console.info("starting shipvote session after api became available");
      $$subscribe_channel($$invalidate(0, channel = await $api2.getChannelInfo()));
    });
    window.Twitch.ext.onContext(async (data, changed) => {
      hasContext = true;
      gameIsWows = data.game === "World of Warships";
      if (data.game !== "World of Warships") {
        return;
      }
      if (!$api) {
        console.error("Game is WoWS, but API is not available");
        return;
      }
      if (!$channel) {
        if (loadingChannel) {
          return;
        }
        loadingChannel = true;
        console.info("Starting Shipvote session");
        set_store_value(channel, $channel = await $api.getChannelInfo(), $channel);
      }
    });
    pubSubHandler.addEventListener("channel_update", (e) => {
      if (e.detail.overlay_position) {
        console.log("channel update. changed overlay position to", e.detail.overlay_position);
        set_store_value(channel, $channel.overlay_position = e.detail.overlay_position, $channel);
      }
    });
    return () => {
    };
  });
  onDestroy(() => {
    pubSubHandler.deinit();
  });
  vote.subscribe(($vote2) => {
    if (!$vote2) {
      $$invalidate(1, hidden = false);
    }
  });
  const func2 = () => $$invalidate(1, hidden = true);
  return [channel, hidden, $channel, $vote, $warships, func2];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
const main = "";
new App({
  target: document.getElementById("app")
});
