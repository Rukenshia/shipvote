var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (Object.prototype.hasOwnProperty.call(b2, p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
}
function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2)
    for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar)
          ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
  return to.concat(ar || Array.prototype.slice.call(from));
}
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
function compose() {
  var funcs = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    funcs[_i] = arguments[_i];
  }
  if (funcs.length === 0) {
    return function(arg) {
      return arg;
    };
  }
  if (funcs.length === 1) {
    return funcs[0];
  }
  return funcs.reduce(function(a, b) {
    return function() {
      var args = [];
      for (var _i2 = 0; _i2 < arguments.length; _i2++) {
        args[_i2] = arguments[_i2];
      }
      return a(b.apply(void 0, __spreadArray([], __read(args), false)));
    };
  });
}
function toHashMapString(obj) {
  if (!obj)
    return;
  Object.keys(obj).forEach(function(k) {
    if (typeof obj[k] === "object") {
      obj[k] = JSON.stringify(obj[k]);
    }
    obj[k] = String(obj[k]);
  });
  return obj;
}
function toHashMap(obj) {
  if (!obj)
    return;
  Object.keys(obj).forEach(function(k) {
    if (typeof obj[k] === "string" || typeof obj[k] === "boolean" || typeof obj[k] === "number") {
      return;
    }
    obj[k] = JSON.stringify(obj[k]);
  });
  return obj;
}
function isError(error) {
  return typeof error === "object" && typeof error.message !== "undefined";
}
function getStacktrace(error) {
  if (typeof error.stacktrace !== "undefined" || typeof error["opera#sourceloc"] !== "undefined") {
    var _a = error.stacktrace, stacktrace = _a === void 0 ? "" : _a;
    return stacktrace.split("\n").filter(function(line) {
      return line !== "";
    });
  } else if (error.stack) {
    var _b = error.stack, stack = _b === void 0 ? "" : _b;
    return stack.split("\n").filter(function(line) {
      return line !== "";
    });
  } else {
    return ["No stacktrace available"];
  }
}
function urlEncode(object) {
  return Object.keys(object).map(function(key) {
    return "".concat(encodeURIComponent(key), "=").concat(encodeURIComponent(object[key]));
  }).join("&");
}
function isNodeEnv() {
  return Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]";
}
function getGlobalObject() {
  return isNodeEnv() ? global : typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : {};
}
function getAugmentedNamespace(n) {
  if (n.__esModule)
    return n;
  var f = n.default;
  if (typeof f == "function") {
    var a = function a2() {
      if (this instanceof a2) {
        return Reflect.construct(f, arguments, this.constructor);
      }
      return f.apply(this, arguments);
    };
    a.prototype = f.prototype;
  } else
    a = {};
  Object.defineProperty(a, "__esModule", { value: true });
  Object.keys(n).forEach(function(k) {
    var d = Object.getOwnPropertyDescriptor(n, k);
    Object.defineProperty(a, k, d.get ? d : {
      enumerable: true,
      get: function() {
        return n[k];
      }
    });
  });
  return a;
}
function unfetch_module(e, n) {
  return n = n || {}, new Promise(function(t, r) {
    var s = new XMLHttpRequest(), o = [], u = [], i = {}, a = function() {
      return { ok: 2 == (s.status / 100 | 0), statusText: s.statusText, status: s.status, url: s.responseURL, text: function() {
        return Promise.resolve(s.responseText);
      }, json: function() {
        return Promise.resolve(s.responseText).then(JSON.parse);
      }, blob: function() {
        return Promise.resolve(new Blob([s.response]));
      }, clone: a, headers: { keys: function() {
        return o;
      }, entries: function() {
        return u;
      }, get: function(e2) {
        return i[e2.toLowerCase()];
      }, has: function(e2) {
        return e2.toLowerCase() in i;
      } } };
    };
    for (var l in s.open(n.method || "get", e, true), s.onload = function() {
      s.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function(e2, n2, t2) {
        o.push(n2 = n2.toLowerCase()), u.push([n2, t2]), i[n2] = i[n2] ? i[n2] + "," + t2 : t2;
      }), t(a());
    }, s.onerror = r, s.withCredentials = "include" == n.credentials, n.headers)
      s.setRequestHeader(l, n.headers[l]);
    s.send(n.body || null);
  });
}
const unfetch_module$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: unfetch_module
}, Symbol.toStringTag, { value: "Module" }));
const require$$0 = /* @__PURE__ */ getAugmentedNamespace(unfetch_module$1);
self.fetch || (self.fetch = require$$0.default || require$$0);
var Serializable = function() {
  function Serializable2(data) {
    this._data = data;
  }
  Serializable2.prototype.toJSON = function() {
    return JSON.stringify(this._data);
  };
  Serializable2.prototype.serialize = function() {
    return this._data;
  };
  return Serializable2;
}();
var VERSION = "1.3.25";
var Environment = function() {
  function Environment2() {
  }
  Environment2.serialize = function() {
    return {
      transport: this.transport(),
      origin: this.origin()
    };
  };
  Environment2.origin = function() {
    var globals = getGlobalObject();
    if (!globals.location) {
      return "";
    }
    return globals.location.origin || "".concat(globals.location.protocol, "//").concat(globals.location.hostname);
  };
  Environment2.transport = function() {
    var globals = getGlobalObject();
    if (isNodeEnv() && typeof jest === "undefined") {
      return "NodeHTTP";
    } else if (globals.XDomainRequest) {
      return "XDomainRequest";
    } else if (globals.XMLHttpRequest && !globals.fetch) {
      return "XMLHttpRequest";
    } else {
      return "fetch";
    }
  };
  Environment2.supportsPromises = function() {
    var globals = getGlobalObject();
    return "Promise" in globals && "resolve" in globals.Promise && "reject" in globals.Promise && "all" in globals.Promise && "race" in globals.Promise && function() {
      var resolve;
      new globals.Promise(function(r) {
        resolve = r;
      });
      return typeof resolve === "function";
    }();
  };
  return Environment2;
}();
var XDomainTransport = function() {
  function XDomainTransport2(url) {
    this.url = url;
  }
  XDomainTransport2.prototype.send = function(data) {
    var _this = this;
    return new Promise(function(resolve, reject) {
      var _a;
      var req = new XDomainRequest();
      var rx = new RegExp("^https?:");
      req.onload = function() {
        return resolve({});
      };
      req.open("POST", _this.url.replace(rx, (_a = window === null || window === void 0 ? void 0 : window.location) === null || _a === void 0 ? void 0 : _a.protocol));
      setTimeout(function() {
        try {
          req.send(data);
        } catch (e) {
          reject(e);
        }
      }, 0);
    });
  };
  return XDomainTransport2;
}();
var XHRTransport = function() {
  function XHRTransport2(url) {
    this.url = url;
  }
  XHRTransport2.prototype.send = function(data) {
    var _this = this;
    return new Promise(function(resolve, reject) {
      try {
        var req_1 = new XMLHttpRequest();
        req_1.onreadystatechange = function() {
          if (req_1.readyState === XMLHttpRequest.DONE) {
            resolve({});
          }
        };
        req_1.open("POST", _this.url);
        req_1.send(data);
      } catch (e) {
        reject(e);
      }
    });
  };
  return XHRTransport2;
}();
var FetchTransport = function() {
  function FetchTransport2(url, headers) {
    this.url = url;
  }
  FetchTransport2.prototype.send = function(data) {
    return __awaiter(this, void 0, void 0, function() {
      var res, statusText, ok;
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, fetch(this.url, {
              method: "POST",
              body: data
            })];
          case 1:
            res = _a.sent();
            statusText = res.statusText, ok = res.ok;
            return [2, ok ? Promise.resolve({}) : Promise.reject({ statusText })];
        }
      });
    });
  };
  return FetchTransport2;
}();
const https = {};
var NodeTransport = function() {
  function NodeTransport2(url) {
    this.url = url;
  }
  NodeTransport2.prototype.send = function(data) {
    var _this = this;
    var options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": data.length
      }
    };
    return new Promise(function(resolve, reject) {
      var req = https.request(_this.url, options, function() {
      }).on("error", function(error) {
        return reject(error);
      });
      req.write(data);
      req.end();
      resolve({});
    });
  };
  return NodeTransport2;
}();
var PushApi = function() {
  function PushApi2(options) {
    this._uri = options.uri || "https://appsignal-endpoint.net/collect";
    this._apiKey = options.key;
    this._clientVersion = options.version;
    this._transport = this._createTransport(this._url());
  }
  PushApi2.prototype.push = function(span) {
    return __awaiter(this, void 0, void 0, function() {
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            return [4, this._transport.send(span.toJSON())];
          case 1:
            _a.sent();
            return [2, span];
        }
      });
    });
  };
  PushApi2.prototype._createTransport = function(url) {
    switch (Environment.transport()) {
      case "XDomainRequest":
        return new XDomainTransport(url);
      case "XMLHttpRequest":
        return new XHRTransport(url);
      case "NodeHTTP":
        return new NodeTransport(url);
      default:
        return new FetchTransport(url);
    }
  };
  PushApi2.prototype._url = function() {
    var auth = this._authorization();
    return "".concat(this._uri, "?").concat(urlEncode(auth));
  };
  PushApi2.prototype._authorization = function() {
    return {
      api_key: this._apiKey,
      version: this._clientVersion
    };
  };
  return PushApi2;
}();
var Span = function(_super) {
  __extends(Span2, _super);
  function Span2(span) {
    return _super.call(this, __assign({ timestamp: Math.round((/* @__PURE__ */ new Date()).getTime() / 1e3), namespace: "frontend", error: {
      name: "NullError",
      message: "No error has been set",
      backtrace: []
    } }, span)) || this;
  }
  Span2.prototype.setAction = function(name) {
    if (!name || typeof name !== "string") {
      return this;
    }
    this._data.action = name;
    return this;
  };
  Span2.prototype.setNamespace = function(name) {
    if (!name || typeof name !== "string") {
      return this;
    }
    this._data.namespace = name;
    return this;
  };
  Span2.prototype.setError = function(error) {
    if (!error || !isError(error))
      return this;
    this._data.error = {
      name: error.name || "[unknown]",
      message: error.message,
      backtrace: getStacktrace(error)
    };
    return this;
  };
  Span2.prototype.setTags = function(tags) {
    this._data.tags = __assign(__assign({}, this._data.tags), toHashMapString(tags));
    return this;
  };
  Span2.prototype.setParams = function(params) {
    this._data.params = __assign(__assign({}, this._data.params), params);
    return this;
  };
  Span2.prototype.setBreadcrumbs = function(breadcrumbs) {
    this._data.breadcrumbs = breadcrumbs;
    return this;
  };
  return Span2;
}(Serializable);
var Queue = function() {
  function Queue2(data) {
    this._data = data || [];
  }
  Queue2.prototype.clear = function() {
    this._data = [];
  };
  Queue2.prototype.values = function() {
    return this._data;
  };
  Queue2.prototype.push = function(item) {
    var _a;
    return Array.isArray(item) ? (_a = this._data).push.apply(_a, __spreadArray([], __read(item), false)) : this._data.push(item);
  };
  Queue2.prototype.drain = function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (!(this._data.length > 0))
            return [3, 2];
          return [4, this._data.shift()];
        case 1:
          _a.sent();
          return [3, 0];
        case 2:
          return [2];
      }
    });
  };
  return Queue2;
}();
var Dispatcher = function() {
  function Dispatcher2(queue, api, options) {
    this._retries = 0;
    this._timerID = 0;
    this._duration = 0;
    this._api = api;
    this._queue = queue;
    this.options = __assign({ limit: 5, initialDuration: 1e3 }, options);
    this.reset();
  }
  Dispatcher2.prototype.schedule = function(time) {
    var _this = this;
    if (time === void 0) {
      time = this._duration;
    }
    var globals = getGlobalObject();
    var BACKOFF_FACTOR = 1.3;
    var cb = function() {
      return __awaiter(_this, void 0, void 0, function() {
        var _a, _b, span, expDuration, e_2_1;
        var e_2, _c;
        return __generator(this, function(_d) {
          switch (_d.label) {
            case 0:
              _d.trys.push([0, 7, 8, 9]);
              _a = __values(this._queue.drain()), _b = _a.next();
              _d.label = 1;
            case 1:
              if (!!_b.done)
                return [3, 6];
              span = _b.value;
              if (!span)
                return [2];
              _d.label = 2;
            case 2:
              _d.trys.push([2, 4, , 5]);
              return [4, this._api.push(span)];
            case 3:
              _d.sent();
              return [3, 5];
            case 4:
              _d.sent();
              expDuration = Math.floor(Math.pow(time, BACKOFF_FACTOR));
              this._retries = this._retries - 1;
              if (this._retries === 0) {
                this.reset();
              } else {
                this._queue.push(span);
                this._timerID = this.schedule(expDuration);
              }
              return [2];
            case 5:
              _b = _a.next();
              return [3, 1];
            case 6:
              return [3, 9];
            case 7:
              e_2_1 = _d.sent();
              e_2 = { error: e_2_1 };
              return [3, 9];
            case 8:
              try {
                if (_b && !_b.done && (_c = _a.return))
                  _c.call(_a);
              } finally {
                if (e_2)
                  throw e_2.error;
              }
              return [7];
            case 9:
              this.reset();
              return [2];
          }
        });
      });
    };
    return globals.setTimeout(cb, time);
  };
  Dispatcher2.prototype.reset = function() {
    var _a = this.options, limit = _a.limit, initialDuration = _a.initialDuration;
    this._retries = limit;
    this._duration = initialDuration;
  };
  return Dispatcher2;
}();
var Appsignal = function() {
  function Appsignal2(options) {
    this.VERSION = VERSION;
    this.ignored = [];
    this._breadcrumbs = [];
    this._hooks = {
      decorators: Array(),
      overrides: Array()
    };
    this._env = Environment.serialize();
    this._queue = new Queue([]);
    var _a = options.key, key = _a === void 0 ? "" : _a, uri = options.uri, revision = options.revision, ignoreErrors = options.ignoreErrors;
    if (revision && typeof revision !== "string") {
      options.revision = String(revision);
    }
    if (key === "") {
      console.info("[APPSIGNAL]: Started in development mode.");
    }
    this._api = new PushApi({
      key,
      uri,
      version: this.VERSION
    });
    if (ignoreErrors && Array.isArray(ignoreErrors)) {
      this.ignored = ignoreErrors;
    }
    this._dispatcher = new Dispatcher(this._queue, this._api);
    this._options = options;
  }
  Appsignal2.prototype.send = function(data, tagsOrFn, namespace) {
    var _this = this;
    if (!(data instanceof Error) && !(data instanceof Span)) {
      console.error("[APPSIGNAL]: Can't send error, given error is not a valid type");
      return;
    }
    if (this.ignored.length !== 0) {
      if (data instanceof Error && this.ignored.some(function(el) {
        return el.test(data.message);
      })) {
        console.warn("[APPSIGNAL]: Ignored an error: ".concat(data.message));
        return;
      }
      if (data instanceof Span) {
        var error_1 = data.serialize().error;
        if (error_1.message && this.ignored.some(function(el) {
          return el.test(error_1.message);
        })) {
          console.warn("[APPSIGNAL]: Ignored a span: ".concat(error_1.message));
          return;
        }
      }
    }
    var span = data instanceof Span ? data : this._createSpanFromError(data);
    if (this._hooks.decorators.length > 0) {
      compose.apply(void 0, __spreadArray([], __read(this._hooks.decorators), false))(span);
    }
    if (tagsOrFn) {
      if (typeof tagsOrFn === "function") {
        var callback = tagsOrFn;
        callback(span);
      } else {
        console.warn("[APPSIGNAL]: DEPRECATED: Calling the `send`/`sendError` function with a tags object is deprecated. Use the callback argument instead.");
        var tags = toHashMap(tagsOrFn) || {};
        span.setTags(tags);
      }
    }
    if (namespace) {
      console.warn("[APPSIGNAL]: DEPRECATED: Calling the `send`/`sendError` function with a namespace is deprecated. Use the callback argument instead.");
      span.setNamespace(namespace);
    }
    if (this._breadcrumbs.length > 0)
      span.setBreadcrumbs(this._breadcrumbs);
    if (this._hooks.overrides.length > 0) {
      compose.apply(void 0, __spreadArray([], __read(this._hooks.overrides), false))(span);
    }
    if (Environment.supportsPromises()) {
      this._breadcrumbs = [];
      if (!this._options.key) {
        console.warn("[APPSIGNAL]: Span not sent because we're in development mode:", span);
        if (data instanceof Error) {
          throw data;
        }
      } else {
        return this._api.push(span).catch(function() {
          _this._queue.push(span);
          setTimeout(function() {
            return _this._dispatcher.schedule();
          }, 0);
        });
      }
    } else {
      console.error("[APPSIGNAL]: Error not sent. A Promise polyfill is required.");
      return;
    }
  };
  Appsignal2.prototype.sendError = function(error, tagsOrFn, namespace) {
    return this.send(error, tagsOrFn, namespace);
  };
  Appsignal2.prototype.use = function(plugin) {
    plugin.call(this);
  };
  Appsignal2.prototype.createSpan = function(fn) {
    var _a = this._options, _b = _a.revision, revision = _b === void 0 ? "" : _b, namespace = _a.namespace;
    var span = new Span({
      environment: this._env,
      revision
    });
    if (namespace)
      span.setNamespace(namespace);
    if (fn && typeof fn === "function")
      fn(span);
    return span;
  };
  Appsignal2.prototype.wrap = function(fn, tagsOrFn, namespace) {
    return __awaiter(this, void 0, void 0, function() {
      var e_1;
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            _a.trys.push([0, 2, , 4]);
            return [4, fn()];
          case 1:
            return [2, _a.sent()];
          case 2:
            e_1 = _a.sent();
            return [4, this.sendError(e_1, tagsOrFn, namespace)];
          case 3:
            _a.sent();
            return [2, Promise.reject(e_1)];
          case 4:
            return [2];
        }
      });
    });
  };
  Appsignal2.prototype.addDecorator = function(decorator) {
    this._hooks.decorators.push(decorator);
  };
  Appsignal2.prototype.addOverride = function(override) {
    this._hooks.overrides.push(override);
  };
  Appsignal2.prototype.demo = function() {
    var span = this._createSpanFromError(new Error("Hello world! This is an error used for demonstration purposes."));
    span.setAction("TestAction").setParams({
      path: "/hello",
      method: "GET"
    }).setTags({
      demo_sample: "true"
    });
    this.send(span);
  };
  Appsignal2.prototype.addBreadcrumb = function(breadcrumb) {
    var crumb = __assign(__assign({ timestamp: Math.round((/* @__PURE__ */ new Date()).getTime() / 1e3) }, breadcrumb), { metadata: toHashMap(breadcrumb.metadata) });
    if (!crumb.category) {
      console.warn("[APPSIGNAL]: Breadcrumb not added. `category` is missing.");
      return;
    }
    if (!crumb.action) {
      console.warn("[APPSIGNAL]: Breadcrumb not added. `action` is missing.");
      return;
    }
    if (this._breadcrumbs.length === 20) {
      this._breadcrumbs.pop();
    }
    this._breadcrumbs.unshift(crumb);
  };
  Appsignal2.prototype._createSpanFromError = function(error) {
    var event = this.createSpan();
    event.setError(error);
    return event;
  };
  return Appsignal2;
}();
new Appsignal({
  key: "9765df9f-9098-4d43-ba8b-8d71c38f066f"
});
