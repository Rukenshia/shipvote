import { S as SvelteComponent, i as init, s as safe_not_equal, e as ensure_array_like, a as element, b as space, c as attr, d as insert, f as append, E as noop, m as detach, n as destroy_each, t as toggle_class, l as listen, C as text, H as empty, D as set_data, k as transition_in, h as transition_out, o as component_subscribe, V as shipsInPreviousVote, K as vote, p as api, P as createEventDispatcher, I as onMount, O as set_store_value, N as writable, g as group_outros, j as check_outros, v as create_component, w as mount_component, B as destroy_component, q as binding_callbacks, u as bind, x as add_flush_callback, F as src_url_equal, W as create_slot, X as update_slot_base, Y as get_all_dirty_from_scope, Z as get_slot_changes, M as warships, L as subscribe, y as add_render_callback, _ as create_bidirectional_transition, $ as svg_element, z as create_in_transition, A as create_out_transition, G as derived, J as onDestroy, Q as set_input_value, r as run_all } from "./app.js";
import { h as handle_promise, u as update_await_block_branch, S as ShipFilters, s as slide, P as PubSubHandler } from "./pubsub.js";
import { B as Box } from "./Box.js";
import { R as RemainingVoteTime, C as CreatorBanner } from "./RemainingVoteTime.js";
import { N as Notification } from "./Notification.js";
function get_each_context$4(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[3] = list[i];
  return child_ctx;
}
function create_else_block$2(ctx) {
  let t0_value = (
    /*option*/
    ctx[3] + ""
  );
  let t0;
  let t1;
  let if_block_anchor;
  let if_block = (
    /*option*/
    ctx[3] > 1 && create_if_block_1$4()
  );
  return {
    c() {
      t0 = text(t0_value);
      t1 = text("\n\n              minute");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*options*/
      2 && t0_value !== (t0_value = /*option*/
      ctx2[3] + ""))
        set_data(t0, t0_value);
      if (
        /*option*/
        ctx2[3] > 1
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_1$4();
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block$7(ctx) {
  let t;
  return {
    c() {
      t = text("None");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1$4(ctx) {
  let t;
  return {
    c() {
      t = text("s");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$4(ctx) {
  let label;
  let input;
  let input_checked_value;
  let input_value_value;
  let input_aria_labelledby_value;
  let t0;
  let p;
  let p_id_value;
  let t1;
  let mounted;
  let dispose;
  function click_handler() {
    return (
      /*click_handler*/
      ctx[2](
        /*option*/
        ctx[3]
      )
    );
  }
  function select_block_type(ctx2, dirty) {
    if (!/*option*/
    ctx2[3])
      return create_if_block$7;
    return create_else_block$2;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      label = element("label");
      input = element("input");
      t0 = space();
      p = element("p");
      if_block.c();
      t1 = space();
      input.checked = input_checked_value = /*selected*/
      ctx[0] === /*option*/
      ctx[3];
      attr(input, "type", "radio");
      attr(input, "name", "duration");
      input.value = input_value_value = /*option*/
      ctx[3];
      attr(input, "class", "sr-only");
      attr(input, "aria-labelledby", input_aria_labelledby_value = "duration-" + /*option*/
      ctx[3] + "-label");
      attr(p, "id", p_id_value = "duration-" + /*option*/
      ctx[3] + "-label");
      attr(label, "class", "flex cursor-pointer items-center justify-center rounded-md border border-cyan-400 px-3 py-3 text-sm font-medium text-gray-50 transition hover:bg-cyan-500 hover:text-gray-900 focus:outline-none active:ring-2 active:ring-gray-500 active:ring-offset-2 sm:flex-1");
      toggle_class(
        label,
        "bg-cyan-700",
        /*selected*/
        ctx[0] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "border-transparent",
        /*selected*/
        ctx[0] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "text-white",
        /*selected*/
        ctx[0] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "hover:text-white",
        /*selected*/
        ctx[0] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "hover:bg-cyan-700",
        /*selected*/
        ctx[0] === /*option*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, input);
      append(label, t0);
      append(label, p);
      if_block.m(p, null);
      append(label, t1);
      if (!mounted) {
        dispose = listen(input, "click", click_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*selected, options*/
      3 && input_checked_value !== (input_checked_value = /*selected*/
      ctx[0] === /*option*/
      ctx[3])) {
        input.checked = input_checked_value;
      }
      if (dirty & /*options*/
      2 && input_value_value !== (input_value_value = /*option*/
      ctx[3])) {
        input.value = input_value_value;
      }
      if (dirty & /*options*/
      2 && input_aria_labelledby_value !== (input_aria_labelledby_value = "duration-" + /*option*/
      ctx[3] + "-label")) {
        attr(input, "aria-labelledby", input_aria_labelledby_value);
      }
      if (current_block_type === (current_block_type = select_block_type(ctx)) && if_block) {
        if_block.p(ctx, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx);
        if (if_block) {
          if_block.c();
          if_block.m(p, null);
        }
      }
      if (dirty & /*options*/
      2 && p_id_value !== (p_id_value = "duration-" + /*option*/
      ctx[3] + "-label")) {
        attr(p, "id", p_id_value);
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "bg-cyan-700",
          /*selected*/
          ctx[0] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "border-transparent",
          /*selected*/
          ctx[0] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "text-white",
          /*selected*/
          ctx[0] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "hover:text-white",
          /*selected*/
          ctx[0] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "hover:bg-cyan-700",
          /*selected*/
          ctx[0] === /*option*/
          ctx[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(label);
      }
      if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$8(ctx) {
  let div2;
  let div0;
  let t1;
  let fieldset;
  let legend;
  let t3;
  let div1;
  let each_value = ensure_array_like(
    /*options*/
    ctx[1]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$4(get_each_context$4(ctx, each_value, i));
  }
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      div0.innerHTML = `<h2 class="text-sm font-medium text-gray-300">Time Limit</h2>`;
      t1 = space();
      fieldset = element("fieldset");
      legend = element("legend");
      legend.textContent = "Choose a memory option";
      t3 = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div0, "class", "flex items-center justify-between");
      attr(legend, "class", "sr-only");
      attr(div1, "class", "grid grid-cols-3 gap-3 sm:grid-cols-6");
      attr(fieldset, "class", "mt-2");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div2, t1);
      append(div2, fieldset);
      append(fieldset, legend);
      append(fieldset, t3);
      append(fieldset, div1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*selected, options*/
      3) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[1]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$4(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$4(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div1, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$8($$self, $$props, $$invalidate) {
  let { options = [null, 1, 5, 15, 20, 30] } = $$props;
  let { selected = null } = $$props;
  const click_handler = (option) => $$invalidate(0, selected = option);
  $$self.$$set = ($$props2) => {
    if ("options" in $$props2)
      $$invalidate(1, options = $$props2.options);
    if ("selected" in $$props2)
      $$invalidate(0, selected = $$props2.selected);
  };
  return [selected, options, click_handler];
}
class Duration extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$8, safe_not_equal, { options: 1, selected: 0 });
  }
}
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[26] = list[i];
  return child_ctx;
}
function create_catch_block_1(ctx) {
  let t;
  return {
    c() {
      t = text("could not load channel information");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_then_block$3(ctx) {
  let await_block_anchor;
  let promise;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block_1,
    then: create_then_block_1,
    catch: create_catch_block$3,
    value: 25,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$vote*/
  ctx[3], info);
  return {
    c() {
      await_block_anchor = empty();
      info.block.c();
    },
    m(target, anchor) {
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$vote*/
      8 && promise !== (promise = /*$vote*/
      ctx[3]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(await_block_anchor);
      }
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function create_catch_block$3(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_then_block_1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block$6, create_else_block$1];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*vote*/
      ctx2[25]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block$1(ctx) {
  let box0;
  let t0;
  let box1;
  let t1;
  let div0;
  let t2;
  let button;
  let t3;
  let button_class_value;
  let button_disabled_value;
  let t4;
  let div1;
  let current;
  let mounted;
  let dispose;
  box0 = new Box({
    props: {
      $$slots: { default: [create_default_slot_3$1] },
      $$scope: { ctx }
    }
  });
  box1 = new Box({
    props: {
      $$slots: { default: [create_default_slot_2$1] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*filteredShips*/
    ctx[0].length && create_if_block_2$3(ctx)
  );
  let each_value = ensure_array_like(
    /*filteredShips*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      create_component(box0.$$.fragment);
      t0 = space();
      create_component(box1.$$.fragment);
      t1 = space();
      div0 = element("div");
      if (if_block)
        if_block.c();
      t2 = space();
      button = element("button");
      t3 = text("Remove all");
      t4 = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(button, "class", button_class_value = "rounded-md bg-zinc-700 px-4 py-2 text-gray-300 " + /*$selectedShips*/
      (ctx[2].length ? "hover:bg-cyan-500 hover:text-gray-100" : "") + " font-medium transition");
      button.disabled = button_disabled_value = !/*$selectedShips*/
      ctx[2].length;
      toggle_class(button, "text-gray-500", !/*$selectedShips*/
      ctx[2].length);
      toggle_class(button, "bg-transparent", !/*$selectedShips*/
      ctx[2].length);
      attr(div0, "class", "sticky bottom-0 flex justify-between");
      attr(div1, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      mount_component(box0, target, anchor);
      insert(target, t0, anchor);
      mount_component(box1, target, anchor);
      insert(target, t1, anchor);
      insert(target, div0, anchor);
      if (if_block)
        if_block.m(div0, null);
      append(div0, t2);
      append(div0, button);
      append(button, t3);
      insert(target, t4, anchor);
      insert(target, div1, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_3*/
          ctx[19]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const box0_changes = {};
      if (dirty & /*$$scope, $selectedShips, duration*/
      536870918) {
        box0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box0.$set(box0_changes);
      const box1_changes = {};
      if (dirty & /*$$scope, $channel, filteredShips*/
      536870929) {
        box1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box1.$set(box1_changes);
      if (
        /*filteredShips*/
        ctx2[0].length
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_2$3(ctx2);
          if_block.c();
          if_block.m(div0, t2);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_class_value !== (button_class_value = "rounded-md bg-zinc-700 px-4 py-2 text-gray-300 " + /*$selectedShips*/
      (ctx2[2].length ? "hover:bg-cyan-500 hover:text-gray-100" : "") + " font-medium transition")) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_disabled_value !== (button_disabled_value = !/*$selectedShips*/
      ctx2[2].length)) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "text-gray-500", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "bg-transparent", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (dirty & /*removeShip, filteredShips, $selectedShips, addShip*/
      773) {
        each_value = ensure_array_like(
          /*filteredShips*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$3(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$3(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div1, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(box0.$$.fragment, local);
      transition_in(box1.$$.fragment, local);
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(box0.$$.fragment, local);
      transition_out(box1.$$.fragment, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(div0);
        detach(t4);
        detach(div1);
      }
      destroy_component(box0, detaching);
      destroy_component(box1, detaching);
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block$6(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope*/
      536870912) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_if_block_4$2(ctx) {
  let t;
  return {
    c() {
      t = text("s");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_3$1(ctx) {
  let h2;
  let t1;
  let div0;
  let duration_1;
  let updating_selected;
  let t2;
  let div1;
  let button;
  let t3;
  let t4_value = (
    /*$selectedShips*/
    ctx[2].length + ""
  );
  let t4;
  let t5;
  let button_class_value;
  let button_disabled_value;
  let current;
  let mounted;
  let dispose;
  function duration_1_selected_binding(value) {
    ctx[15](value);
  }
  let duration_1_props = {};
  if (
    /*duration*/
    ctx[1] !== void 0
  ) {
    duration_1_props.selected = /*duration*/
    ctx[1];
  }
  duration_1 = new Duration({ props: duration_1_props });
  binding_callbacks.push(() => bind(duration_1, "selected", duration_1_selected_binding));
  let if_block = (
    /*$selectedShips*/
    ctx[2].length !== 1 && create_if_block_4$2()
  );
  return {
    c() {
      h2 = element("h2");
      h2.textContent = "New Vote";
      t1 = space();
      div0 = element("div");
      create_component(duration_1.$$.fragment);
      t2 = space();
      div1 = element("div");
      button = element("button");
      t3 = text("Start vote with ");
      t4 = text(t4_value);
      t5 = text(" ship");
      if (if_block)
        if_block.c();
      attr(h2, "class", "text-xl font-medium text-gray-200");
      attr(div0, "class", "p-4");
      attr(button, "class", button_class_value = "rounded-md px-8 py-4 " + /*$selectedShips*/
      (ctx[2].length ? "hover:bg-cyan-400 active:bg-cyan-600 active:ring-2 active:ring-cyan-400" : "text-cyan-200/50") + " font-medium transition");
      button.disabled = button_disabled_value = !/*$selectedShips*/
      ctx[2].length;
      toggle_class(
        button,
        "text-gray-800",
        /*$selectedShips*/
        ctx[2].length
      );
      toggle_class(button, "bg-cyan-900", !/*$selectedShips*/
      ctx[2].length);
      toggle_class(
        button,
        "bg-cyan-500",
        /*$selectedShips*/
        ctx[2].length
      );
      attr(div1, "class", "mt-8 flex items-center justify-around");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      insert(target, t1, anchor);
      insert(target, div0, anchor);
      mount_component(duration_1, div0, null);
      insert(target, t2, anchor);
      insert(target, div1, anchor);
      append(div1, button);
      append(button, t3);
      append(button, t4);
      append(button, t5);
      if (if_block)
        if_block.m(button, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_1*/
          ctx[16]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const duration_1_changes = {};
      if (!updating_selected && dirty & /*duration*/
      2) {
        updating_selected = true;
        duration_1_changes.selected = /*duration*/
        ctx2[1];
        add_flush_callback(() => updating_selected = false);
      }
      duration_1.$set(duration_1_changes);
      if ((!current || dirty & /*$selectedShips*/
      4) && t4_value !== (t4_value = /*$selectedShips*/
      ctx2[2].length + ""))
        set_data(t4, t4_value);
      if (
        /*$selectedShips*/
        ctx2[2].length !== 1
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_4$2();
          if_block.c();
          if_block.m(button, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_class_value !== (button_class_value = "rounded-md px-8 py-4 " + /*$selectedShips*/
      (ctx2[2].length ? "hover:bg-cyan-400 active:bg-cyan-600 active:ring-2 active:ring-cyan-400" : "text-cyan-200/50") + " font-medium transition")) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_disabled_value !== (button_disabled_value = !/*$selectedShips*/
      ctx2[2].length)) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(
          button,
          "text-gray-800",
          /*$selectedShips*/
          ctx2[2].length
        );
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "bg-cyan-900", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(
          button,
          "bg-cyan-500",
          /*$selectedShips*/
          ctx2[2].length
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(duration_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(duration_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t1);
        detach(div0);
        detach(t2);
        detach(div1);
      }
      destroy_component(duration_1);
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot_2$1(ctx) {
  let shipfilters;
  let updating_filteredShips;
  let current;
  function shipfilters_filteredShips_binding(value) {
    ctx[17](value);
  }
  let shipfilters_props = { ships: (
    /*channel*/
    ctx[12].ships
  ) };
  if (
    /*filteredShips*/
    ctx[0] !== void 0
  ) {
    shipfilters_props.filteredShips = /*filteredShips*/
    ctx[0];
  }
  shipfilters = new ShipFilters({ props: shipfilters_props });
  binding_callbacks.push(() => bind(shipfilters, "filteredShips", shipfilters_filteredShips_binding));
  return {
    c() {
      create_component(shipfilters.$$.fragment);
    },
    m(target, anchor) {
      mount_component(shipfilters, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const shipfilters_changes = {};
      if (dirty & /*$channel*/
      16)
        shipfilters_changes.ships = /*channel*/
        ctx2[12].ships;
      if (!updating_filteredShips && dirty & /*filteredShips*/
      1) {
        updating_filteredShips = true;
        shipfilters_changes.filteredShips = /*filteredShips*/
        ctx2[0];
        add_flush_callback(() => updating_filteredShips = false);
      }
      shipfilters.$set(shipfilters_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(shipfilters.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(shipfilters.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(shipfilters, detaching);
    }
  };
}
function create_if_block_2$3(ctx) {
  let button;
  let mounted;
  let dispose;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*filteredShips*/
      ctx2[0].length === 1
    )
      return create_if_block_3$3;
    return create_else_block_2$1;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      button = element("button");
      if_block.c();
      attr(button, "class", "rounded-md bg-cyan-800/50 px-4 py-2 font-medium text-gray-200 transition hover:bg-cyan-700 hover:text-gray-100");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if_block.m(button, null);
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_2*/
          ctx[18]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_1(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(button, null);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_else_block_2$1(ctx) {
  let t0;
  let t1_value = (
    /*filteredShips*/
    ctx[0].length + ""
  );
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Add ");
      t1 = text(t1_value);
      t2 = text(" Ships");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*filteredShips*/
      ctx2[0].length + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_if_block_3$3(ctx) {
  let t0;
  let t1_value = (
    /*filteredShips*/
    ctx[0][0].name + ""
  );
  let t1;
  return {
    c() {
      t0 = text("Add ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*filteredShips*/
      ctx2[0][0].name + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_else_block_1$1(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_5() {
    return (
      /*click_handler_5*/
      ctx[21](
        /*ship*/
        ctx[26]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.textContent = "+";
      attr(button, "class", "rounded bg-cyan-900 px-4 py-2 font-medium drop-shadow-sm transition hover:bg-cyan-700");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_5);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_1$3(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_4() {
    return (
      /*click_handler_4*/
      ctx[20](
        /*ship*/
        ctx[26]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.textContent = "-";
      attr(button, "class", "rounded bg-cyan-900 px-4 py-2 font-medium drop-shadow-sm transition hover:bg-cyan-700");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_4);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot_1$1(ctx) {
  let div;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let span;
  let t1_value = (
    /*ship*/
    ctx[26].name + ""
  );
  let t1;
  let t2;
  let show_if;
  let t3;
  function func(...args) {
    return (
      /*func*/
      ctx[13](
        /*ship*/
        ctx[26],
        ...args
      )
    );
  }
  function select_block_type_2(ctx2, dirty) {
    if (dirty & /*$selectedShips, filteredShips*/
    5)
      show_if = null;
    if (show_if == null)
      show_if = !!/*$selectedShips*/
      ctx2[2].find(func);
    if (show_if)
      return create_if_block_1$3;
    return create_else_block_1$1;
  }
  let current_block_type = select_block_type_2(ctx, -1);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span = element("span");
      t1 = text(t1_value);
      t2 = space();
      if_block.c();
      t3 = space();
      attr(img, "class", "h-10 w-16");
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[26].name);
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[26].image))
        attr(img, "src", img_src_value);
      attr(span, "class", "flex-grow text-lg");
      attr(div, "class", "flex items-center gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span);
      append(span, t1);
      append(div, t2);
      if_block.m(div, null);
      insert(target, t3, anchor);
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*filteredShips*/
      1 && img_alt_value !== (img_alt_value = /*ship*/
      ctx[26].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*filteredShips*/
      1 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx[26].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*ship*/
      ctx[26].name + ""))
        set_data(t1, t1_value);
      if (current_block_type === (current_block_type = select_block_type_2(ctx, dirty)) && if_block) {
        if_block.p(ctx, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx);
        if (if_block) {
          if_block.c();
          if_block.m(div, null);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t3);
      }
      if_block.d();
    }
  };
}
function create_each_block$3(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope, filteredShips, $selectedShips*/
      536870917) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_default_slot$4(ctx) {
  let t;
  return {
    c() {
      t = text("There is already an open vote");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_pending_block_1(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_pending_block$3(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "loading...";
      attr(div, "class", "text-gray-500");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$7(ctx) {
  let div1;
  let div0;
  let a;
  let t1;
  let promise;
  let current;
  let mounted;
  let dispose;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: true,
    pending: create_pending_block$3,
    then: create_then_block$3,
    catch: create_catch_block_1,
    value: 12,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$channel*/
  ctx[4], info);
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      a = element("a");
      a.innerHTML = `<svg class="mt-0.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
      Go back`;
      t1 = space();
      info.block.c();
      attr(a, "class", "inline-flex items-center gap-2 rounded p-4 font-medium text-gray-300 transition hover:bg-gray-800 hover:drop-shadow-xl");
      attr(a, "href", "#live_config");
      attr(div1, "class", "flex flex-col gap-8");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, a);
      append(div1, t1);
      info.block.m(div1, info.anchor = null);
      info.mount = () => div1;
      info.anchor = null;
      current = true;
      if (!mounted) {
        dispose = listen(
          a,
          "click",
          /*click_handler*/
          ctx[14]
        );
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$channel*/
      16 && promise !== (promise = /*$channel*/
      ctx[4]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      info.block.d();
      info.token = null;
      info = null;
      mounted = false;
      dispose();
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let $selectedShips;
  let $shipsInPreviousVote;
  let $vote;
  let $api;
  let $channel;
  component_subscribe($$self, shipsInPreviousVote, ($$value) => $$invalidate(22, $shipsInPreviousVote = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(3, $vote = $$value));
  component_subscribe($$self, api, ($$value) => $$invalidate(23, $api = $$value));
  const dispatch = createEventDispatcher();
  const channel = writable();
  component_subscribe($$self, channel, (value) => $$invalidate(4, $channel = value));
  api.subscribe(($api2) => {
    if (!$api2) {
      return;
    }
    channel.set($api2.broadcasterGetChannel());
  });
  let selectedShips = writable();
  component_subscribe($$self, selectedShips, (value) => $$invalidate(2, $selectedShips = value));
  let filteredShips = [];
  let duration;
  function addShips(ships) {
    set_store_value(selectedShips, $selectedShips = [...$selectedShips, ...ships.filter((s) => !$selectedShips.includes(s))], $selectedShips);
  }
  function addShip(ship) {
    if ($selectedShips.includes(ship)) {
      return;
    }
    set_store_value(selectedShips, $selectedShips = [...$selectedShips, ship], $selectedShips);
  }
  function removeShip(ship) {
    set_store_value(selectedShips, $selectedShips = $selectedShips.filter((s) => s !== ship), $selectedShips);
  }
  function removeAllShips() {
    set_store_value(selectedShips, $selectedShips = [], $selectedShips);
  }
  async function openVote() {
    shipsInPreviousVote.set($selectedShips.map((s) => s.id));
    set_store_value(vote, $vote = await $api.openVote($selectedShips.map((s) => s.id), duration), $vote);
    dispatch("vote_opened");
  }
  onMount(async () => {
    channel.subscribe(async ($channel2) => {
      if (!$channel2) {
        return;
      }
      set_store_value(selectedShips, $selectedShips = (await $channel2).ships.filter((s) => $shipsInPreviousVote.find((previousShipId) => previousShipId === s.id)), $selectedShips);
    });
    set_store_value(selectedShips, $selectedShips = [], $selectedShips);
  });
  const func = (ship, s) => s.id === ship.id;
  const click_handler = () => dispatch("back");
  function duration_1_selected_binding(value) {
    duration = value;
    $$invalidate(1, duration);
  }
  const click_handler_1 = () => openVote();
  function shipfilters_filteredShips_binding(value) {
    filteredShips = value;
    $$invalidate(0, filteredShips);
  }
  const click_handler_2 = () => addShips(filteredShips);
  const click_handler_3 = () => removeAllShips();
  const click_handler_4 = (ship) => removeShip(ship);
  const click_handler_5 = (ship) => addShip(ship);
  return [
    filteredShips,
    duration,
    $selectedShips,
    $vote,
    $channel,
    dispatch,
    selectedShips,
    addShips,
    addShip,
    removeShip,
    removeAllShips,
    openVote,
    channel,
    func,
    click_handler,
    duration_1_selected_binding,
    click_handler_1,
    shipfilters_filteredShips_binding,
    click_handler_2,
    click_handler_3,
    click_handler_4,
    click_handler_5
  ];
}
class NewVote extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, {});
  }
}
function get_each_context$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  child_ctx[7] = i;
  return child_ctx;
}
const get_title_slot_changes$2 = (dirty) => ({});
const get_title_slot_context$2 = (ctx) => ({});
function fallback_block$2(ctx) {
  let t;
  return {
    c() {
      t = text("Results");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_catch_block$2(ctx) {
  return { c: noop, m: noop, p: noop, d: noop };
}
function create_then_block$2(ctx) {
  let t;
  let each_1_anchor;
  let if_block = (
    /*ships*/
    ctx[1].length === 0 && create_if_block$5()
  );
  let each_value = ensure_array_like(
    /*ships*/
    ctx[1]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (
        /*ships*/
        ctx2[1].length === 0
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block$5();
          if_block.c();
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*$ships*/
      1) {
        each_value = ensure_array_like(
          /*ships*/
          ctx2[1]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$2(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$2(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(each_1_anchor);
      }
      if (if_block)
        if_block.d(detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block$5(ctx) {
  let li;
  return {
    c() {
      li = element("li");
      li.innerHTML = `<div class="flex h-10 items-center text-center">No voted ships</div>`;
      attr(li, "class", "my-2 flex items-center justify-around gap-4 rounded bg-gray-700 p-2 drop-shadow-md transition hover:bg-gray-600");
    },
    m(target, anchor) {
      insert(target, li, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_each_block$2(ctx) {
  let li;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t3;
  let span1;
  let t4_value = (
    /*ship*/
    ctx[5].name + ""
  );
  let t4;
  let t5;
  let span2;
  let t6_value = (
    /*ship*/
    ctx[5].votes + ""
  );
  let t6;
  let t7;
  return {
    c() {
      li = element("li");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = `${/*rank*/
      ctx[7] + 1}.`;
      t3 = space();
      span1 = element("span");
      t4 = text(t4_value);
      t5 = space();
      span2 = element("span");
      t6 = text(t6_value);
      t7 = space();
      attr(img, "alt", "ship");
      attr(img, "class", "h-10 w-16");
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[5].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-lg font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-lg");
      attr(span2, "class", "pr-4 font-medium");
      attr(li, "class", "my-2 flex items-center justify-around gap-4 rounded bg-gray-700 p-2 drop-shadow-md transition hover:bg-gray-600");
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, img);
      append(li, t0);
      append(li, span0);
      append(li, t3);
      append(li, span1);
      append(span1, t4);
      append(li, t5);
      append(li, span2);
      append(span2, t6);
      append(li, t7);
    },
    p(ctx2, dirty) {
      if (dirty & /*$ships*/
      1 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx2[5].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$ships*/
      1 && t4_value !== (t4_value = /*ship*/
      ctx2[5].name + ""))
        set_data(t4, t4_value);
      if (dirty & /*$ships*/
      1 && t6_value !== (t6_value = /*ship*/
      ctx2[5].votes + ""))
        set_data(t6, t6_value);
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_pending_block$2(ctx) {
  let li;
  return {
    c() {
      li = element("li");
      li.innerHTML = `<div class="h-10"></div>`;
      attr(li, "class", "my-2 flex items-center justify-around gap-4 rounded bg-gray-700 p-2 drop-shadow-md transition hover:bg-gray-600");
    },
    m(target, anchor) {
      insert(target, li, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_fragment$6(ctx) {
  let h2;
  let t;
  let ul;
  let promise;
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[4].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[3],
    get_title_slot_context$2
  );
  const title_slot_or_fallback = title_slot || fallback_block$2();
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block$2,
    then: create_then_block$2,
    catch: create_catch_block$2,
    value: 1
  };
  handle_promise(promise = /*$ships*/
  ctx[0], info);
  return {
    c() {
      h2 = element("h2");
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
      t = space();
      ul = element("ul");
      info.block.c();
      attr(h2, "class", "mt-2 text-xl");
      attr(ul, "class", "px-4");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(h2, null);
      }
      insert(target, t, anchor);
      insert(target, ul, anchor);
      info.block.m(ul, info.anchor = null);
      info.mount = () => ul;
      info.anchor = null;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        8)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx,
            /*$$scope*/
            ctx[3],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[3]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx[3],
              dirty,
              get_title_slot_changes$2
            ),
            get_title_slot_context$2
          );
        }
      }
      info.ctx = ctx;
      if (dirty & /*$ships*/
      1 && promise !== (promise = /*$ships*/
      ctx[0]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t);
        detach(ul);
      }
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
      info.block.d();
      info.token = null;
      info = null;
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let $ships;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { votes } = $$props;
  const ships = writable([]);
  component_subscribe($$self, ships, (value) => $$invalidate(0, $ships = value));
  $$self.$$set = ($$props2) => {
    if ("votes" in $$props2)
      $$invalidate(2, votes = $$props2.votes);
    if ("$$scope" in $$props2)
      $$invalidate(3, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*votes*/
    4) {
      {
        warships.subscribe(async ($warships) => {
          if (!$warships) {
            return;
          }
          const currentWarships = await $warships;
          ships.set(Object.entries(votes).map(([key, value]) => {
            return { ...currentWarships[key], votes: value };
          }).sort((a, b) => a.votes > b.votes ? -1 : a.votes === b.votes ? 0 : 1).slice(0, 4));
        });
      }
    }
  };
  return [$ships, ships, votes, $$scope, slots];
}
class VoteResults extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, { votes: 2 });
  }
}
function create_if_block$4(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope, $vote*/
      65) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_if_block_2$2(ctx) {
  let div;
  let button;
  let t0;
  let button_disabled_value;
  let t1;
  let current;
  let mounted;
  let dispose;
  let if_block = vote.ends_at && create_if_block_3$2(ctx);
  return {
    c() {
      div = element("div");
      button = element("button");
      t0 = text("Close vote");
      t1 = space();
      if (if_block)
        if_block.c();
      attr(button, "class", "rounded-md px-8 py-4 font-medium transition active:bg-cyan-600 active:ring-2 active:ring-cyan-400");
      button.disabled = button_disabled_value = /*$vote*/
      ctx[0] === void 0;
      toggle_class(
        button,
        "text-gray-800",
        /*$vote*/
        ctx[0] !== void 0
      );
      toggle_class(
        button,
        "text-gray-200",
        /*$vote*/
        ctx[0] === void 0
      );
      toggle_class(
        button,
        "bg-gray-700",
        /*$vote*/
        ctx[0] === void 0
      );
      toggle_class(
        button,
        "bg-cyan-500",
        /*$vote*/
        ctx[0] !== void 0
      );
      toggle_class(
        button,
        "hover:bg-cyan-400",
        /*$vote*/
        ctx[0] !== void 0
      );
      attr(div, "class", "mt-2 flex flex-col justify-around gap-2 px-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, button);
      append(button, t0);
      append(div, t1);
      if (if_block)
        if_block.m(div, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[2]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*$vote*/
      1 && button_disabled_value !== (button_disabled_value = /*$vote*/
      ctx2[0] === void 0)) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "text-gray-800",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
      if (!current || dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "text-gray-200",
          /*$vote*/
          ctx2[0] === void 0
        );
      }
      if (!current || dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "bg-gray-700",
          /*$vote*/
          ctx2[0] === void 0
        );
      }
      if (!current || dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "bg-cyan-500",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
      if (!current || dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "hover:bg-cyan-400",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
      if (vote.ends_at)
        if_block.p(ctx2, dirty);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_3$2(ctx) {
  let remainingvotetime;
  let current;
  remainingvotetime = new RemainingVoteTime({
    props: {
      started_at: (
        /*$vote*/
        ctx[0].created_at
      ),
      ends_at: (
        /*$vote*/
        ctx[0].ends_at
      )
    }
  });
  return {
    c() {
      create_component(remainingvotetime.$$.fragment);
    },
    m(target, anchor) {
      mount_component(remainingvotetime, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const remainingvotetime_changes = {};
      if (dirty & /*$vote*/
      1)
        remainingvotetime_changes.started_at = /*$vote*/
        ctx2[0].created_at;
      if (dirty & /*$vote*/
      1)
        remainingvotetime_changes.ends_at = /*$vote*/
        ctx2[0].ends_at;
      remainingvotetime.$set(remainingvotetime_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(remainingvotetime.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(remainingvotetime.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(remainingvotetime, detaching);
    }
  };
}
function create_if_block_1$2(ctx) {
  let voteresults;
  let current;
  voteresults = new VoteResults({ props: { votes: (
    /*$vote*/
    ctx[0].votes
  ) } });
  return {
    c() {
      create_component(voteresults.$$.fragment);
    },
    m(target, anchor) {
      mount_component(voteresults, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const voteresults_changes = {};
      if (dirty & /*$vote*/
      1)
        voteresults_changes.votes = /*$vote*/
        ctx2[0].votes;
      voteresults.$set(voteresults_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(voteresults.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(voteresults.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(voteresults, detaching);
    }
  };
}
function create_default_slot$3(ctx) {
  let t0;
  let span;
  let t2;
  let t3;
  let div;
  let current;
  let if_block0 = (
    /*$vote*/
    ctx[0] && /*$vote*/
    ctx[0].status === "open" && create_if_block_2$2(ctx)
  );
  let if_block1 = (
    /*$vote*/
    ctx[0] && /*$vote*/
    ctx[0].status === "open" && create_if_block_1$2(ctx)
  );
  return {
    c() {
      t0 = text("The vote is currently\n\n    ");
      span = element("span");
      span.textContent = "open";
      t2 = space();
      if (if_block0)
        if_block0.c();
      t3 = space();
      div = element("div");
      if (if_block1)
        if_block1.c();
      attr(span, "class", "font-medium");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, span, anchor);
      insert(target, t2, anchor);
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t3, anchor);
      insert(target, div, anchor);
      if (if_block1)
        if_block1.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[0] && /*$vote*/
        ctx2[0].status === "open"
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*$vote*/
          1) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_2$2(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t3.parentNode, t3);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*$vote*/
        ctx2[0] && /*$vote*/
        ctx2[0].status === "open"
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*$vote*/
          1) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1$2(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(div, null);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(span);
        detach(t2);
        detach(t3);
        detach(div);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d();
    }
  };
}
function create_fragment$5(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$vote*/
    ctx[0] && /*$vote*/
    ctx[0].status === "open" && create_if_block$4(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*$vote*/
        ctx2[0] && /*$vote*/
        ctx2[0].status === "open"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$4(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let $vote;
  let $api;
  component_subscribe($$self, vote, ($$value) => $$invalidate(0, $vote = $$value));
  component_subscribe($$self, api, ($$value) => $$invalidate(3, $api = $$value));
  const dispatch = createEventDispatcher();
  async function closeVote() {
    await $api.closeVote($vote.id);
    dispatch("close", { id: $vote.id });
    $api.getOpenVote().then((v) => set_store_value(vote, $vote = v, $vote));
  }
  const click_handler = () => closeVote();
  return [$vote, closeVote, click_handler];
}
class VoteStatus extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, {});
  }
}
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[7] = list[i];
  return child_ctx;
}
const get_title_slot_changes$1 = (dirty) => ({});
const get_title_slot_context$1 = (ctx) => ({});
function fallback_block$1(ctx) {
  let t;
  return {
    c() {
      t = text("Previous Votes");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_catch_block$1(ctx) {
  let t;
  return {
    c() {
      t = text("error");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_then_block$1(ctx) {
  let t;
  let div;
  let div_transition;
  let current;
  let if_block = (
    /*$voteStats*/
    ctx[2].length === 0 && create_if_block_4$1()
  );
  let each_value = ensure_array_like(
    /*$voteStats*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$voteStats*/
        ctx2[2].length === 0
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_4$1();
          if_block.c();
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*$voteStats*/
      4) {
        each_value = ensure_array_like(
          /*$voteStats*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, {}, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(div);
      }
      if (if_block)
        if_block.d(detaching);
      destroy_each(each_blocks, detaching);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block_4$1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.innerHTML = `<span class="mt-2 block text-base text-gray-400">No votes yet. Click on &quot;New Vote&quot; to create one</span>`;
      attr(div, "class", "m-4 relative block w-full rounded-lg border-2 border-dashed hover:border-gray-300 p-12 text-center border-gray-400");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_3$1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.innerHTML = `<span class="text-gray-500">No ships voted</span>`;
      attr(div, "class", "flex items");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_2$1(ctx) {
  let div;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t2;
  let span1;
  let t3_value = (
    /*vote*/
    ctx[7].votedShips[0].name + ""
  );
  let t3;
  let t4;
  let span2;
  let t5_value = (
    /*vote*/
    ctx[7].votedShips[0].votes + ""
  );
  let t5;
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = "1.";
      t2 = space();
      span1 = element("span");
      t3 = text(t3_value);
      t4 = space();
      span2 = element("span");
      t5 = text(t5_value);
      attr(img, "alt", "ship");
      attr(img, "class", "h-6 w-10");
      if (!src_url_equal(img.src, img_src_value = /*vote*/
      ctx[7].votedShips[0].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-lg font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-lg");
      attr(span2, "class", "text-gray-400");
      attr(div, "class", "bg-gray-700 hover:bg-gray-600 transition text-gray-200 drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span0);
      append(div, t2);
      append(div, span1);
      append(span1, t3);
      append(div, t4);
      append(div, span2);
      append(span2, t5);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && !src_url_equal(img.src, img_src_value = /*vote*/
      ctx2[7].votedShips[0].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$voteStats*/
      4 && t3_value !== (t3_value = /*vote*/
      ctx2[7].votedShips[0].name + ""))
        set_data(t3, t3_value);
      if (dirty & /*$voteStats*/
      4 && t5_value !== (t5_value = /*vote*/
      ctx2[7].votedShips[0].votes + ""))
        set_data(t5, t5_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1$1(ctx) {
  let div2;
  let div0;
  let span0;
  let t1;
  let span1;
  let t2_value = (
    /*vote*/
    ctx[7].votedShips[1].name + ""
  );
  let t2;
  let t3;
  let span2;
  let t4_value = (
    /*vote*/
    ctx[7].votedShips[0].votes + ""
  );
  let t4;
  let t5;
  let div1;
  let span3;
  let t7;
  let span4;
  let t8_value = (
    /*vote*/
    ctx[7].votedShips[2].name + ""
  );
  let t8;
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      span0 = element("span");
      span0.textContent = "2.";
      t1 = space();
      span1 = element("span");
      t2 = text(t2_value);
      t3 = space();
      span2 = element("span");
      t4 = text(t4_value);
      t5 = space();
      div1 = element("div");
      span3 = element("span");
      span3.textContent = "3.";
      t7 = space();
      span4 = element("span");
      t8 = text(t8_value);
      attr(span0, "class", "text-xs font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-xs");
      attr(span2, "class", "text-gray-400");
      attr(span3, "class", "text-xs font-medium text-gray-400");
      attr(span4, "class", "text-xs");
      attr(div2, "class", "flex flex-col items-start pl-4");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div0, span0);
      append(div0, t1);
      append(div0, span1);
      append(span1, t2);
      append(div0, t3);
      append(div0, span2);
      append(span2, t4);
      append(div2, t5);
      append(div2, div1);
      append(div1, span3);
      append(div1, t7);
      append(div1, span4);
      append(span4, t8);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && t2_value !== (t2_value = /*vote*/
      ctx2[7].votedShips[1].name + ""))
        set_data(t2, t2_value);
      if (dirty & /*$voteStats*/
      4 && t4_value !== (t4_value = /*vote*/
      ctx2[7].votedShips[0].votes + ""))
        set_data(t4, t4_value);
      if (dirty & /*$voteStats*/
      4 && t8_value !== (t8_value = /*vote*/
      ctx2[7].votedShips[2].name + ""))
        set_data(t8, t8_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
    }
  };
}
function create_if_block$3(ctx) {
  let div;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t2;
  let span1;
  let t3_value = (
    /*vote*/
    ctx[7].votedShips[1].name + ""
  );
  let t3;
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = "2.";
      t2 = space();
      span1 = element("span");
      t3 = text(t3_value);
      attr(img, "alt", "ship");
      attr(img, "class", "h-4 w-8");
      if (!src_url_equal(img.src, img_src_value = /*vote*/
      ctx[7].votedShips[1].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-md font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-md");
      attr(div, "class", "text-gray-200 drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span0);
      append(div, t2);
      append(div, span1);
      append(span1, t3);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && !src_url_equal(img.src, img_src_value = /*vote*/
      ctx2[7].votedShips[1].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$voteStats*/
      4 && t3_value !== (t3_value = /*vote*/
      ctx2[7].votedShips[1].name + ""))
        set_data(t3, t3_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block$1(ctx) {
  let div3;
  let h5;
  let div1;
  let div0;
  let span0;
  let t1;
  let t2_value = (
    /*vote*/
    ctx[7].id + ""
  );
  let t2;
  let t3;
  let span1;
  let t4_value = (
    /*vote*/
    ctx[7].updated_at + ""
  );
  let t4;
  let t5;
  let div2;
  let t6;
  let t7;
  let t8;
  let t9;
  let if_block0 = (
    /*vote*/
    ctx[7].votedShips.length === 0 && create_if_block_3$1()
  );
  let if_block1 = (
    /*vote*/
    ctx[7].votedShips.length > 0 && create_if_block_2$1(ctx)
  );
  let if_block2 = (
    /*vote*/
    ctx[7].votedShips.length > 2 && create_if_block_1$1(ctx)
  );
  let if_block3 = (
    /*vote*/
    ctx[7].votedShips.length === 2 && create_if_block$3(ctx)
  );
  return {
    c() {
      div3 = element("div");
      h5 = element("h5");
      div1 = element("div");
      div0 = element("div");
      span0 = element("span");
      span0.textContent = "#";
      t1 = space();
      t2 = text(t2_value);
      t3 = space();
      span1 = element("span");
      t4 = text(t4_value);
      t5 = space();
      div2 = element("div");
      if (if_block0)
        if_block0.c();
      t6 = space();
      if (if_block1)
        if_block1.c();
      t7 = space();
      if (if_block2)
        if_block2.c();
      t8 = space();
      if (if_block3)
        if_block3.c();
      t9 = space();
      attr(span0, "class", "text-gray-300");
      attr(div0, "class", "flex-grow");
      attr(span1, "class", "text-gray-500 text-xs");
      attr(div1, "class", "flex items-center");
      attr(h5, "class", "text-md font-medium text-gray-100");
      attr(div2, "class", "px-4 grid grid-cols-2 gap-2 items-center");
      attr(div3, "class", "p-2");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, h5);
      append(h5, div1);
      append(div1, div0);
      append(div0, span0);
      append(div0, t1);
      append(div0, t2);
      append(div1, t3);
      append(div1, span1);
      append(span1, t4);
      append(div3, t5);
      append(div3, div2);
      if (if_block0)
        if_block0.m(div2, null);
      append(div2, t6);
      if (if_block1)
        if_block1.m(div2, null);
      append(div2, t7);
      if (if_block2)
        if_block2.m(div2, null);
      append(div2, t8);
      if (if_block3)
        if_block3.m(div2, null);
      append(div3, t9);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && t2_value !== (t2_value = /*vote*/
      ctx2[7].id + ""))
        set_data(t2, t2_value);
      if (dirty & /*$voteStats*/
      4 && t4_value !== (t4_value = /*vote*/
      ctx2[7].updated_at + ""))
        set_data(t4, t4_value);
      if (
        /*vote*/
        ctx2[7].votedShips.length === 0
      ) {
        if (if_block0)
          ;
        else {
          if_block0 = create_if_block_3$1();
          if_block0.c();
          if_block0.m(div2, t6);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*vote*/
        ctx2[7].votedShips.length > 0
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block_2$1(ctx2);
          if_block1.c();
          if_block1.m(div2, t7);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (
        /*vote*/
        ctx2[7].votedShips.length > 2
      ) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
        } else {
          if_block2 = create_if_block_1$1(ctx2);
          if_block2.c();
          if_block2.m(div2, t8);
        }
      } else if (if_block2) {
        if_block2.d(1);
        if_block2 = null;
      }
      if (
        /*vote*/
        ctx2[7].votedShips.length === 2
      ) {
        if (if_block3) {
          if_block3.p(ctx2, dirty);
        } else {
          if_block3 = create_if_block$3(ctx2);
          if_block3.c();
          if_block3.m(div2, null);
        }
      } else if (if_block3) {
        if_block3.d(1);
        if_block3 = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
      if (if_block3)
        if_block3.d();
    }
  };
}
function create_pending_block$1(ctx) {
  let t;
  return {
    c() {
      t = text("loading...");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$4(ctx) {
  let h2;
  let t;
  let await_block_anchor;
  let promise;
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[6].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    get_title_slot_context$1
  );
  const title_slot_or_fallback = title_slot || fallback_block$1();
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: true,
    pending: create_pending_block$1,
    then: create_then_block$1,
    catch: create_catch_block$1,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$votes*/
  ctx[1], info);
  return {
    c() {
      h2 = element("h2");
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
      t = space();
      await_block_anchor = empty();
      info.block.c();
      attr(h2, "class", "text-xl -mt-2");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(h2, null);
      }
      insert(target, t, anchor);
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx,
            /*$$scope*/
            ctx[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[5]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx[5],
              dirty,
              get_title_slot_changes$1
            ),
            get_title_slot_context$1
          );
        }
      }
      info.ctx = ctx;
      if (dirty & /*$votes*/
      2 && promise !== (promise = /*$votes*/
      ctx[1]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      transition_in(info.block);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t);
        detach(await_block_anchor);
      }
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let $votes, $$unsubscribe_votes = noop, $$subscribe_votes = () => ($$unsubscribe_votes(), $$unsubscribe_votes = subscribe(votes, ($$value) => $$invalidate(1, $votes = $$value)), votes);
  let $warships;
  let $voteStats;
  component_subscribe($$self, warships, ($$value) => $$invalidate(4, $warships = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_votes());
  let { $$slots: slots = {}, $$scope } = $$props;
  let { votes } = $$props;
  $$subscribe_votes();
  const voteStats = writable([]);
  component_subscribe($$self, voteStats, (value) => $$invalidate(2, $voteStats = value));
  $$self.$$set = ($$props2) => {
    if ("votes" in $$props2)
      $$subscribe_votes($$invalidate(0, votes = $$props2.votes));
    if ("$$scope" in $$props2)
      $$invalidate(5, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$warships, $votes*/
    18) {
      {
        if ($warships && $votes) {
          $warships.then(async (warships2) => {
            const votes2 = await $votes;
            return { votes: votes2, warships: warships2 };
          }).then(({ votes: votes2, warships: warships2 }) => {
            voteStats.set(votes2.map((vote2) => {
              return {
                ...vote2,
                votedShips: Object.entries(vote2.votes).map(([key, value]) => {
                  return { ...warships2[key], votes: value };
                }).sort((a, b) => a.votes > b.votes ? -1 : a.votes === b.votes ? 0 : 1).slice(0, 4)
              };
            }).sort((a, b) => a.id > b.id ? -1 : 1));
          });
        }
      }
    }
  };
  return [votes, $votes, $voteStats, voteStats, $warships, $$scope, slots];
}
class VoteHistory extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, { votes: 0 });
  }
}
function create_fragment$3(ctx) {
  let button;
  let div;
  let t;
  let svg;
  let path;
  let button_class_value;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[7].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[6],
    null
  );
  return {
    c() {
      button = element("button");
      div = element("div");
      if (default_slot)
        default_slot.c();
      t = space();
      svg = svg_element("svg");
      path = svg_element("path");
      attr(path, "stroke-linecap", "round");
      attr(path, "stroke-linejoin", "round");
      attr(path, "stroke-width", "2");
      attr(path, "d", "M17 8l4 4m0 0l-4 4m4-4H3");
      attr(svg, "class", "w-6 h-6");
      attr(svg, "fill", "none");
      attr(svg, "stroke", "currentColor");
      attr(svg, "viewBox", "0 0 24 24");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
      attr(div, "class", "flex space-around items-center gap-4");
      attr(button, "class", button_class_value = "overflow-hidden drop-shadow-xl rounded-lg px-4 py-5 sm:p-6 transition-all duration-250 " + /*disabled*/
      (ctx[0] ? (
        /*disabledClasses*/
        ctx[2]
      ) : (
        /*classes*/
        ctx[1]
      )));
      button.disabled = /*disabled*/
      ctx[0];
      toggle_class(button, "hover:cursor-pointer", !/*disabled*/
      ctx[0]);
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, div);
      if (default_slot) {
        default_slot.m(div, null);
      }
      append(div, t);
      append(div, svg);
      append(svg, path);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*navigate*/
          ctx[3]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        64)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[6],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[6]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[6],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*disabled*/
      1 && button_class_value !== (button_class_value = "overflow-hidden drop-shadow-xl rounded-lg px-4 py-5 sm:p-6 transition-all duration-250 " + /*disabled*/
      (ctx2[0] ? (
        /*disabledClasses*/
        ctx2[2]
      ) : (
        /*classes*/
        ctx2[1]
      )))) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*disabled*/
      1) {
        button.disabled = /*disabled*/
        ctx2[0];
      }
      if (!current || dirty & /*disabled, disabled*/
      1) {
        toggle_class(button, "hover:cursor-pointer", !/*disabled*/
        ctx2[0]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  const colorClassesMap = {
    default: "text-gray-100 bg-gray-800",
    primary: "text-emerald-50 bg-size-100 font-normal tracking-widest bg-gradient-to-b from-emerald-500 to-emerald-700 hover:bg-size-110"
  };
  const disabledClassesMap = {
    default: "text-gray-400 bg-gray-700",
    primary: "text-emerald-400 bg-emerald-900"
  };
  let { name } = $$props;
  let { disabled = false } = $$props;
  let { role = "default" } = $$props;
  let classes = colorClassesMap[role];
  let disabledClasses = disabledClassesMap[role];
  const dispatch = createEventDispatcher();
  async function navigate() {
    dispatch("navigate", { name });
  }
  $$self.$$set = ($$props2) => {
    if ("name" in $$props2)
      $$invalidate(4, name = $$props2.name);
    if ("disabled" in $$props2)
      $$invalidate(0, disabled = $$props2.disabled);
    if ("role" in $$props2)
      $$invalidate(5, role = $$props2.role);
    if ("$$scope" in $$props2)
      $$invalidate(6, $$scope = $$props2.$$scope);
  };
  return [disabled, classes, disabledClasses, navigate, name, role, $$scope, slots];
}
class Link extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, { name: 4, disabled: 0, role: 5 });
  }
}
const get_title_slot_changes = (dirty) => ({});
const get_title_slot_context = (ctx) => ({});
function fallback_block(ctx) {
  let t;
  return {
    c() {
      t = text(
        /*title*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*title*/
      1)
        set_data(
          t,
          /*title*/
          ctx2[0]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block$2(ctx) {
  let div;
  let div_intro;
  let div_outro;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "mt-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[5]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[5],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_default_slot$2(ctx) {
  let button;
  let svg;
  let path;
  let path_d_value;
  let t0;
  let t1;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  const title_slot_template = (
    /*#slots*/
    ctx[3].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    get_title_slot_context
  );
  const title_slot_or_fallback = title_slot || fallback_block(ctx);
  let if_block = (
    /*expanded*/
    ctx[2] && create_if_block$2(ctx)
  );
  return {
    c() {
      button = element("button");
      svg = svg_element("svg");
      path = svg_element("path");
      t0 = space();
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
      t1 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(path, "stroke-linecap", "round");
      attr(path, "stroke-linejoin", "round");
      attr(path, "stroke-width", "2");
      attr(path, "d", path_d_value = /*expanded*/
      ctx[2] ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7");
      attr(svg, "class", "h-6 w-6");
      attr(svg, "fill", "none");
      attr(svg, "stroke", "currentColor");
      attr(svg, "viewBox", "0 0 24 24");
      attr(button, "class", "flex cursor-pointer items-center gap-2");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, svg);
      append(svg, path);
      append(button, t0);
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(button, null);
      }
      insert(target, t1, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[4]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*expanded*/
      4 && path_d_value !== (path_d_value = /*expanded*/
      ctx2[2] ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7")) {
        attr(path, "d", path_d_value);
      }
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[5]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx2[5],
              dirty,
              get_title_slot_changes
            ),
            get_title_slot_context
          );
        }
      } else {
        if (title_slot_or_fallback && title_slot_or_fallback.p && (!current || dirty & /*title*/
        1)) {
          title_slot_or_fallback.p(ctx2, !current ? -1 : dirty);
        }
      }
      if (
        /*expanded*/
        ctx2[2]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*expanded*/
          4) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
        detach(t1);
        detach(if_block_anchor);
      }
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$2(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      colorClasses: (
        /*colorClasses*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const box_changes = {};
      if (dirty & /*colorClasses*/
      2)
        box_changes.colorClasses = /*colorClasses*/
        ctx2[1];
      if (dirty & /*$$scope, expanded, title*/
      37) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { title = "" } = $$props;
  let { colorClasses = void 0 } = $$props;
  let expanded = false;
  const click_handler = () => $$invalidate(2, expanded = !expanded);
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("colorClasses" in $$props2)
      $$invalidate(1, colorClasses = $$props2.colorClasses);
    if ("$$scope" in $$props2)
      $$invalidate(5, $$scope = $$props2.$$scope);
  };
  return [title, colorClasses, expanded, slots, click_handler, $$scope];
}
class ExpandableBox extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { title: 0, colorClasses: 1 });
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[10] = list[i][0];
  child_ctx[11] = list[i][1];
  return child_ctx;
}
function create_each_block(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_1() {
    return (
      /*click_handler_1*/
      ctx[7](
        /*position*/
        ctx[10]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.textContent = `${/*label*/
      ctx[11]} `;
      attr(button, "class", "w-full aspect-square col-span-1 hover:bg-cyan-700 transition text-gray-200 px-4 py-2 rounded active:bg-cyan-600 active:ring-2 ring-cyan-400");
      toggle_class(
        button,
        "bg-cyan-800",
        /*overlayPosition*/
        ctx[0] === /*position*/
        ctx[10]
      );
      toggle_class(
        button,
        "bg-cyan-900",
        /*overlayPosition*/
        ctx[0] !== /*position*/
        ctx[10]
      );
      toggle_class(
        button,
        "ring-2",
        /*overlayPosition*/
        ctx[0] === /*position*/
        ctx[10]
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_1);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*overlayPosition, options*/
      9) {
        toggle_class(
          button,
          "bg-cyan-800",
          /*overlayPosition*/
          ctx[0] === /*position*/
          ctx[10]
        );
      }
      if (dirty & /*overlayPosition, options*/
      9) {
        toggle_class(
          button,
          "bg-cyan-900",
          /*overlayPosition*/
          ctx[0] !== /*position*/
          ctx[10]
        );
      }
      if (dirty & /*overlayPosition, options*/
      9) {
        toggle_class(
          button,
          "ring-2",
          /*overlayPosition*/
          ctx[0] === /*position*/
          ctx[10]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block$1(ctx) {
  let div;
  let t;
  return {
    c() {
      div = element("div");
      t = text(
        /*channelUpdateFeedback*/
        ctx[1]
      );
      attr(div, "class", "text-cyan-400");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*channelUpdateFeedback*/
      2)
        set_data(
          t,
          /*channelUpdateFeedback*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot$1(ctx) {
  let div1;
  let h2;
  let t1;
  let div0;
  let t2;
  let button;
  let t4;
  let mounted;
  let dispose;
  let each_value = ensure_array_like(
    /*options*/
    ctx[3]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  let if_block = (
    /*channelUpdateFeedback*/
    ctx[1] && create_if_block$1(ctx)
  );
  return {
    c() {
      div1 = element("div");
      h2 = element("h2");
      h2.textContent = "Overlay Position";
      t1 = space();
      div0 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t2 = space();
      button = element("button");
      button.textContent = "Save";
      t4 = space();
      if (if_block)
        if_block.c();
      attr(h2, "class", "text-lg font-normal");
      attr(div0, "class", "grid content-center max-w-xl grid-cols-2 gap-4 px-8");
      attr(button, "class", "bg-cyan-900 hover:bg-cyan-800 transition text-gray-200 px-4 py-2 rounded mt-4 active:bg-cyan-600 active:ring-2 ring-cyan-400");
      attr(div1, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, h2);
      append(div1, t1);
      append(div1, div0);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div0, null);
        }
      }
      append(div1, t2);
      append(div1, button);
      append(div1, t4);
      if (if_block)
        if_block.m(div1, null);
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_2*/
          ctx[8]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*overlayPosition, options*/
      9) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[3]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div0, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (
        /*channelUpdateFeedback*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          if_block.m(div1, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_each(each_blocks, detaching);
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let a;
  let t1;
  let box;
  let current;
  let mounted;
  let dispose;
  box = new Box({
    props: {
      title: "Settings",
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      a = element("a");
      a.innerHTML = `<svg class="mt-0.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
    Go back`;
      t1 = space();
      create_component(box.$$.fragment);
      attr(a, "class", "inline-flex items-center gap-2 rounded p-4 font-medium text-gray-300 transition hover:bg-gray-800 hover:drop-shadow-xl");
      attr(a, "href", "#live_config");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, a);
      insert(target, t1, anchor);
      mount_component(box, target, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          a,
          "click",
          /*click_handler*/
          ctx[6]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      const box_changes = {};
      if (dirty & /*$$scope, channelUpdateFeedback, overlayPosition*/
      16387) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t1);
      }
      destroy_component(box, detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let $api;
  component_subscribe($$self, api, ($$value) => $$invalidate(9, $api = $$value));
  let { channel } = $$props;
  let overlayPosition = channel.overlay_position;
  const dispatch = createEventDispatcher();
  let channelUpdateFeedback = "";
  const options = [
    ["top_left", "Top Left"],
    ["top_right", "Top Right"],
    ["bottom_left", "Bottom Left"],
    ["bottom_right", "Bottom Right"]
  ];
  async function changeOverlayPosition(position) {
    console.log("changeOverlayPosition", position);
    $$invalidate(5, channel.overlay_position = position, channel);
    try {
      await $api.updateChannelConfig(channel);
      $$invalidate(1, channelUpdateFeedback = "Overlay position updated");
    } catch (e) {
      console.error(e);
      $$invalidate(1, channelUpdateFeedback = "Failed to update overlay position");
    }
    setTimeout(
      () => {
        $$invalidate(1, channelUpdateFeedback = "");
      },
      5e3
    );
  }
  const click_handler = () => dispatch("back");
  const click_handler_1 = (position) => $$invalidate(0, overlayPosition = position);
  const click_handler_2 = () => changeOverlayPosition(overlayPosition);
  $$self.$$set = ($$props2) => {
    if ("channel" in $$props2)
      $$invalidate(5, channel = $$props2.channel);
  };
  return [
    overlayPosition,
    channelUpdateFeedback,
    dispatch,
    options,
    changeOverlayPosition,
    channel,
    click_handler,
    click_handler_1,
    click_handler_2
  ];
}
class VideoOverlaySettings extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { channel: 5 });
  }
}
function create_catch_block(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block_6, create_else_block_2];
  const if_blocks = [];
  function select_block_type_2(ctx2, dirty) {
    if (
      /*e*/
      ctx2[18].response && /*e*/
      ctx2[18].response.status === 404
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_2(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_2(ctx2);
      if (current_block_type_index !== previous_block_index) {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block_2(ctx) {
  let notification;
  let current;
  notification = new Notification({
    props: {
      type: "error",
      title: "Error",
      $$slots: { default: [create_default_slot_7] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(notification.$$.fragment);
    },
    m(target, anchor) {
      mount_component(notification, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(notification.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(notification.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(notification, detaching);
    }
  };
}
function create_if_block_6(ctx) {
  let notification;
  let current;
  notification = new Notification({
    props: {
      type: "info",
      title: "No configuration found",
      $$slots: { default: [create_default_slot_6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(notification.$$.fragment);
    },
    m(target, anchor) {
      mount_component(notification, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(notification.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(notification.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(notification, detaching);
    }
  };
}
function create_default_slot_7(ctx) {
  let p;
  return {
    c() {
      p = element("p");
      p.textContent = "Could not load channel configuration";
    },
    m(target, anchor) {
      insert(target, p, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_default_slot_6(ctx) {
  let p;
  return {
    c() {
      p = element("p");
      p.textContent = 'Please visit the "Extensions" page and set up the Shipvote extension\n          for your channel';
    },
    m(target, anchor) {
      insert(target, p, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_then_block(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let div_transition;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*currentOverlay*/
      ctx2[1] !== null
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "flex flex-col gap-4");
      toggle_class(div, "hidden", !/*channel*/
      ctx[10]);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
      if (!current || dirty & /*$channel*/
      64) {
        toggle_class(div, "hidden", !/*channel*/
        ctx2[10]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, { duration: 300 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(if_block);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, { duration: 300 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_else_block(ctx) {
  let div;
  let t0;
  let votestatus;
  let t1;
  let box;
  let t2;
  let link;
  let t3;
  let expandablebox0;
  let t4;
  let expandablebox1;
  let div_transition;
  let current;
  let if_block = (
    /*$vote*/
    (ctx[5] === void 0 || /*$vote*/
    ctx[5] === null || /*$vote*/
    ctx[5].status === "closed") && create_if_block_5(ctx)
  );
  votestatus = new VoteStatus({});
  votestatus.$on(
    "close",
    /*close_handler*/
    ctx[14]
  );
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  link = new Link({
    props: {
      name: "settings",
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  link.$on(
    "navigate",
    /*navigate*/
    ctx[8]
  );
  expandablebox0 = new ExpandableBox({
    props: {
      $$slots: {
        title: [create_title_slot],
        default: [create_default_slot_2]
      },
      $$scope: { ctx }
    }
  });
  expandablebox1 = new ExpandableBox({
    props: {
      colorClasses: "text-amber-50 bg-gradient-to-b from-amber-400/20 to-amber-600/20",
      title: "Feedback",
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      t0 = space();
      create_component(votestatus.$$.fragment);
      t1 = space();
      create_component(box.$$.fragment);
      t2 = space();
      create_component(link.$$.fragment);
      t3 = space();
      create_component(expandablebox0.$$.fragment);
      t4 = space();
      create_component(expandablebox1.$$.fragment);
      attr(div, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      append(div, t0);
      mount_component(votestatus, div, null);
      append(div, t1);
      mount_component(box, div, null);
      append(div, t2);
      mount_component(link, div, null);
      append(div, t3);
      mount_component(expandablebox0, div, null);
      append(div, t4);
      mount_component(expandablebox1, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[5] === void 0 || /*$vote*/
        ctx2[5] === null || /*$vote*/
        ctx2[5].status === "closed"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          32) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_5(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, t0);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      const box_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
      const link_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
      const expandablebox0_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        expandablebox0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      expandablebox0.$set(expandablebox0_changes);
      const expandablebox1_changes = {};
      if (dirty & /*$$scope, feedbackStatus, feedback*/
      524300) {
        expandablebox1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      expandablebox1.$set(expandablebox1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(votestatus.$$.fragment, local);
      transition_in(box.$$.fragment, local);
      transition_in(link.$$.fragment, local);
      transition_in(expandablebox0.$$.fragment, local);
      transition_in(expandablebox1.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, { duration: 100 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(votestatus.$$.fragment, local);
      transition_out(box.$$.fragment, local);
      transition_out(link.$$.fragment, local);
      transition_out(expandablebox0.$$.fragment, local);
      transition_out(expandablebox1.$$.fragment, local);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, { duration: 100 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      destroy_component(votestatus);
      destroy_component(box);
      destroy_component(link);
      destroy_component(expandablebox0);
      destroy_component(expandablebox1);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block(ctx) {
  let t;
  let if_block1_anchor;
  let current;
  let if_block0 = (
    /*currentOverlay*/
    ctx[1] === "new_vote" && create_if_block_2(ctx)
  );
  let if_block1 = (
    /*currentOverlay*/
    ctx[1] === "settings" && create_if_block_1(ctx)
  );
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*currentOverlay*/
        ctx2[1] === "new_vote"
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*currentOverlay*/
          2) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_2(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (
        /*currentOverlay*/
        ctx2[1] === "settings"
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
          if (dirty & /*currentOverlay*/
          2) {
            transition_in(if_block1, 1);
          }
        } else {
          if_block1 = create_if_block_1(ctx2);
          if_block1.c();
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        }
      } else if (if_block1) {
        group_outros();
        transition_out(if_block1, 1, 1, () => {
          if_block1 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if (if_block1)
        if_block1.d(detaching);
    }
  };
}
function create_if_block_5(ctx) {
  let link;
  let current;
  link = new Link({
    props: {
      name: "new_vote",
      role: "primary",
      disabled: (
        /*$vote*/
        ctx[5] !== void 0 && /*$vote*/
        ctx[5] !== null
      ),
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  link.$on(
    "navigate",
    /*navigate*/
    ctx[8]
  );
  return {
    c() {
      create_component(link.$$.fragment);
    },
    m(target, anchor) {
      mount_component(link, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const link_changes = {};
      if (dirty & /*$vote*/
      32)
        link_changes.disabled = /*$vote*/
        ctx2[5] !== void 0 && /*$vote*/
        ctx2[5] !== null;
      if (dirty & /*$$scope*/
      524288) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(link.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(link.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(link, detaching);
    }
  };
}
function create_default_slot_5(ctx) {
  let t;
  return {
    c() {
      t = text("New Vote");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_4(ctx) {
  let votehistory;
  let current;
  votehistory = new VoteHistory({ props: { votes: (
    /*closedVotes*/
    ctx[7]
  ) } });
  return {
    c() {
      create_component(votehistory.$$.fragment);
    },
    m(target, anchor) {
      mount_component(votehistory, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(votehistory.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(votehistory.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(votehistory, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.innerHTML = `<span class="inline-flex items-center rounded-md bg-cyan-400/10 px-2 py-1 text-xs font-medium text-cyan-400 ring-1 ring-inset ring-cyan-400/30">New</span> <span>Settings</span>`;
      attr(div, "class", "flex gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot_2(ctx) {
  let div4;
  return {
    c() {
      div4 = element("div");
      div4.innerHTML = `<h3 class="text-xl font-bold">v3.2.0</h3> <div class="prose text-gray-400"><ul><li>Added a Settings page where you can configure the overlay
                    position for desktop viewers</li> <li>Cleaned up some UI elements to make it easier to interact
                    with votes</li> <li>The most recently used ships for your vote are now saved in
                    the backend so that it resets less often for you</li> <li>You can now submit feedback directly from the extension</li></ul></div> <h3 class="text-xl font-bold">v3.1.0</h3> <div class="prose text-gray-400"><ul><li>You can now select a time limit for votes. The vote will
                    close automatically after the time limit is reached. Viewers
                    can also see the remaining time.</li> <li>Various changes in the backend to make it run on a more
                    modern server</li></ul></div> <h3 class="text-xl font-bold">v3.0.1</h3> <div class="prose text-gray-400"><ul><li>Fixed a bug where channels could not be configured</li> <li>Fixed a bug where there were too many HTTP requests to the
                    Shipvote server.</li></ul></div> <h3 class="text-xl font-bold">v3.0.0</h3> <div class="prose text-gray-400"><p>This version is a complete rewrite of the previous interface.
                  It hopefully lays some groundwork for upcoming improvements.
                  This version is more or less on par with the previous version
                  feature-wise, although I had to remove the timer functionality
                  for now.</p> <p>Please let me know if you encounter any problems or are
                  missing any features - I am happy to take feature requests!</p></div>`;
      attr(div4, "class", "flex flex-col gap-2");
    },
    m(target, anchor) {
      insert(target, div4, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div4);
      }
    }
  };
}
function create_title_slot(ctx) {
  let div1;
  let h2;
  let t1;
  let div0;
  return {
    c() {
      div1 = element("div");
      h2 = element("h2");
      h2.textContent = "Changelog";
      t1 = space();
      div0 = element("div");
      div0.textContent = `${"3.2.0"}`;
      attr(div0, "class", "flex items-center rounded-lg bg-gray-900 px-2 text-xs text-cyan-100");
      attr(div1, "slot", "title");
      attr(div1, "class", "flex gap-2");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, h2);
      append(div1, t1);
      append(div1, div0);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
    }
  };
}
function create_if_block_3(ctx) {
  let div;
  let div_intro;
  let div_outro;
  let current;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*feedbackStatus*/
      ctx2[3] === "error"
    )
      return create_if_block_4;
    return create_else_block_1;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_block.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (current_block_type !== (current_block_type = select_block_type_1(ctx2))) {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(div, null);
        }
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_block.d();
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_else_block_1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "Feedback sent!";
      attr(div, "class", "text-amber-200");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_4(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "Error sending feedback. Please contact me on Discord!";
      attr(div, "class", "text-red-200");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot_1(ctx) {
  let div1;
  let div0;
  let t3;
  let textarea;
  let t4;
  let button;
  let t6;
  let mounted;
  let dispose;
  let if_block = (
    /*feedbackStatus*/
    ctx[3] && create_if_block_3(ctx)
  );
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      div0.innerHTML = `If you have any feedback, feature requests, or bug reports,
                please let me know! You can either submit feedback through the
                field below or contact me on Discord at <span class="font-semibold">Rukenshia#4396<span>.</span></span>`;
      t3 = space();
      textarea = element("textarea");
      t4 = space();
      button = element("button");
      button.textContent = "Submit";
      t6 = space();
      if (if_block)
        if_block.c();
      attr(div0, "class", "prose text-gray-50 min-w-full");
      attr(textarea, "class", "w-full p-2 rounded-lg bg-amber-950/60 text-amber-100 placeholder-amber-100");
      attr(textarea, "placeholder", "Enter your feedback here");
      attr(button, "class", "rounded-lg bg-gradient-to-b from-amber-400/50 to-amber-600/50 text-amber-50 px-6 py-2 bg-size-100 hover:bg-size-110 transition-all duration-250");
      attr(div1, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div1, t3);
      append(div1, textarea);
      set_input_value(
        textarea,
        /*feedback*/
        ctx[2]
      );
      append(div1, t4);
      append(div1, button);
      append(div1, t6);
      if (if_block)
        if_block.m(div1, null);
      if (!mounted) {
        dispose = [
          listen(
            textarea,
            "input",
            /*textarea_input_handler*/
            ctx[15]
          ),
          listen(
            button,
            "click",
            /*submitFeedback*/
            ctx[9]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*feedback*/
      4) {
        set_input_value(
          textarea,
          /*feedback*/
          ctx2[2]
        );
      }
      if (
        /*feedbackStatus*/
        ctx2[3]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*feedbackStatus*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_3(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div1, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if (if_block)
        if_block.d();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_if_block_2(ctx) {
  let newvote;
  let current;
  newvote = new NewVote({});
  newvote.$on(
    "back",
    /*back_handler*/
    ctx[11]
  );
  newvote.$on(
    "vote_opened",
    /*vote_opened_handler*/
    ctx[12]
  );
  return {
    c() {
      create_component(newvote.$$.fragment);
    },
    m(target, anchor) {
      mount_component(newvote, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(newvote.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(newvote.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(newvote, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let videooverlaysettings;
  let current;
  videooverlaysettings = new VideoOverlaySettings({ props: { channel: (
    /*channel*/
    ctx[10]
  ) } });
  videooverlaysettings.$on(
    "back",
    /*back_handler_1*/
    ctx[13]
  );
  return {
    c() {
      create_component(videooverlaysettings.$$.fragment);
    },
    m(target, anchor) {
      mount_component(videooverlaysettings, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const videooverlaysettings_changes = {};
      if (dirty & /*$channel*/
      64)
        videooverlaysettings_changes.channel = /*channel*/
        ctx2[10];
      videooverlaysettings.$set(videooverlaysettings_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(videooverlaysettings.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(videooverlaysettings.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(videooverlaysettings, detaching);
    }
  };
}
function create_pending_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_default_slot(ctx) {
  let creatorbanner;
  let current;
  creatorbanner = new CreatorBanner({});
  return {
    c() {
      create_component(creatorbanner.$$.fragment);
    },
    m(target, anchor) {
      mount_component(creatorbanner, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(creatorbanner.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(creatorbanner.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(creatorbanner, detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let promise;
  let t;
  let box;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: true,
    pending: create_pending_block,
    then: create_then_block,
    catch: create_catch_block,
    value: 10,
    error: 18,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$channel*/
  ctx[6], info);
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      info.block.c();
      t = space();
      create_component(box.$$.fragment);
      attr(div, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      info.block.m(div, info.anchor = null);
      info.mount = () => div;
      info.anchor = t;
      append(div, t);
      mount_component(box, div, null);
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$channel*/
      64 && promise !== (promise = /*$channel*/
      ctx[6]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
      const box_changes = {};
      if (dirty & /*$$scope*/
      524288) {
        box_changes.$$scope = { dirty, ctx };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      info.block.d();
      info.token = null;
      info = null;
      destroy_component(box);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $api;
  let $closedVotes;
  let $vote;
  let $channel;
  component_subscribe($$self, api, ($$value) => $$invalidate(0, $api = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(5, $vote = $$value));
  let currentOverlay = null;
  const pubSubHandler = new PubSubHandler();
  const channel = derived(api, ($api2, set) => {
    if (!$api2) {
      return;
    }
    set($api2.broadcasterGetChannel());
  });
  component_subscribe($$self, channel, (value) => $$invalidate(6, $channel = value));
  onMount(() => {
    pubSubHandler.init();
    pubSubHandler.addEventListener("vote_closed", async () => {
      set_store_value(closedVotes, $closedVotes = await $api.getClosedVotes(), $closedVotes);
    });
    return () => {
    };
  });
  onDestroy(() => {
    pubSubHandler.deinit();
  });
  const closedVotes = writable(new Promise(() => {
  }));
  component_subscribe($$self, closedVotes, (value) => $$invalidate(4, $closedVotes = value));
  function navigate(e) {
    e.preventDefault();
    switch (e.detail.name) {
      case "new_vote":
        $$invalidate(1, currentOverlay = "new_vote");
        break;
      case "settings":
        $$invalidate(1, currentOverlay = "settings");
        break;
    }
  }
  let feedback = "";
  let feedbackStatus = "";
  async function submitFeedback() {
    try {
      await $api.sendFeedback(feedback);
      $$invalidate(2, feedback = "");
      $$invalidate(3, feedbackStatus = "sent");
    } catch (e) {
      $$invalidate(3, feedbackStatus = "error");
    }
    setTimeout(
      () => {
        $$invalidate(3, feedbackStatus = "");
      },
      5e3
    );
  }
  const back_handler = () => $$invalidate(1, currentOverlay = null);
  const vote_opened_handler = () => $$invalidate(1, currentOverlay = null);
  const back_handler_1 = () => $$invalidate(1, currentOverlay = null);
  const close_handler = async () => set_store_value(closedVotes, $closedVotes = await $api.getClosedVotes(), $closedVotes);
  function textarea_input_handler() {
    feedback = this.value;
    $$invalidate(2, feedback);
  }
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$api*/
    1) {
      if ($api) {
        $api.getOpenVote().then((v) => set_store_value(vote, $vote = v, $vote));
        set_store_value(closedVotes, $closedVotes = $api.getClosedVotes(), $closedVotes);
      }
    }
  };
  return [
    $api,
    currentOverlay,
    feedback,
    feedbackStatus,
    $closedVotes,
    $vote,
    $channel,
    closedVotes,
    navigate,
    submitFeedback,
    channel,
    back_handler,
    vote_opened_handler,
    back_handler_1,
    close_handler,
    textarea_input_handler
  ];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
new App({
  target: document.getElementById("app")
});
