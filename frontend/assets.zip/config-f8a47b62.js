import { S as SvelteComponent, i as init, s as safe_not_equal, v as create_component, w as mount_component, g as transition_in, j as transition_out, B as destroy_component, o as component_subscribe, p as api, N as createEventDispatcher, G as derived, H as empty, d as insert, m as detach, F as noop, O as subscribe, L as writable, e as ensure_array_like, a as element, b as space, c as attr, f as append, P as set_input_value, l as listen, n as destroy_each, C as text, E as src_url_equal, D as set_data, k as check_outros, I as onMount, h as group_outros, Q as channelId, M as set_store_value, R as select_value, y as add_render_callback, T as select_option, r as run_all } from "./app.js";
import { B as Box } from "./Box.js";
import { N as Notification } from "./Notification.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[13] = list[i];
  return child_ctx;
}
function create_if_block$1(ctx) {
  let div1;
  let input;
  let t;
  let div0;
  let mounted;
  let dispose;
  let each_value = ensure_array_like(
    /*$filteredShips*/
    ctx[3]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div1 = element("div");
      input = element("input");
      t = space();
      div0 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(input, "type", "text");
      attr(input, "placeholder", "Search");
      attr(input, "class", "w-full border placeholder-gray-400 text-gray-300 rounded px-2 py-1 bg-cyan-900 border-gray-800");
      attr(div0, "class", "flex flex-col gap-4");
      attr(div1, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, input);
      set_input_value(
        input,
        /*$search*/
        ctx[2]
      );
      append(div1, t);
      append(div1, div0);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div0, null);
        }
      }
      if (!mounted) {
        dispose = listen(
          input,
          "input",
          /*input_input_handler*/
          ctx[8]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*$search*/
      4 && input.value !== /*$search*/
      ctx2[2]) {
        set_input_value(
          input,
          /*$search*/
          ctx2[2]
        );
      }
      if (dirty & /*disable, $filteredShips, enable*/
      200) {
        each_value = ensure_array_like(
          /*$filteredShips*/
          ctx2[3]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div0, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_else_block$1(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_1() {
    return (
      /*click_handler_1*/
      ctx[10](
        /*ship*/
        ctx[13]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.innerHTML = `<span>Enable</span>`;
      attr(button, "class", "bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 text-gray-200 transition");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_1);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_1$1(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler() {
    return (
      /*click_handler*/
      ctx[9](
        /*ship*/
        ctx[13]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.innerHTML = `<span>Disable</span>`;
      attr(button, "class", "hover:bg-gray-700 rounded px-4 py-2 text-gray-400 transition");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_each_block(ctx) {
  let div1;
  let img;
  let img_src_value;
  let img_alt_value;
  let t0;
  let div0;
  let t1_value = (
    /*ship*/
    ctx[13].name + ""
  );
  let t1;
  let t2;
  let t3;
  function select_block_type(ctx2, dirty) {
    if (
      /*ship*/
      ctx2[13].enabled
    )
      return create_if_block_1$1;
    return create_else_block$1;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div1 = element("div");
      img = element("img");
      t0 = space();
      div0 = element("div");
      t1 = text(t1_value);
      t2 = space();
      if_block.c();
      t3 = space();
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[13].image))
        attr(img, "src", img_src_value);
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[13].name);
      attr(img, "class", "h-6");
      attr(div0, "class", "flex-grow");
      attr(div1, "class", "flex flex-row gap-4 bg-gray-900 drop-shadow rounded items-center p-2");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, img);
      append(div1, t0);
      append(div1, div0);
      append(div0, t1);
      append(div1, t2);
      if_block.m(div1, null);
      append(div1, t3);
    },
    p(ctx2, dirty) {
      if (dirty & /*$filteredShips*/
      8 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx2[13].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$filteredShips*/
      8 && img_alt_value !== (img_alt_value = /*ship*/
      ctx2[13].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*$filteredShips*/
      8 && t1_value !== (t1_value = /*ship*/
      ctx2[13].name + ""))
        set_data(t1, t1_value);
      if (current_block_type === (current_block_type = select_block_type(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(div1, t3);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      if_block.d();
    }
  };
}
function create_default_slot$1(ctx) {
  let if_block_anchor;
  let if_block = (
    /*$channel*/
    ctx[1] && create_if_block$1(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (
        /*$channel*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      title: "Ships",
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const box_changes = {};
      if (dirty & /*$$scope, $filteredShips, $search, $channel*/
      65550) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let $channel, $$unsubscribe_channel = noop, $$subscribe_channel = () => ($$unsubscribe_channel(), $$unsubscribe_channel = subscribe(channel, ($$value) => $$invalidate(1, $channel = $$value)), channel);
  let $api;
  let $search;
  let $filteredShips;
  component_subscribe($$self, api, ($$value) => $$invalidate(11, $api = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_channel());
  let { channel } = $$props;
  $$subscribe_channel();
  const dispatch = createEventDispatcher();
  let search = writable("");
  component_subscribe($$self, search, (value) => $$invalidate(2, $search = value));
  let filteredShips = derived([channel, search], ([$channel2, $search2]) => {
    if (!$channel2) {
      return;
    }
    const sort = (a, b) => {
      if (a.enabled && !b.enabled) {
        return 1;
      }
      if (!a.enabled && b.enabled) {
        return -1;
      }
      return a.name.localeCompare(b.name);
    };
    if (!$search2) {
      return $channel2.ships.sort(sort);
    }
    return $channel2.ships.filter((ship) => ship.name.toLowerCase().includes($search2.toLowerCase())).sort(sort);
  });
  component_subscribe($$self, filteredShips, (value) => $$invalidate(3, $filteredShips = value));
  async function enable(ship) {
    ship.enabled = true;
    await $api.setShipStatus(ship.id, true);
    dispatch("update", $channel.ships);
  }
  async function disable(ship) {
    ship.enabled = false;
    await $api.setShipStatus(ship.id, false);
    dispatch("update", $channel.ships);
  }
  function input_input_handler() {
    $search = this.value;
    search.set($search);
  }
  const click_handler = (ship) => disable(ship);
  const click_handler_1 = (ship) => enable(ship);
  $$self.$$set = ($$props2) => {
    if ("channel" in $$props2)
      $$subscribe_channel($$invalidate(0, channel = $$props2.channel));
  };
  return [
    channel,
    $channel,
    $search,
    $filteredShips,
    search,
    filteredShips,
    enable,
    disable,
    input_input_handler,
    click_handler,
    click_handler_1
  ];
}
class ChannelShips extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { channel: 0 });
  }
}
function create_else_block(ctx) {
  let t;
  let current_block_type_index;
  let if_block1;
  let if_block1_anchor;
  let current;
  let if_block0 = !/*exists*/
  ctx[1] && create_if_block_2(ctx);
  const if_block_creators = [create_if_block_1, create_else_block_1];
  const if_blocks = [];
  function select_block_type_1(ctx2, dirty) {
    if (
      /*$channel*/
      ctx2[4]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type_1(ctx);
  if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if (if_block0)
        if_block0.c();
      t = space();
      if_block1.c();
      if_block1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block0)
        if_block0.m(target, anchor);
      insert(target, t, anchor);
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (!/*exists*/
      ctx2[1]) {
        if (if_block0) {
          if (dirty & /*exists*/
          2) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_2(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(t.parentNode, t);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type_1(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block1 = if_blocks[current_block_type_index];
        if (!if_block1) {
          if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block1.c();
        } else {
          if_block1.p(ctx2, dirty);
        }
        transition_in(if_block1, 1);
        if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(if_block1_anchor);
      }
      if (if_block0)
        if_block0.d(detaching);
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_if_block(ctx) {
  let notification;
  let current;
  notification = new Notification({
    props: {
      type: "info",
      title: "Loading",
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(notification.$$.fragment);
    },
    m(target, anchor) {
      mount_component(notification, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const notification_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        notification_changes.$$scope = { dirty, ctx: ctx2 };
      }
      notification.$set(notification_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(notification.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(notification.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(notification, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let notification;
  let current;
  notification = new Notification({
    props: {
      type: "info",
      title: "No configuration found",
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(notification.$$.fragment);
    },
    m(target, anchor) {
      mount_component(notification, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(notification.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(notification.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(notification, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  let p;
  return {
    c() {
      p = element("p");
      p.textContent = "Please enter your World of Warships account information below to get\n          started";
    },
    m(target, anchor) {
      insert(target, p, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_else_block_1(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      title: "Setup",
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope, wows_realm, wows_username*/
      65548) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let box;
  let t;
  let channelships;
  let current;
  box = new Box({
    props: {
      title: "Settings",
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  channelships = new ChannelShips({ props: { channel: (
    /*channel*/
    ctx[5]
  ) } });
  channelships.$on(
    "update",
    /*updateShips*/
    ctx[8]
  );
  return {
    c() {
      create_component(box.$$.fragment);
      t = space();
      create_component(channelships.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      insert(target, t, anchor);
      mount_component(channelships, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope, wows_realm, wows_username*/
      65548) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      transition_in(channelships.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      transition_out(channelships.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(box, detaching);
      destroy_component(channelships, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let form;
  let div2;
  let div0;
  let label0;
  let t1;
  let input;
  let t2;
  let div1;
  let label1;
  let t4;
  let select;
  let option0;
  let option1;
  let option2;
  let t8;
  let button;
  let mounted;
  let dispose;
  return {
    c() {
      form = element("form");
      div2 = element("div");
      div0 = element("div");
      label0 = element("label");
      label0.textContent = "WoWS Username";
      t1 = space();
      input = element("input");
      t2 = space();
      div1 = element("div");
      label1 = element("label");
      label1.textContent = "WoWS Server";
      t4 = space();
      select = element("select");
      option0 = element("option");
      option0.textContent = "EU";
      option1 = element("option");
      option1.textContent = "NA";
      option2 = element("option");
      option2.textContent = "ASIA";
      t8 = space();
      button = element("button");
      button.textContent = "Save";
      attr(label0, "for", "channel-name");
      attr(input, "id", "channel-name");
      attr(input, "type", "text");
      attr(input, "placeholder", "Your WoWS username");
      attr(input, "class", "border placeholder-cyan-700/90 rounded px-2 py-1 bg-cyan-900 border-gray-800");
      attr(div0, "class", "flex flex-col gap-2");
      attr(label1, "for", "channel-name");
      option0.__value = "eu";
      set_input_value(option0, option0.__value);
      option1.__value = "na";
      set_input_value(option1, option1.__value);
      option2.__value = "asia";
      set_input_value(option2, option2.__value);
      attr(select, "id", "channel-name");
      attr(select, "class", "border rounded px-2 py-1 bg-cyan-900 border-gray-800");
      if (
        /*wows_realm*/
        ctx[3] === void 0
      )
        add_render_callback(() => (
          /*select_change_handler_1*/
          ctx[12].call(select)
        ));
      attr(div1, "class", "flex flex-col gap-2");
      attr(div2, "class", "flex flex-col gap-4");
      attr(button, "type", "submit");
      attr(button, "class", "bg-cyan-900 hover:bg-cyan-800 transition text-gray-200 px-4 py-2 rounded mt-4");
      attr(form, "action", "#");
      attr(form, "method", "GET");
    },
    m(target, anchor) {
      insert(target, form, anchor);
      append(form, div2);
      append(div2, div0);
      append(div0, label0);
      append(div0, t1);
      append(div0, input);
      set_input_value(
        input,
        /*wows_username*/
        ctx[2]
      );
      append(div2, t2);
      append(div2, div1);
      append(div1, label1);
      append(div1, t4);
      append(div1, select);
      append(select, option0);
      append(select, option1);
      append(select, option2);
      select_option(
        select,
        /*wows_realm*/
        ctx[3],
        true
      );
      append(form, t8);
      append(form, button);
      if (!mounted) {
        dispose = [
          listen(
            input,
            "input",
            /*input_input_handler_1*/
            ctx[11]
          ),
          listen(
            select,
            "change",
            /*select_change_handler_1*/
            ctx[12]
          ),
          listen(
            button,
            "click",
            /*createConfig*/
            ctx[7]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*wows_username*/
      4 && input.value !== /*wows_username*/
      ctx2[2]) {
        set_input_value(
          input,
          /*wows_username*/
          ctx2[2]
        );
      }
      if (dirty & /*wows_realm*/
      8) {
        select_option(
          select,
          /*wows_realm*/
          ctx2[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(form);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot_2(ctx) {
  let form;
  let div2;
  let div0;
  let label0;
  let t1;
  let input;
  let t2;
  let div1;
  let label1;
  let t4;
  let select;
  let option0;
  let option1;
  let option2;
  let t8;
  let button;
  let mounted;
  let dispose;
  return {
    c() {
      form = element("form");
      div2 = element("div");
      div0 = element("div");
      label0 = element("label");
      label0.textContent = "WoWS Username";
      t1 = space();
      input = element("input");
      t2 = space();
      div1 = element("div");
      label1 = element("label");
      label1.textContent = "WoWS Server";
      t4 = space();
      select = element("select");
      option0 = element("option");
      option0.textContent = "EU";
      option1 = element("option");
      option1.textContent = "NA";
      option2 = element("option");
      option2.textContent = "ASIA";
      t8 = space();
      button = element("button");
      button.textContent = "Save";
      attr(label0, "for", "channel-name");
      attr(input, "id", "channel-name");
      attr(input, "type", "text");
      attr(input, "placeholder", "Your WoWS username");
      attr(input, "class", "border rounded px-2 py-1 bg-cyan-900 border-gray-800");
      attr(div0, "class", "flex flex-col gap-2");
      attr(label1, "for", "channel-name");
      option0.__value = "eu";
      set_input_value(option0, option0.__value);
      option1.__value = "na";
      set_input_value(option1, option1.__value);
      option2.__value = "asia";
      set_input_value(option2, option2.__value);
      attr(select, "id", "channel-name");
      attr(select, "class", "border rounded px-2 py-1 bg-cyan-900 border-gray-800");
      if (
        /*wows_realm*/
        ctx[3] === void 0
      )
        add_render_callback(() => (
          /*select_change_handler*/
          ctx[10].call(select)
        ));
      attr(div1, "class", "flex flex-col gap-2");
      attr(div2, "class", "flex flex-col gap-4");
      attr(button, "type", "submit");
      attr(button, "class", "bg-cyan-900 hover:bg-cyan-800 transition text-gray-200 px-4 py-2 rounded mt-4");
      attr(form, "action", "#");
      attr(form, "method", "GET");
    },
    m(target, anchor) {
      insert(target, form, anchor);
      append(form, div2);
      append(div2, div0);
      append(div0, label0);
      append(div0, t1);
      append(div0, input);
      set_input_value(
        input,
        /*wows_username*/
        ctx[2]
      );
      append(div2, t2);
      append(div2, div1);
      append(div1, label1);
      append(div1, t4);
      append(div1, select);
      append(select, option0);
      append(select, option1);
      append(select, option2);
      select_option(
        select,
        /*wows_realm*/
        ctx[3],
        true
      );
      append(form, t8);
      append(form, button);
      if (!mounted) {
        dispose = [
          listen(
            input,
            "input",
            /*input_input_handler*/
            ctx[9]
          ),
          listen(
            select,
            "change",
            /*select_change_handler*/
            ctx[10]
          ),
          listen(
            button,
            "click",
            /*updateConfig*/
            ctx[6]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*wows_username*/
      4 && input.value !== /*wows_username*/
      ctx2[2]) {
        set_input_value(
          input,
          /*wows_username*/
          ctx2[2]
        );
      }
      if (dirty & /*wows_realm*/
      8) {
        select_option(
          select,
          /*wows_realm*/
          ctx2[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(form);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_default_slot_1(ctx) {
  let p;
  return {
    c() {
      p = element("p");
      p.textContent = "Please wait while we load your configuration";
    },
    m(target, anchor) {
      insert(target, p, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_default_slot(ctx) {
  let t;
  return {
    c() {
      t = text("If you have any problems configuring this extension, please contact me on\n    Discord(Rukenshia#4396) or via Mail (svc-shipvote@ruken.pw)");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let t;
  let box;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*loading*/
      ctx2[0]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      if_block.c();
      t = space();
      create_component(box.$$.fragment);
      attr(div, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      append(div, t);
      mount_component(box, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, t);
      }
      const box_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      destroy_component(box);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $channel;
  let $channelId;
  let $api;
  component_subscribe($$self, channelId, ($$value) => $$invalidate(13, $channelId = $$value));
  component_subscribe($$self, api, ($$value) => $$invalidate(14, $api = $$value));
  const channel = writable();
  component_subscribe($$self, channel, (value) => $$invalidate(4, $channel = value));
  let loading = true;
  let exists = false;
  api.subscribe(async ($api2) => {
    if (!$api2) {
      return;
    }
    $$invalidate(0, loading = true);
    channel.set(await $api2.broadcasterGetChannel());
    $$invalidate(0, loading = false);
  });
  let wows_username = "";
  let wows_realm = "eu";
  onMount(async () => {
    channel.subscribe(async ($channel2) => {
      if (!$channel2) {
        $$invalidate(1, exists = false);
        return;
      }
      $$invalidate(1, exists = true);
      $$invalidate(2, wows_username = $channel2.wows_username);
      $$invalidate(3, wows_realm = $channel2.wows_realm);
    });
  });
  async function updateConfig() {
    set_store_value(channel, $channel = await $api.updateChannelConfig({ ...$channel, wows_username, wows_realm }), $channel);
  }
  async function createConfig() {
    set_store_value(
      channel,
      $channel = await $api.createChannelConfig({
        id: $channelId,
        wows_username,
        wows_realm,
        ships: []
      }),
      $channel
    );
  }
  async function updateShips({ detail: ships }) {
    set_store_value(channel, $channel.ships = ships, $channel);
  }
  function input_input_handler() {
    wows_username = this.value;
    $$invalidate(2, wows_username);
  }
  function select_change_handler() {
    wows_realm = select_value(this);
    $$invalidate(3, wows_realm);
  }
  function input_input_handler_1() {
    wows_username = this.value;
    $$invalidate(2, wows_username);
  }
  function select_change_handler_1() {
    wows_realm = select_value(this);
    $$invalidate(3, wows_realm);
  }
  return [
    loading,
    exists,
    wows_username,
    wows_realm,
    $channel,
    channel,
    updateConfig,
    createConfig,
    updateShips,
    input_input_handler,
    select_change_handler,
    input_input_handler_1,
    select_change_handler_1
  ];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
new App({
  target: document.getElementById("app")
});
