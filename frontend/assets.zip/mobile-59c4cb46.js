import { S as SvelteComponent, i as init, s as safe_not_equal, e as ensure_array_like, a as element, b as space, c as attr, t as toggle_class, d as insert, f as append, l as listen, g as transition_in, h as group_outros, j as transition_out, k as check_outros, m as detach, n as destroy_each, o as component_subscribe, p as api, q as binding_callbacks, u as bind, v as create_component, w as mount_component, x as add_flush_callback, y as add_render_callback, z as create_in_transition, A as create_out_transition, B as destroy_component, C as text, E as src_url_equal, D as set_data, M as set_store_value, I as onMount, K as warships, J as vote, L as writable, F as noop, H as empty } from "./app.js";
import "./appsignal.js";
import { S as ShipFilters, s as slide, h as handle_promise, u as update_await_block_branch, r as registerPubSubHandler } from "./pubsub.js";
import { N as Notification } from "./Notification.js";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[11] = list[i];
  return child_ctx;
}
function create_if_block$1(ctx) {
  let div;
  let shipfilters;
  let updating_filteredShips;
  let div_intro;
  let div_outro;
  let current;
  function shipfilters_filteredShips_binding(value) {
    ctx[7](value);
  }
  let shipfilters_props = { ships: (
    /*votedShips*/
    ctx[2].map(func)
  ) };
  if (
    /*filteredShips*/
    ctx[0] !== void 0
  ) {
    shipfilters_props.filteredShips = /*filteredShips*/
    ctx[0];
  }
  shipfilters = new ShipFilters({ props: shipfilters_props });
  binding_callbacks.push(() => bind(shipfilters, "filteredShips", shipfilters_filteredShips_binding));
  return {
    c() {
      div = element("div");
      create_component(shipfilters.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(shipfilters, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const shipfilters_changes = {};
      if (!updating_filteredShips && dirty & /*filteredShips*/
      1) {
        updating_filteredShips = true;
        shipfilters_changes.filteredShips = /*filteredShips*/
        ctx2[0];
        add_flush_callback(() => updating_filteredShips = false);
      }
      shipfilters.$set(shipfilters_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(shipfilters.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(shipfilters.$$.fragment, local);
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(shipfilters);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_each_block(ctx) {
  let button;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let span0;
  let t1_value = (
    /*ship*/
    ctx[11].name + ""
  );
  let t1;
  let t2;
  let span1;
  let t3_value = (
    /*votedShips*/
    ctx[2].find(func_1).votes + ""
  );
  let t3;
  let t4;
  let t5;
  let mounted;
  let dispose;
  function func_1(...args) {
    return (
      /*func_1*/
      ctx[8](
        /*ship*/
        ctx[11],
        ...args
      )
    );
  }
  function click_handler_1() {
    return (
      /*click_handler_1*/
      ctx[9](
        /*ship*/
        ctx[11]
      )
    );
  }
  return {
    c() {
      button = element("button");
      img = element("img");
      t0 = space();
      span0 = element("span");
      t1 = text(t1_value);
      t2 = space();
      span1 = element("span");
      t3 = text(t3_value);
      t4 = text("\n          votes");
      t5 = space();
      attr(img, "class", "w-auto h-8");
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[11].name);
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[11].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-md sm:text-lg truncate flex-grow text-left");
      attr(span1, "class", "text-md sm:text-lg text-cyan-400/50");
      attr(button, "class", "py-6 flex gap-4 items-end truncate");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, img);
      append(button, t0);
      append(button, span0);
      append(span0, t1);
      append(button, t2);
      append(button, span1);
      append(span1, t3);
      append(span1, t4);
      append(button, t5);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_1);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*filteredShips*/
      1 && img_alt_value !== (img_alt_value = /*ship*/
      ctx[11].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*filteredShips*/
      1 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx[11].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*ship*/
      ctx[11].name + ""))
        set_data(t1, t1_value);
      if (dirty & /*filteredShips*/
      1 && t3_value !== (t3_value = /*votedShips*/
      ctx[2].find(func_1).votes + ""))
        set_data(t3, t3_value);
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$1(ctx) {
  let div2;
  let div0;
  let h2;
  let t1;
  let button;
  let t4;
  let t5;
  let div1;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*showFilters*/
    ctx[1] && create_if_block$1(ctx)
  );
  let each_value = ensure_array_like(
    /*filteredShips*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      h2 = element("h2");
      h2.textContent = "Cast your vote";
      t1 = space();
      button = element("button");
      button.innerHTML = `<svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 01-.659 1.591l-5.432 5.432a2.25 2.25 0 00-.659 1.591v2.927a2.25 2.25 0 01-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 00-.659-1.591L3.659 7.409A2.25 2.25 0 013 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0112 3z"></path></svg> <span class="text-md">Filters</span>`;
      t4 = space();
      if (if_block)
        if_block.c();
      t5 = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(h2, "class", "text-xl font-bold flex-grow");
      attr(button, "class", "bg-cyan-800 rounded hover:bg-cyan-700 px-4 py-2 flex gap-2 items-center justify-center text-xl");
      toggle_class(
        button,
        "bg-cyan-700",
        /*showFilters*/
        ctx[1]
      );
      attr(div0, "class", "flex items-center justify-center gap-8");
      attr(div1, "class", "grid grid-cols-1 divide-y divide-cyan-800");
      attr(div2, "class", "flex flex-col gap-4 text-white");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div0, h2);
      append(div0, t1);
      append(div0, button);
      append(div2, t4);
      if (if_block)
        if_block.m(div2, null);
      append(div2, t5);
      append(div2, div1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[6]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*showFilters*/
      2) {
        toggle_class(
          button,
          "bg-cyan-700",
          /*showFilters*/
          ctx2[1]
        );
      }
      if (
        /*showFilters*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*showFilters*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div2, t5);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty & /*voteForShip, filteredShips, votedShips*/
      13) {
        each_value = ensure_array_like(
          /*filteredShips*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div1, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
const func = (vs) => vs.ship;
function instance$1($$self, $$props, $$invalidate) {
  let $api;
  component_subscribe($$self, api, ($$value) => $$invalidate(10, $api = $$value));
  let { vote: vote2 } = $$props;
  let { warships: warships2 } = $$props;
  let filteredShips = vote2.ships.map((id) => warships2[`${id}`]);
  let showFilters = false;
  const votedShips = vote2.ships.map((id) => ({
    ship: warships2[`${id}`],
    votes: vote2.votes[id] || 0
  }));
  async function voteForShip(ship) {
    await $api.voteForShip(vote2.id, ship.id);
  }
  const click_handler = () => $$invalidate(1, showFilters = !showFilters);
  function shipfilters_filteredShips_binding(value) {
    filteredShips = value;
    $$invalidate(0, filteredShips);
  }
  const func_1 = (ship, vs) => vs.ship.id === ship.id;
  const click_handler_1 = (ship) => voteForShip(ship);
  $$self.$$set = ($$props2) => {
    if ("vote" in $$props2)
      $$invalidate(4, vote2 = $$props2.vote);
    if ("warships" in $$props2)
      $$invalidate(5, warships2 = $$props2.warships);
  };
  return [
    filteredShips,
    showFilters,
    votedShips,
    voteForShip,
    vote2,
    warships2,
    click_handler,
    shipfilters_filteredShips_binding,
    func_1,
    click_handler_1
  ];
}
class VoteForShipMobile extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { vote: 4, warships: 5 });
  }
}
function create_catch_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_then_block(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$vote*/
      ctx2[0] && /*$vote*/
      ctx2[0].status === "open"
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block(ctx) {
  let notification;
  let current;
  notification = new Notification({
    props: {
      title: "No vote in progress",
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(notification.$$.fragment);
    },
    m(target, anchor) {
      mount_component(notification, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const notification_changes = {};
      if (dirty & /*$$scope*/
      32) {
        notification_changes.$$scope = { dirty, ctx: ctx2 };
      }
      notification.$set(notification_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(notification.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(notification.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(notification, detaching);
    }
  };
}
function create_if_block(ctx) {
  let voteforshipmobile;
  let current;
  voteforshipmobile = new VoteForShipMobile({
    props: {
      vote: (
        /*$vote*/
        ctx[0]
      ),
      warships: (
        /*$warships*/
        ctx[1]
      )
    }
  });
  return {
    c() {
      create_component(voteforshipmobile.$$.fragment);
    },
    m(target, anchor) {
      mount_component(voteforshipmobile, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const voteforshipmobile_changes = {};
      if (dirty & /*$vote*/
      1)
        voteforshipmobile_changes.vote = /*$vote*/
        ctx2[0];
      if (dirty & /*$warships*/
      2)
        voteforshipmobile_changes.warships = /*$warships*/
        ctx2[1];
      voteforshipmobile.$set(voteforshipmobile_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(voteforshipmobile.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(voteforshipmobile.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(voteforshipmobile, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let p;
  return {
    c() {
      p = element("p");
      p.textContent = "There is no vote in progress. Come back here when the streamer starts\n          a vote.";
    },
    m(target, anchor) {
      insert(target, p, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(p);
      }
    }
  };
}
function create_pending_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_fragment(ctx) {
  let div;
  let promise;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block,
    then: create_then_block,
    catch: create_catch_block,
    value: 1,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$warships*/
  ctx[1], info);
  return {
    c() {
      div = element("div");
      info.block.c();
      attr(div, "class", "bg-gray-900 min-h-screen p-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      info.block.m(div, info.anchor = null);
      info.mount = () => div;
      info.anchor = null;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$warships*/
      2 && promise !== (promise = /*$warships*/
      ctx[1]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      info.block.d();
      info.token = null;
      info = null;
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $channel;
  let $warships;
  let $vote;
  component_subscribe($$self, warships, ($$value) => $$invalidate(1, $warships = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(0, $vote = $$value));
  let channel = writable();
  component_subscribe($$self, channel, (value) => $$invalidate(3, $channel = value));
  api.subscribe(async ($api) => {
    if (!$api) {
      return;
    }
    set_store_value(channel, $channel = await $api.getChannelInfo(), $channel);
  });
  onMount(() => {
    registerPubSubHandler();
    return () => {
    };
  });
  return [$vote, $warships, channel];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
new App({
  target: document.getElementById("app")
});
