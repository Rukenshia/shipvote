import { S as SvelteComponent, i as init, s as safe_not_equal, e as ensure_array_like, a as element, b as space, c as attr, t as toggle_class, d as insert, f as append, l as listen, g as transition_in, h as group_outros, j as transition_out, k as check_outros, m as detach, n as destroy_each, r as run_all, o as component_subscribe, p as api, q as binding_callbacks, u as bind, v as create_component, w as mount_component, x as add_flush_callback, y as add_render_callback, z as create_in_transition, A as create_out_transition, B as destroy_component, C as text, D as set_data, E as src_url_equal, F as noop, G as derived, H as empty, I as onMount, J as vote, K as warships, L as writable, M as set_store_value } from "./app.js";
import { S as ShipFilters, s as slide, h as handle_promise, u as update_await_block_branch, r as registerPubSubHandler, a as scale } from "./pubsub.js";
import { C as CreatorBanner } from "./CreatorBanner.js";
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[13] = list[i][0];
  child_ctx[14] = list[i][1];
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[17] = list[i];
  return child_ctx;
}
function create_if_block$1(ctx) {
  let div;
  let shipfilters;
  let updating_filteredShips;
  let div_intro;
  let div_outro;
  let current;
  function shipfilters_filteredShips_binding(value) {
    ctx[10](value);
  }
  let shipfilters_props = { ships: (
    /*votedShips*/
    ctx[4].map(func)
  ) };
  if (
    /*filteredShips*/
    ctx[1] !== void 0
  ) {
    shipfilters_props.filteredShips = /*filteredShips*/
    ctx[1];
  }
  shipfilters = new ShipFilters({ props: shipfilters_props });
  binding_callbacks.push(() => bind(shipfilters, "filteredShips", shipfilters_filteredShips_binding));
  return {
    c() {
      div = element("div");
      create_component(shipfilters.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(shipfilters, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const shipfilters_changes = {};
      if (!updating_filteredShips && dirty & /*filteredShips*/
      2) {
        updating_filteredShips = true;
        shipfilters_changes.filteredShips = /*filteredShips*/
        ctx2[1];
        add_flush_callback(() => updating_filteredShips = false);
      }
      shipfilters.$set(shipfilters_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(shipfilters.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(shipfilters.$$.fragment, local);
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(shipfilters);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_each_block_1(ctx) {
  let button;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let span;
  let t1_value = (
    /*ship*/
    ctx[17].name + ""
  );
  let t1;
  let mounted;
  let dispose;
  function click_handler_2() {
    return (
      /*click_handler_2*/
      ctx[11](
        /*ship*/
        ctx[17]
      )
    );
  }
  return {
    c() {
      button = element("button");
      img = element("img");
      t0 = space();
      span = element("span");
      t1 = text(t1_value);
      attr(img, "class", "w-auto h-6");
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[17].name);
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[17].image))
        attr(img, "src", img_src_value);
      attr(span, "class", "text-xs sm:text-sm flex-grow truncate");
      attr(button, "class", "flex bg-cyan-700 hover:bg-cyan-600 rounded pr-2 pb-1 items-end truncate min-w-min transition-colors");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, img);
      append(button, t0);
      append(button, span);
      append(span, t1);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_2);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*shipsByTier*/
      4 && img_alt_value !== (img_alt_value = /*ship*/
      ctx[17].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*shipsByTier*/
      4 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx[17].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*shipsByTier*/
      4 && t1_value !== (t1_value = /*ship*/
      ctx[17].name + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_each_block$1(ctx) {
  let div;
  let span1;
  let t0;
  let t1_value = romanize(
    /*tier*/
    ctx[13]
  ) + "";
  let t1;
  let t2;
  let span0;
  let t3;
  let t4;
  let each_value_1 = ensure_array_like(
    /*ships*/
    ctx[14]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  return {
    c() {
      div = element("div");
      span1 = element("span");
      t0 = text("Tier ");
      t1 = text(t1_value);
      t2 = space();
      span0 = element("span");
      t3 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t4 = space();
      attr(span0, "class", "border-t flex-grow");
      attr(span1, "class", "col-span-full text-xs font-bold flex items-center gap-2 text-cyan-100");
      attr(div, "class", "grid grid-cols-4 sm:grid-cols-4 lg:grid-cols-4 gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, span1);
      append(span1, t0);
      append(span1, t1);
      append(span1, t2);
      append(span1, span0);
      append(div, t3);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      append(div, t4);
    },
    p(ctx2, dirty) {
      if (dirty & /*shipsByTier*/
      4 && t1_value !== (t1_value = romanize(
        /*tier*/
        ctx2[13]
      ) + ""))
        set_data(t1, t1_value);
      if (dirty & /*voteForShip, shipsByTier*/
      36) {
        each_value_1 = ensure_array_like(
          /*ships*/
          ctx2[14]
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, t4);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value_1.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let div2;
  let div1;
  let h2;
  let t1;
  let button0;
  let t4;
  let div0;
  let t5;
  let button1;
  let t6;
  let t7;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*showFilters*/
    ctx[3] && create_if_block$1(ctx)
  );
  let each_value = ensure_array_like(
    /*shipsByTier*/
    ctx[2].entries()
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      div2 = element("div");
      div1 = element("div");
      h2 = element("h2");
      h2.textContent = "Cast your vote";
      t1 = space();
      button0 = element("button");
      button0.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 01-.659 1.591l-5.432 5.432a2.25 2.25 0 00-.659 1.591v2.927a2.25 2.25 0 01-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 00-.659-1.591L3.659 7.409A2.25 2.25 0 013 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0112 3z"></path></svg> <span class="text-md">Filters</span>`;
      t4 = space();
      div0 = element("div");
      t5 = space();
      button1 = element("button");
      button1.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>`;
      t6 = space();
      if (if_block)
        if_block.c();
      t7 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(h2, "class", "text-lg font-bold");
      attr(button0, "class", "bg-cyan-700 rounded hover:bg-cyan-600 px-2 py-0.5 flex gap-2 items-center");
      toggle_class(
        button0,
        "bg-cyan-600",
        /*showFilters*/
        ctx[3]
      );
      attr(div0, "class", "flex-grow");
      attr(button1, "class", "bg-cyan-700 rounded hover:bg-cyan-600 px-2 py-0.5 flex items-center");
      attr(div1, "class", "flex gap-4");
      attr(div2, "class", "flex flex-col gap-4 pr-4");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div1);
      append(div1, h2);
      append(div1, t1);
      append(div1, button0);
      append(div1, t4);
      append(div1, div0);
      append(div1, t5);
      append(div1, button1);
      append(div2, t6);
      if (if_block)
        if_block.m(div2, null);
      append(div2, t7);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div2, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            button0,
            "click",
            /*click_handler*/
            ctx[8]
          ),
          listen(
            button1,
            "click",
            /*click_handler_1*/
            ctx[9]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*showFilters*/
      8) {
        toggle_class(
          button0,
          "bg-cyan-600",
          /*showFilters*/
          ctx2[3]
        );
      }
      if (
        /*showFilters*/
        ctx2[3]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*showFilters*/
          8) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div2, t7);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (dirty & /*shipsByTier, voteForShip, romanize*/
      36) {
        each_value = ensure_array_like(
          /*shipsByTier*/
          ctx2[2].entries()
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div2, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
function romanize(tier) {
  return "I II III IV V VI VII VIII IX X".split(" ")[tier - 1];
}
const func = (vs) => vs.ship;
function instance$2($$self, $$props, $$invalidate) {
  let $api;
  component_subscribe($$self, api, ($$value) => $$invalidate(12, $api = $$value));
  let { vote: vote2 } = $$props;
  let { warships: warships2 } = $$props;
  let { close } = $$props;
  let filteredShips = vote2.ships.map((id) => warships2[`${id}`]);
  let showFilters = false;
  let shipsByTier = /* @__PURE__ */ new Map();
  const votedShips = vote2.ships.map((id) => ({
    ship: warships2[`${id}`],
    votes: vote2.votes[id] || 0
  }));
  async function voteForShip(ship) {
    close();
    await $api.voteForShip(vote2.id, ship.id);
  }
  const click_handler = () => $$invalidate(3, showFilters = !showFilters);
  const click_handler_1 = () => close();
  function shipfilters_filteredShips_binding(value) {
    filteredShips = value;
    $$invalidate(1, filteredShips);
  }
  const click_handler_2 = (ship) => voteForShip(ship);
  $$self.$$set = ($$props2) => {
    if ("vote" in $$props2)
      $$invalidate(6, vote2 = $$props2.vote);
    if ("warships" in $$props2)
      $$invalidate(7, warships2 = $$props2.warships);
    if ("close" in $$props2)
      $$invalidate(0, close = $$props2.close);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*filteredShips, shipsByTier*/
    6) {
      {
        $$invalidate(2, shipsByTier = /* @__PURE__ */ new Map());
        filteredShips.forEach((ship) => {
          if (!shipsByTier.has(ship.tier)) {
            shipsByTier.set(ship.tier, []);
          }
          shipsByTier.get(ship.tier).push(ship);
        });
        $$invalidate(2, shipsByTier = new Map([...shipsByTier.entries()].sort((a, b) => a[0] - b[0])));
      }
    }
  };
  return [
    close,
    filteredShips,
    shipsByTier,
    showFilters,
    votedShips,
    voteForShip,
    vote2,
    warships2,
    click_handler,
    click_handler_1,
    shipfilters_filteredShips_binding,
    click_handler_2
  ];
}
class VoteForShip extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { vote: 6, warships: 7, close: 0 });
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[4] = list[i];
  return child_ctx;
}
function create_each_block(ctx) {
  let div2;
  let img;
  let img_src_value;
  let img_alt_value;
  let t0;
  let div0;
  let t1_value = (
    /*votedShip*/
    ctx[4].ship.name + ""
  );
  let t1;
  let t2;
  let div1;
  let t3_value = (
    /*votedShip*/
    ctx[4].votes + ""
  );
  let t3;
  let t4;
  return {
    c() {
      div2 = element("div");
      img = element("img");
      t0 = space();
      div0 = element("div");
      t1 = text(t1_value);
      t2 = space();
      div1 = element("div");
      t3 = text(t3_value);
      t4 = space();
      if (!src_url_equal(img.src, img_src_value = /*votedShip*/
      ctx[4].ship.image))
        attr(img, "src", img_src_value);
      attr(img, "alt", img_alt_value = /*votedShip*/
      ctx[4].ship.name);
      attr(img, "class", "h-6");
      attr(div0, "class", "flex-grow");
      attr(div1, "class", "text-cyan-200");
      attr(div2, "class", "bg-cyan-900/80 rounded pr-2 py-0.5 text-cyan-100 flex items-center gap-2 text-md");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, img);
      append(div2, t0);
      append(div2, div0);
      append(div0, t1);
      append(div2, t2);
      append(div2, div1);
      append(div1, t3);
      append(div2, t4);
    },
    p(ctx2, dirty) {
      if (dirty & /*$topThreeShips*/
      1 && !src_url_equal(img.src, img_src_value = /*votedShip*/
      ctx2[4].ship.image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$topThreeShips*/
      1 && img_alt_value !== (img_alt_value = /*votedShip*/
      ctx2[4].ship.name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*$topThreeShips*/
      1 && t1_value !== (t1_value = /*votedShip*/
      ctx2[4].ship.name + ""))
        set_data(t1, t1_value);
      if (dirty & /*$topThreeShips*/
      1 && t3_value !== (t3_value = /*votedShip*/
      ctx2[4].votes + ""))
        set_data(t3, t3_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let each_value = ensure_array_like(
    /*$topThreeShips*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "flex flex-col");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*$topThreeShips*/
      1) {
        each_value = ensure_array_like(
          /*$topThreeShips*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let $topThreeShips;
  let { vote: vote2 } = $$props;
  let { warships: warships2 } = $$props;
  let topThreeShips = derived(
    vote2,
    ($vote) => {
      if (!$vote || !$vote.votes) {
        return [];
      }
      return Object.entries($vote.votes).sort(([_, a], [__, b]) => b - a).slice(0, 3).map(([id, votes]) => {
        return { ship: warships2[`${id}`], votes };
      });
    },
    []
  );
  component_subscribe($$self, topThreeShips, (value) => $$invalidate(0, $topThreeShips = value));
  $$self.$$set = ($$props2) => {
    if ("vote" in $$props2)
      $$invalidate(2, vote2 = $$props2.vote);
    if ("warships" in $$props2)
      $$invalidate(3, warships2 = $$props2.warships);
  };
  return [$topThreeShips, topThreeShips, vote2, warships2];
}
class VoteProgressOverlay extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { vote: 2, warships: 3 });
  }
}
function create_catch_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_then_block(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$vote*/
    ctx[1] && create_if_block(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block(ctx) {
  let if_block_anchor;
  let current;
  let if_block = (
    /*$vote*/
    ctx[1].status === "open" && create_if_block_1(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (
        /*$vote*/
        ctx2[1].status === "open"
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$vote*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let div;
  let voteprogressoverlay;
  let t;
  let if_block_anchor;
  let current;
  voteprogressoverlay = new VoteProgressOverlay({
    props: { vote, warships: (
      /*$warships*/
      ctx[2]
    ) }
  });
  let if_block = !/*hidden*/
  ctx[0] && create_if_block_2(ctx);
  return {
    c() {
      div = element("div");
      create_component(voteprogressoverlay.$$.fragment);
      t = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(div, "class", "fixed left-0 top-0");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(voteprogressoverlay, div, null);
      insert(target, t, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const voteprogressoverlay_changes = {};
      if (dirty & /*$warships*/
      4)
        voteprogressoverlay_changes.warships = /*$warships*/
        ctx2[2];
      voteprogressoverlay.$set(voteprogressoverlay_changes);
      if (!/*hidden*/
      ctx2[0]) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*hidden*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block_2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(voteprogressoverlay.$$.fragment, local);
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(voteprogressoverlay.$$.fragment, local);
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t);
        detach(if_block_anchor);
      }
      destroy_component(voteprogressoverlay);
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let div5;
  let div4;
  let div2;
  let div1;
  let voteforship;
  let t0;
  let div0;
  let creatorbanner;
  let t1;
  let div3;
  let div5_intro;
  let div5_outro;
  let current;
  voteforship = new VoteForShip({
    props: {
      vote: (
        /*$vote*/
        ctx[1]
      ),
      warships: (
        /*$warships*/
        ctx[2]
      ),
      close: (
        /*func*/
        ctx[4]
      )
    }
  });
  creatorbanner = new CreatorBanner({});
  return {
    c() {
      div5 = element("div");
      div4 = element("div");
      div2 = element("div");
      div1 = element("div");
      create_component(voteforship.$$.fragment);
      t0 = space();
      div0 = element("div");
      create_component(creatorbanner.$$.fragment);
      t1 = space();
      div3 = element("div");
      attr(div0, "class", "opacity-50 mt-4 bg-cyan-950 px-2 py-1 text-xs rounded-lg");
      attr(div1, "class", "max-h-64 overflow-y-auto");
      attr(div2, "class", "h-full z-20 p-4 pt-2 relative bg-gradient-to-b from-cyan-800 to-cyan-950 rounded-xl opacity-80 hover:opacity-100 transition-all duration-300");
      attr(div3, "class", "absolute -inset-1 rounded-md blur-md bg-gradient-to-br from-blue-500/50 via-sky-800/60 to-cyan-600/50 z-10");
      attr(div4, "class", "relative max-w-2xl w-full text-white");
      attr(div5, "class", "h-full flex items-center justify-center py-16 overflow-hidden");
    },
    m(target, anchor) {
      insert(target, div5, anchor);
      append(div5, div4);
      append(div4, div2);
      append(div2, div1);
      mount_component(voteforship, div1, null);
      append(div1, t0);
      append(div1, div0);
      mount_component(creatorbanner, div0, null);
      append(div4, t1);
      append(div4, div3);
      current = true;
    },
    p(ctx2, dirty) {
      const voteforship_changes = {};
      if (dirty & /*$vote*/
      2)
        voteforship_changes.vote = /*$vote*/
        ctx2[1];
      if (dirty & /*$warships*/
      4)
        voteforship_changes.warships = /*$warships*/
        ctx2[2];
      if (dirty & /*hidden*/
      1)
        voteforship_changes.close = /*func*/
        ctx2[4];
      voteforship.$set(voteforship_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(voteforship.$$.fragment, local);
      transition_in(creatorbanner.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div5_outro)
            div5_outro.end(1);
          div5_intro = create_in_transition(div5, scale, { duration: 300 });
          div5_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(voteforship.$$.fragment, local);
      transition_out(creatorbanner.$$.fragment, local);
      if (div5_intro)
        div5_intro.invalidate();
      if (local) {
        div5_outro = create_out_transition(div5, scale, { duration: 300 });
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div5);
      }
      destroy_component(voteforship);
      destroy_component(creatorbanner);
      if (detaching && div5_outro)
        div5_outro.end();
    }
  };
}
function create_pending_block(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_fragment(ctx) {
  let await_block_anchor;
  let promise;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block,
    then: create_then_block,
    catch: create_catch_block,
    value: 2,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$warships*/
  ctx[2], info);
  return {
    c() {
      await_block_anchor = empty();
      info.block.c();
    },
    m(target, anchor) {
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$warships*/
      4 && promise !== (promise = /*$warships*/
      ctx[2]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(await_block_anchor);
      }
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $api;
  let $channel;
  let $warships;
  let $vote;
  component_subscribe($$self, api, ($$value) => $$invalidate(5, $api = $$value));
  component_subscribe($$self, warships, ($$value) => $$invalidate(2, $warships = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(1, $vote = $$value));
  let channel = writable();
  component_subscribe($$self, channel, (value) => $$invalidate(6, $channel = value));
  let hidden = false;
  onMount(() => {
    registerPubSubHandler();
    window.Twitch.ext.onContext(async (data, changed) => {
      if (data.game !== "World of Warships") {
        console.log("game is not WoWS");
        return;
      }
      if (!$channel) {
        console.info("Starting Shipvote session");
        if (!$api) {
          console.error("Game is WoWS, but API is not available");
          return;
        }
        set_store_value(channel, $channel = await $api.getChannelInfo(), $channel);
      }
    });
    return () => {
    };
  });
  vote.subscribe(($vote2) => {
    if (!$vote2) {
      $$invalidate(0, hidden = false);
    }
  });
  const func2 = () => $$invalidate(0, hidden = true);
  return [hidden, $vote, $warships, channel, func2];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
const main = "";
new App({
  target: document.getElementById("app")
});
