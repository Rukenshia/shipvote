import { S as SvelteComponent, i as init, s as safe_not_equal, C as text, d as insert, E as noop, m as detach, a as element, b as space, c as attr, f as append, I as onMount, J as onDestroy, D as set_data } from "./app.js";
function create_fragment$1(ctx) {
  let t0;
  let t1_value = "3.1.0";
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Shipvote Extension v");
      t1 = text(t1_value);
      t2 = text(" · made by Rukenshia\n(Discord: Rukenshia#4396)");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
class CreatorBanner extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$1, safe_not_equal, {});
  }
}
function create_else_block(ctx) {
  let span0;
  let t1;
  let span1;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*remaining_minutes*/
      ctx2[1] > 0
    )
      return create_if_block_1;
    return create_else_block_1;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      span0 = element("span");
      span0.textContent = "Vote ends in";
      t1 = space();
      span1 = element("span");
      if_block.c();
      attr(span0, "class", "font-medium");
      attr(span1, "class", "trim");
    },
    m(target, anchor) {
      insert(target, span0, anchor);
      insert(target, t1, anchor);
      insert(target, span1, anchor);
      if_block.m(span1, null);
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_1(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(span1, null);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(span0);
        detach(t1);
        detach(span1);
      }
      if_block.d();
    }
  };
}
function create_if_block(ctx) {
  let span;
  return {
    c() {
      span = element("span");
      span.textContent = "Closing vote...";
      attr(span, "class", "font-medium text-cyan-500");
    },
    m(target, anchor) {
      insert(target, span, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(span);
      }
    }
  };
}
function create_else_block_1(ctx) {
  let t0_value = (
    /*remaining_seconds*/
    ctx[2] % 60 + ""
  );
  let t0;
  let t1;
  return {
    c() {
      t0 = text(t0_value);
      t1 = text(" seconds");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*remaining_seconds*/
      4 && t0_value !== (t0_value = /*remaining_seconds*/
      ctx2[2] % 60 + ""))
        set_data(t0, t0_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let t0;
  let t1;
  return {
    c() {
      t0 = text(
        /*remaining_minutes*/
        ctx[1]
      );
      t1 = text(" minutes");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*remaining_minutes*/
      2)
        set_data(
          t0,
          /*remaining_minutes*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_fragment(ctx) {
  let div3;
  let div1;
  let div0;
  let div0_style_value;
  let t;
  let div2;
  let div2_class_value;
  function select_block_type(ctx2, dirty) {
    if (
      /*closing*/
      ctx2[3]
    )
      return create_if_block;
    return create_else_block;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div3 = element("div");
      div1 = element("div");
      div0 = element("div");
      t = space();
      div2 = element("div");
      if_block.c();
      attr(div0, "style", div0_style_value = `width: ${/*width*/
      ctx[4]}%;`);
      attr(div0, "class", "h-full rounded bg-cyan-500/10 transition-all duration-[1500ms]");
      attr(div1, "class", "absolute z-0 h-full w-full");
      attr(div2, "class", div2_class_value = `z-10 p-4 py-${/*vertical_padding*/
      ctx[0]}`);
      attr(div3, "class", "relative flex h-full justify-start rounded-md bg-gray-200/5 text-sm text-gray-100/80 shadow-inner");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, div1);
      append(div1, div0);
      append(div3, t);
      append(div3, div2);
      if_block.m(div2, null);
    },
    p(ctx2, [dirty]) {
      if (dirty & /*width*/
      16 && div0_style_value !== (div0_style_value = `width: ${/*width*/
      ctx2[4]}%;`)) {
        attr(div0, "style", div0_style_value);
      }
      if (current_block_type === (current_block_type = select_block_type(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(div2, null);
        }
      }
      if (dirty & /*vertical_padding*/
      1 && div2_class_value !== (div2_class_value = `z-10 p-4 py-${/*vertical_padding*/
      ctx2[0]}`)) {
        attr(div2, "class", div2_class_value);
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      if_block.d();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { started_at } = $$props;
  let { ends_at } = $$props;
  let { vertical_padding = 2 } = $$props;
  let remaining_minutes = 0;
  let remaining_seconds = 0;
  let closing = false;
  const started_at_date = new Date(started_at);
  const ends_at_date = new Date(ends_at);
  const total_seconds = Math.floor((ends_at_date.getTime() - started_at_date.getTime()) / 1e3);
  let width = 0;
  let intv;
  onMount(() => {
    if (!ends_at)
      return;
    const calculateRemainingTime = () => {
      const elapsed_seconds = Math.floor((Date.now() - started_at_date.getTime()) / 1e3);
      $$invalidate(4, width = elapsed_seconds / total_seconds * 100);
      $$invalidate(1, remaining_minutes = Math.floor((ends_at_date.getTime() - Date.now()) / 1e3 / 60));
      $$invalidate(2, remaining_seconds = Math.floor((ends_at_date.getTime() - Date.now()) / 1e3));
      if (remaining_seconds <= 0 && remaining_minutes <= 0) {
        $$invalidate(3, closing = true);
        if (intv) {
          clearInterval(intv);
        }
      }
    };
    intv = setInterval(calculateRemainingTime, 1e3);
    calculateRemainingTime();
  });
  onDestroy(() => {
    if (intv) {
      clearInterval(intv);
    }
  });
  $$self.$$set = ($$props2) => {
    if ("started_at" in $$props2)
      $$invalidate(5, started_at = $$props2.started_at);
    if ("ends_at" in $$props2)
      $$invalidate(6, ends_at = $$props2.ends_at);
    if ("vertical_padding" in $$props2)
      $$invalidate(0, vertical_padding = $$props2.vertical_padding);
  };
  return [
    vertical_padding,
    remaining_minutes,
    remaining_seconds,
    closing,
    width,
    started_at,
    ends_at
  ];
}
class RemainingVoteTime extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {
      started_at: 5,
      ends_at: 6,
      vertical_padding: 0
    });
  }
}
export {
  CreatorBanner as C,
  RemainingVoteTime as R
};
