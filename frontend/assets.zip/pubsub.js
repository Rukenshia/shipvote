var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { a0 as is_promise, a1 as get_current_component, a2 as set_current_component, g as group_outros, h as transition_out, j as check_outros, k as transition_in, a3 as flush, S as SvelteComponent, i as init, s as safe_not_equal, W as create_slot, e as ensure_array_like, a as element, b as space, c as attr, y as add_render_callback, d as insert, f as append, U as select_option, l as listen, X as update_slot_base, Y as get_all_dirty_from_scope, Z as get_slot_changes, m as detach, n as destroy_each, C as text, Q as set_input_value, E as noop, T as select_value, q as binding_callbacks, u as bind, $ as svg_element, v as create_component, t as toggle_class, w as mount_component, x as add_flush_callback, B as destroy_component, r as run_all, a4 as get_store_value, K as vote, p as api } from "./app.js";
function handle_promise(promise, info) {
  const token = info.token = {};
  function update(type, index, key, value) {
    if (info.token !== token)
      return;
    info.resolved = value;
    let child_ctx = info.ctx;
    if (key !== void 0) {
      child_ctx = child_ctx.slice();
      child_ctx[key] = value;
    }
    const block = type && (info.current = type)(child_ctx);
    let needs_flush = false;
    if (info.block) {
      if (info.blocks) {
        info.blocks.forEach((block2, i) => {
          if (i !== index && block2) {
            group_outros();
            transition_out(block2, 1, 1, () => {
              if (info.blocks[i] === block2) {
                info.blocks[i] = null;
              }
            });
            check_outros();
          }
        });
      } else {
        info.block.d(1);
      }
      block.c();
      transition_in(block, 1);
      block.m(info.mount(), info.anchor);
      needs_flush = true;
    }
    info.block = block;
    if (info.blocks)
      info.blocks[index] = block;
    if (needs_flush) {
      flush();
    }
  }
  if (is_promise(promise)) {
    const current_component = get_current_component();
    promise.then(
      (value) => {
        set_current_component(current_component);
        update(info.then, 1, info.value, value);
        set_current_component(null);
      },
      (error) => {
        set_current_component(current_component);
        update(info.catch, 2, info.error, error);
        set_current_component(null);
        if (!info.hasCatch) {
          throw error;
        }
      }
    );
    if (info.current !== info.pending) {
      update(info.pending, 0);
      return true;
    }
  } else {
    if (info.current !== info.then) {
      update(info.then, 1, info.value, promise);
      return true;
    }
    info.resolved = /** @type {T} */
    promise;
  }
}
function update_await_block_branch(info, ctx, dirty) {
  const child_ctx = ctx.slice();
  const { resolved } = info;
  if (info.current === info.then) {
    child_ctx[info.value] = resolved;
  }
  if (info.current === info.catch) {
    child_ctx[info.error] = resolved;
  }
  info.block.p(child_ctx, dirty);
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[7] = list[i];
  return child_ctx;
}
function create_each_block(ctx) {
  let option_1;
  let t_value = (
    /*option*/
    ctx[7] + ""
  );
  let t;
  return {
    c() {
      option_1 = element("option");
      t = text(t_value);
      option_1.__value = /*option*/
      ctx[7];
      set_input_value(option_1, option_1.__value);
    },
    m(target, anchor) {
      insert(target, option_1, anchor);
      append(option_1, t);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(option_1);
      }
    }
  };
}
function create_fragment$1(ctx) {
  let div;
  let label;
  let t;
  let select;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[5].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  let each_value = ensure_array_like(
    /*allOptions*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      label = element("label");
      if (default_slot)
        default_slot.c();
      t = space();
      select = element("select");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(
        label,
        "for",
        /*name*/
        ctx[1]
      );
      attr(label, "class", "block text-sm font-medium text-cyan-100");
      attr(
        select,
        "id",
        /*name*/
        ctx[1]
      );
      attr(
        select,
        "name",
        /*name*/
        ctx[1]
      );
      attr(select, "class", "mt-1 block w-full pl-3 pr-10 py-2 text-base border-cyan-600 bg-cyan-700 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md");
      if (
        /*value*/
        ctx[0] === void 0
      )
        add_render_callback(() => (
          /*select_change_handler*/
          ctx[6].call(select)
        ));
      attr(div, "class", "flex-auto");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, label);
      if (default_slot) {
        default_slot.m(label, null);
      }
      append(div, t);
      append(div, select);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(select, null);
        }
      }
      select_option(
        select,
        /*value*/
        ctx[0],
        true
      );
      current = true;
      if (!mounted) {
        dispose = listen(
          select,
          "change",
          /*select_change_handler*/
          ctx[6]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*name*/
      2) {
        attr(
          label,
          "for",
          /*name*/
          ctx2[1]
        );
      }
      if (dirty & /*allOptions*/
      4) {
        each_value = ensure_array_like(
          /*allOptions*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(select, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      if (!current || dirty & /*name*/
      2) {
        attr(
          select,
          "id",
          /*name*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*name*/
      2) {
        attr(
          select,
          "name",
          /*name*/
          ctx2[1]
        );
      }
      if (dirty & /*value, allOptions*/
      5) {
        select_option(
          select,
          /*value*/
          ctx2[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { name } = $$props;
  let { options } = $$props;
  let allOptions = ["all", ...options];
  let { value = allOptions[0] } = $$props;
  function select_change_handler() {
    value = select_value(this);
    $$invalidate(0, value);
    $$invalidate(2, allOptions);
  }
  $$self.$$set = ($$props2) => {
    if ("name" in $$props2)
      $$invalidate(1, name = $$props2.name);
    if ("options" in $$props2)
      $$invalidate(3, options = $$props2.options);
    if ("value" in $$props2)
      $$invalidate(0, value = $$props2.value);
    if ("$$scope" in $$props2)
      $$invalidate(4, $$scope = $$props2.$$scope);
  };
  return [value, name, allOptions, options, $$scope, slots, select_change_handler];
}
class Filter extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { name: 1, options: 3, value: 0 });
  }
}
function create_default_slot_2(ctx) {
  let t;
  return {
    c() {
      t = text("Nations");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_1(ctx) {
  let t;
  return {
    c() {
      t = text("Tier");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot(ctx) {
  let t;
  return {
    c() {
      t = text("Class");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment(ctx) {
  let div5;
  let div0;
  let h2;
  let t1;
  let button;
  let svg0;
  let path0;
  let button_disabled_value;
  let t2;
  let div4;
  let div1;
  let filter0;
  let updating_value;
  let t3;
  let filter1;
  let updating_value_1;
  let t4;
  let filter2;
  let updating_value_2;
  let t5;
  let div3;
  let input;
  let t6;
  let div2;
  let current;
  let mounted;
  let dispose;
  function filter0_value_binding(value) {
    ctx[11](value);
  }
  let filter0_props = {
    name: "nations",
    options: (
      /*nations*/
      ctx[5]
    ),
    $$slots: { default: [create_default_slot_2] },
    $$scope: { ctx }
  };
  if (
    /*selectedNation*/
    ctx[0] !== void 0
  ) {
    filter0_props.value = /*selectedNation*/
    ctx[0];
  }
  filter0 = new Filter({ props: filter0_props });
  binding_callbacks.push(() => bind(filter0, "value", filter0_value_binding));
  function filter1_value_binding(value) {
    ctx[12](value);
  }
  let filter1_props = {
    name: "tiers",
    options: (
      /*tiers*/
      ctx[6]
    ),
    $$slots: { default: [create_default_slot_1] },
    $$scope: { ctx }
  };
  if (
    /*selectedTier*/
    ctx[1] !== void 0
  ) {
    filter1_props.value = /*selectedTier*/
    ctx[1];
  }
  filter1 = new Filter({ props: filter1_props });
  binding_callbacks.push(() => bind(filter1, "value", filter1_value_binding));
  function filter2_value_binding(value) {
    ctx[13](value);
  }
  let filter2_props = {
    name: "types",
    options: (
      /*types*/
      ctx[7]
    ),
    $$slots: { default: [create_default_slot] },
    $$scope: { ctx }
  };
  if (
    /*selectedType*/
    ctx[2] !== void 0
  ) {
    filter2_props.value = /*selectedType*/
    ctx[2];
  }
  filter2 = new Filter({ props: filter2_props });
  binding_callbacks.push(() => bind(filter2, "value", filter2_value_binding));
  return {
    c() {
      div5 = element("div");
      div0 = element("div");
      h2 = element("h2");
      h2.textContent = "Filters";
      t1 = space();
      button = element("button");
      svg0 = svg_element("svg");
      path0 = svg_element("path");
      t2 = space();
      div4 = element("div");
      div1 = element("div");
      create_component(filter0.$$.fragment);
      t3 = space();
      create_component(filter1.$$.fragment);
      t4 = space();
      create_component(filter2.$$.fragment);
      t5 = space();
      div3 = element("div");
      input = element("input");
      t6 = space();
      div2 = element("div");
      div2.innerHTML = `<svg class="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>`;
      attr(h2, "class", "text-cyan-100 text-xl font-medium");
      attr(path0, "xmlns", "http://www.w3.org/2000/svg");
      attr(path0, "d", "M12.2071 2.29289C12.5976 2.68342 12.5976 3.31658 12.2071 3.70711L10.9142 5H12.5C17.1523 5 21 8.84772 21 13.5C21 18.1523 17.1523 22 12.5 22C7.84772 22 4 18.1523 4 13.5C4 12.9477 4.44772 12.5 5 12.5C5.55228 12.5 6 12.9477 6 13.5C6 17.0477 8.95228 20 12.5 20C16.0477 20 19 17.0477 19 13.5C19 9.95228 16.0477 7 12.5 7H10.9142L12.2071 8.29289C12.5976 8.68342 12.5976 9.31658 12.2071 9.70711C11.8166 10.0976 11.1834 10.0976 10.7929 9.70711L7.79289 6.70711C7.40237 6.31658 7.40237 5.68342 7.79289 5.29289L10.7929 2.29289C11.1834 1.90237 11.8166 1.90237 12.2071 2.29289Z");
      attr(path0, "fill", "currentColor");
      attr(svg0, "class", "h-6 w-6");
      attr(svg0, "fill", "inherit");
      attr(svg0, "viewBox", "0 0 24 24");
      attr(svg0, "xmlns", "http://www.w3.org/2000/svg");
      attr(button, "class", "text-xs drop-shadow-sm transition font-medium py-0.5 px-1 rounded");
      button.disabled = button_disabled_value = !/*changed*/
      ctx[4];
      toggle_class(button, "text-cyan-600", !/*changed*/
      ctx[4]);
      toggle_class(
        button,
        "text-cyan-300",
        /*changed*/
        ctx[4]
      );
      toggle_class(
        button,
        "bg-cyan-600",
        /*changed*/
        ctx[4]
      );
      toggle_class(button, "bg-cyan-950", !/*changed*/
      ctx[4]);
      toggle_class(
        button,
        "hover:bg-cyan-700",
        /*changed*/
        ctx[4]
      );
      attr(div0, "class", "flex items-center gap-2");
      attr(div1, "class", "flex gap-2");
      attr(input, "type", "text");
      attr(input, "name", "ship_name");
      attr(input, "class", "bg-cyan-700 shadow-sm focus:ring-cyan-500 focus:border-cyan-500 block w-full sm:text-sm border-cyan-500 rounded-md placeholder-cyan-300/50 px-4 py-2");
      attr(input, "placeholder", "Name");
      attr(div2, "class", "absolute flex items-center inset-y-0 right-0 pr-3");
      attr(div3, "class", "relative");
      attr(div4, "class", "flex flex-col gap-2");
      attr(div5, "class", "flex flex-col gap-2");
    },
    m(target, anchor) {
      insert(target, div5, anchor);
      append(div5, div0);
      append(div0, h2);
      append(div0, t1);
      append(div0, button);
      append(button, svg0);
      append(svg0, path0);
      append(div5, t2);
      append(div5, div4);
      append(div4, div1);
      mount_component(filter0, div1, null);
      append(div1, t3);
      mount_component(filter1, div1, null);
      append(div1, t4);
      mount_component(filter2, div1, null);
      append(div4, t5);
      append(div4, div3);
      append(div3, input);
      set_input_value(
        input,
        /*shipName*/
        ctx[3]
      );
      append(div3, t6);
      append(div3, div2);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            button,
            "click",
            /*resetAllFilters*/
            ctx[8]
          ),
          listen(
            input,
            "input",
            /*input_input_handler*/
            ctx[14]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (!current || dirty & /*changed*/
      16 && button_disabled_value !== (button_disabled_value = !/*changed*/
      ctx2[4])) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*changed*/
      16) {
        toggle_class(button, "text-cyan-600", !/*changed*/
        ctx2[4]);
      }
      if (!current || dirty & /*changed*/
      16) {
        toggle_class(
          button,
          "text-cyan-300",
          /*changed*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*changed*/
      16) {
        toggle_class(
          button,
          "bg-cyan-600",
          /*changed*/
          ctx2[4]
        );
      }
      if (!current || dirty & /*changed*/
      16) {
        toggle_class(button, "bg-cyan-950", !/*changed*/
        ctx2[4]);
      }
      if (!current || dirty & /*changed*/
      16) {
        toggle_class(
          button,
          "hover:bg-cyan-700",
          /*changed*/
          ctx2[4]
        );
      }
      const filter0_changes = {};
      if (dirty & /*$$scope*/
      32768) {
        filter0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_value && dirty & /*selectedNation*/
      1) {
        updating_value = true;
        filter0_changes.value = /*selectedNation*/
        ctx2[0];
        add_flush_callback(() => updating_value = false);
      }
      filter0.$set(filter0_changes);
      const filter1_changes = {};
      if (dirty & /*$$scope*/
      32768) {
        filter1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_value_1 && dirty & /*selectedTier*/
      2) {
        updating_value_1 = true;
        filter1_changes.value = /*selectedTier*/
        ctx2[1];
        add_flush_callback(() => updating_value_1 = false);
      }
      filter1.$set(filter1_changes);
      const filter2_changes = {};
      if (dirty & /*$$scope*/
      32768) {
        filter2_changes.$$scope = { dirty, ctx: ctx2 };
      }
      if (!updating_value_2 && dirty & /*selectedType*/
      4) {
        updating_value_2 = true;
        filter2_changes.value = /*selectedType*/
        ctx2[2];
        add_flush_callback(() => updating_value_2 = false);
      }
      filter2.$set(filter2_changes);
      if (dirty & /*shipName*/
      8 && input.value !== /*shipName*/
      ctx2[3]) {
        set_input_value(
          input,
          /*shipName*/
          ctx2[3]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(filter0.$$.fragment, local);
      transition_in(filter1.$$.fragment, local);
      transition_in(filter2.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(filter0.$$.fragment, local);
      transition_out(filter1.$$.fragment, local);
      transition_out(filter2.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div5);
      }
      destroy_component(filter0);
      destroy_component(filter1);
      destroy_component(filter2);
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { ships = [] } = $$props;
  let { filteredShips = [] } = $$props;
  let nations = [...new Set(ships.map((ship) => ship.nation)).values()].sort();
  let selectedNation = "all";
  let tiers = [...new Set(ships.map((ship) => ship.tier)).values()].sort().reverse();
  let selectedTier = "all";
  let types = [...new Set(ships.map((ship) => ship.type)).values()].sort().reverse();
  let selectedType = "all";
  let shipName = "";
  let changed = false;
  function resetAllFilters() {
    $$invalidate(0, selectedNation = "all");
    $$invalidate(1, selectedTier = "all");
    $$invalidate(2, selectedType = "all");
    $$invalidate(3, shipName = "");
  }
  resetAllFilters();
  function filter0_value_binding(value) {
    selectedNation = value;
    $$invalidate(0, selectedNation);
  }
  function filter1_value_binding(value) {
    selectedTier = value;
    $$invalidate(1, selectedTier);
  }
  function filter2_value_binding(value) {
    selectedType = value;
    $$invalidate(2, selectedType);
  }
  function input_input_handler() {
    shipName = this.value;
    $$invalidate(3, shipName);
  }
  $$self.$$set = ($$props2) => {
    if ("ships" in $$props2)
      $$invalidate(10, ships = $$props2.ships);
    if ("filteredShips" in $$props2)
      $$invalidate(9, filteredShips = $$props2.filteredShips);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*ships, shipName, selectedNation, selectedTier, selectedType*/
    1039) {
      {
        $$invalidate(9, filteredShips = ships.filter((ship) => shipName ? ship.name.toLowerCase().includes(shipName.toLowerCase()) : true).filter((ship) => selectedNation === "all" || ship.nation === selectedNation).filter((ship) => selectedTier === "all" || ship.tier === selectedTier).filter((ship) => selectedType === "all" || ship.type === selectedType));
        $$invalidate(4, changed = selectedNation !== "all" || selectedTier !== "all" || selectedType !== "all" || shipName !== "");
      }
    }
  };
  return [
    selectedNation,
    selectedTier,
    selectedType,
    shipName,
    changed,
    nations,
    tiers,
    types,
    resetAllFilters,
    filteredShips,
    ships,
    filter0_value_binding,
    filter1_value_binding,
    filter2_value_binding,
    input_input_handler
  ];
}
class ShipFilters extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { ships: 10, filteredShips: 9 });
  }
}
function cubicOut(t) {
  const f = t - 1;
  return f * f * f + 1;
}
function slide(node, { delay = 0, duration = 400, easing = cubicOut, axis = "y" } = {}) {
  const style = getComputedStyle(node);
  const opacity = +style.opacity;
  const primary_property = axis === "y" ? "height" : "width";
  const primary_property_value = parseFloat(style[primary_property]);
  const secondary_properties = axis === "y" ? ["top", "bottom"] : ["left", "right"];
  const capitalized_secondary_properties = secondary_properties.map(
    (e) => `${e[0].toUpperCase()}${e.slice(1)}`
  );
  const padding_start_value = parseFloat(style[`padding${capitalized_secondary_properties[0]}`]);
  const padding_end_value = parseFloat(style[`padding${capitalized_secondary_properties[1]}`]);
  const margin_start_value = parseFloat(style[`margin${capitalized_secondary_properties[0]}`]);
  const margin_end_value = parseFloat(style[`margin${capitalized_secondary_properties[1]}`]);
  const border_width_start_value = parseFloat(
    style[`border${capitalized_secondary_properties[0]}Width`]
  );
  const border_width_end_value = parseFloat(
    style[`border${capitalized_secondary_properties[1]}Width`]
  );
  return {
    delay,
    duration,
    easing,
    css: (t) => `overflow: hidden;opacity: ${Math.min(t * 20, 1) * opacity};${primary_property}: ${t * primary_property_value}px;padding-${secondary_properties[0]}: ${t * padding_start_value}px;padding-${secondary_properties[1]}: ${t * padding_end_value}px;margin-${secondary_properties[0]}: ${t * margin_start_value}px;margin-${secondary_properties[1]}: ${t * margin_end_value}px;border-${secondary_properties[0]}-width: ${t * border_width_start_value}px;border-${secondary_properties[1]}-width: ${t * border_width_end_value}px;`
  };
}
function scale(node, { delay = 0, duration = 400, easing = cubicOut, start = 0, opacity = 0 } = {}) {
  const style = getComputedStyle(node);
  const target_opacity = +style.opacity;
  const transform = style.transform === "none" ? "" : style.transform;
  const sd = 1 - start;
  const od = target_opacity * (1 - opacity);
  return {
    delay,
    duration,
    easing,
    css: (_t, u) => `
			transform: ${transform} scale(${1 - sd * u});
			opacity: ${target_opacity - od * u}
		`
  };
}
class PubSubHandler extends EventTarget {
  constructor() {
    super(...arguments);
    __publicField(this, "fn", (_target, contentType, message) => {
      if (contentType !== "application/json") {
        return;
      }
      const data = JSON.parse(atob(message));
      this.handlePubSubMessage(data);
    });
  }
  init() {
    window.Twitch.ext.listen("broadcast", this.fn);
  }
  deinit() {
    window.Twitch.ext.unlisten("broadcast", this.fn);
  }
  handlePubSubMessage(message) {
    const currentVote = get_store_value(vote);
    const currentApi = get_store_value(api);
    if (!currentApi) {
      console.log("no api in handlePubSubMessage");
      return;
    }
    switch (message.type) {
      case "vote_status":
        if (currentVote && message.data.status === "closed") {
          vote.update(() => null);
          console.log(`vote ${currentVote.id} closed`);
          this.dispatchEvent(new Event("vote_closed"));
          return;
        }
        if (!currentVote && message.data.status === "open") {
          setTimeout(
            async () => {
              const newVote = await currentApi.getVote(message.data.id);
              vote.update(() => newVote);
              console.log(`vote ${newVote.id} opened`);
              this.dispatchEvent(new Event("vote_opened"));
            },
            Math.floor(Math.random() * 2001)
          );
        }
        break;
      case "vote_progress":
        if (!currentVote) {
          setTimeout(
            async () => {
              const newVote = await currentApi.getVote(message.data.id);
              vote.update(() => newVote);
              console.log(
                `vote ${newVote.id} opened (detected via vote_progress)`
              );
              this.dispatchEvent(new Event("vote_opened"));
            },
            Math.floor(Math.random() * 2001)
          );
          return;
        }
        vote.update(() => ({
          ...currentVote,
          votes: message.data.voted_ships
        }));
        this.dispatchEvent(new CustomEvent("vote_progress"));
      case "channel_update":
        this.dispatchEvent(new CustomEvent("channel_update", {
          detail: message.data
        }));
    }
  }
}
export {
  PubSubHandler as P,
  ShipFilters as S,
  scale as a,
  handle_promise as h,
  slide as s,
  update_await_block_branch as u
};
