import { S as SvelteComponent, i as init, s as safe_not_equal, V as create_slot, a as element, b as space, c as attr, t as toggle_class, d as insert, f as append, k as transition_in, g as group_outros, h as transition_out, j as check_outros, W as update_slot_base, X as get_all_dirty_from_scope, Y as get_slot_changes, m as detach, C as text, D as set_data } from "./app.js";
const get_title_slot_changes = (dirty) => ({});
const get_title_slot_context = (ctx) => ({});
function create_if_block(ctx) {
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[3].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[2],
    get_title_slot_context
  );
  const title_slot_or_fallback = title_slot || fallback_block(ctx);
  return {
    c() {
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
    },
    m(target, anchor) {
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(target, anchor);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        4)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[2],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[2]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx2[2],
              dirty,
              get_title_slot_changes
            ),
            get_title_slot_context
          );
        }
      } else {
        if (title_slot_or_fallback && title_slot_or_fallback.p && (!current || dirty & /*title*/
        2)) {
          title_slot_or_fallback.p(ctx2, !current ? -1 : dirty);
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      current = false;
    },
    d(detaching) {
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
    }
  };
}
function fallback_block(ctx) {
  let h2;
  let t;
  return {
    c() {
      h2 = element("h2");
      t = text(
        /*title*/
        ctx[1]
      );
      attr(h2, "class", "text-gray-200 text-xl font-medium mb-4");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      append(h2, t);
    },
    p(ctx2, dirty) {
      if (dirty & /*title*/
      2)
        set_data(
          t,
          /*title*/
          ctx2[1]
        );
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
      }
    }
  };
}
function create_fragment(ctx) {
  let div;
  let t;
  let current;
  let if_block = (
    /*title*/
    ctx[1] && create_if_block(ctx)
  );
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[2],
    null
  );
  return {
    c() {
      div = element("div");
      if (if_block)
        if_block.c();
      t = space();
      if (default_slot)
        default_slot.c();
      attr(div, "class", "text-gray-100 bg-gray-800 overflow-hidden drop-shadow-xl rounded-lg p-4 sm:p-6");
      toggle_class(
        div,
        "hover:bg-gray-700",
        /*hover*/
        ctx[0]
      );
      toggle_class(
        div,
        "transition",
        /*hover*/
        ctx[0]
      );
      toggle_class(
        div,
        "hover:cursor-pointer",
        /*hover*/
        ctx[0]
      );
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (if_block)
        if_block.m(div, null);
      append(div, t);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if (
        /*title*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*title*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(div, t);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[2],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[2]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[2],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*hover*/
      1) {
        toggle_class(
          div,
          "hover:bg-gray-700",
          /*hover*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*hover*/
      1) {
        toggle_class(
          div,
          "transition",
          /*hover*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*hover*/
      1) {
        toggle_class(
          div,
          "hover:cursor-pointer",
          /*hover*/
          ctx2[0]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (if_block)
        if_block.d();
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { hover = false } = $$props;
  let { title = void 0 } = $$props;
  $$self.$$set = ($$props2) => {
    if ("hover" in $$props2)
      $$invalidate(0, hover = $$props2.hover);
    if ("title" in $$props2)
      $$invalidate(1, title = $$props2.title);
    if ("$$scope" in $$props2)
      $$invalidate(2, $$scope = $$props2.$$scope);
  };
  return [hover, title, $$scope, slots];
}
class Box extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, { hover: 0, title: 1 });
  }
}
export {
  Box as B
};
