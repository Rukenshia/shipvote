import { S as SvelteComponent, i as init, s as safe_not_equal, C as text, d as insert, F as noop, m as detach } from "./app.js";
function create_fragment(ctx) {
  let t0;
  let t1_value = "3.0.1";
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Shipvote Extension v");
      t1 = text(t1_value);
      t2 = text(" · made by Rukenshia\n(Discord: Rukenshia#4396)");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
class CreatorBanner extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment, safe_not_equal, {});
  }
}
export {
  CreatorBanner as C
};
