import { S as SvelteComponent, i as init, s as safe_not_equal, e as ensure_array_like, a as element, b as space, c as attr, d as insert, f as append, F as noop, m as detach, n as destroy_each, t as toggle_class, l as listen, C as text, H as empty, D as set_data, g as transition_in, j as transition_out, o as component_subscribe, J as vote, p as api, N as createEventDispatcher, L as writable, M as set_store_value, h as group_outros, k as check_outros, v as create_component, w as mount_component, B as destroy_component, q as binding_callbacks, u as bind, x as add_flush_callback, E as src_url_equal, U as create_slot, V as update_slot_base, W as get_all_dirty_from_scope, X as get_slot_changes, K as warships, O as subscribe, y as add_render_callback, Y as create_bidirectional_transition, Z as svg_element, z as create_in_transition, A as create_out_transition, I as onMount } from "./app.js";
import { C as CreatorBanner } from "./CreatorBanner.js";
import { h as handle_promise, u as update_await_block_branch, S as ShipFilters, s as slide, r as registerPubSubHandler } from "./pubsub.js";
import { B as Box } from "./Box.js";
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[3] = list[i];
  return child_ctx;
}
function create_else_block$3(ctx) {
  let t0_value = (
    /*option*/
    ctx[3] + ""
  );
  let t0;
  let t1;
  let if_block_anchor;
  let if_block = (
    /*option*/
    ctx[3] > 1 && create_if_block_1$3()
  );
  return {
    c() {
      t0 = text(t0_value);
      t1 = text("\n\n              minute");
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*options*/
      1 && t0_value !== (t0_value = /*option*/
      ctx2[3] + ""))
        set_data(t0, t0_value);
      if (
        /*option*/
        ctx2[3] > 1
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_1$3();
          if_block.c();
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
    }
  };
}
function create_if_block$6(ctx) {
  let t;
  return {
    c() {
      t = text("None");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1$3(ctx) {
  let t;
  return {
    c() {
      t = text("s");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$3(ctx) {
  let label;
  let input;
  let input_checked_value;
  let input_value_value;
  let input_aria_labelledby_value;
  let t0;
  let p;
  let p_id_value;
  let t1;
  let mounted;
  let dispose;
  function click_handler() {
    return (
      /*click_handler*/
      ctx[2](
        /*option*/
        ctx[3]
      )
    );
  }
  function select_block_type(ctx2, dirty) {
    if (!/*option*/
    ctx2[3])
      return create_if_block$6;
    return create_else_block$3;
  }
  let current_block_type = select_block_type(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      label = element("label");
      input = element("input");
      t0 = space();
      p = element("p");
      if_block.c();
      t1 = space();
      input.checked = input_checked_value = /*selected*/
      ctx[1] === /*option*/
      ctx[3];
      attr(input, "type", "radio");
      attr(input, "name", "duration");
      input.value = input_value_value = /*option*/
      ctx[3];
      attr(input, "class", "sr-only");
      attr(input, "aria-labelledby", input_aria_labelledby_value = "duration-" + /*option*/
      ctx[3] + "-label");
      attr(p, "id", p_id_value = "duration-" + /*option*/
      ctx[3] + "-label");
      attr(label, "class", "border rounded-md py-3 px-3 flex items-center justify-center text-sm font-medium sm:flex-1 cursor-pointer transition focus:outline-none border-zinc-400 text-gray-50 hover:text-gray-900 hover:bg-zinc-200 active:ring-2 active:ring-offset-2 active:ring-gray-500");
      toggle_class(
        label,
        "bg-gray-500",
        /*selected*/
        ctx[1] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "border-transparent",
        /*selected*/
        ctx[1] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "text-white",
        /*selected*/
        ctx[1] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "hover:text-white",
        /*selected*/
        ctx[1] === /*option*/
        ctx[3]
      );
      toggle_class(
        label,
        "hover:bg-gray-400",
        /*selected*/
        ctx[1] === /*option*/
        ctx[3]
      );
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, input);
      append(label, t0);
      append(label, p);
      if_block.m(p, null);
      append(label, t1);
      if (!mounted) {
        dispose = listen(input, "click", click_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*selected, options*/
      3 && input_checked_value !== (input_checked_value = /*selected*/
      ctx[1] === /*option*/
      ctx[3])) {
        input.checked = input_checked_value;
      }
      if (dirty & /*options*/
      1 && input_value_value !== (input_value_value = /*option*/
      ctx[3])) {
        input.value = input_value_value;
      }
      if (dirty & /*options*/
      1 && input_aria_labelledby_value !== (input_aria_labelledby_value = "duration-" + /*option*/
      ctx[3] + "-label")) {
        attr(input, "aria-labelledby", input_aria_labelledby_value);
      }
      if (current_block_type === (current_block_type = select_block_type(ctx)) && if_block) {
        if_block.p(ctx, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx);
        if (if_block) {
          if_block.c();
          if_block.m(p, null);
        }
      }
      if (dirty & /*options*/
      1 && p_id_value !== (p_id_value = "duration-" + /*option*/
      ctx[3] + "-label")) {
        attr(p, "id", p_id_value);
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "bg-gray-500",
          /*selected*/
          ctx[1] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "border-transparent",
          /*selected*/
          ctx[1] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "text-white",
          /*selected*/
          ctx[1] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "hover:text-white",
          /*selected*/
          ctx[1] === /*option*/
          ctx[3]
        );
      }
      if (dirty & /*selected, options*/
      3) {
        toggle_class(
          label,
          "hover:bg-gray-400",
          /*selected*/
          ctx[1] === /*option*/
          ctx[3]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(label);
      }
      if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$7(ctx) {
  let div2;
  let div0;
  let t1;
  let fieldset;
  let legend;
  let t3;
  let div1;
  let each_value = ensure_array_like(
    /*options*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
  }
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      div0.innerHTML = `<h2 class="text-sm font-medium text-gray-300">Time Limit</h2>`;
      t1 = space();
      fieldset = element("fieldset");
      legend = element("legend");
      legend.textContent = "Choose a memory option";
      t3 = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div0, "class", "flex items-center justify-between");
      attr(legend, "class", "sr-only");
      attr(div1, "class", "grid grid-cols-3 gap-3 sm:grid-cols-6");
      attr(fieldset, "class", "mt-2");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div2, t1);
      append(div2, fieldset);
      append(fieldset, legend);
      append(fieldset, t3);
      append(fieldset, div1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*selected, options*/
      3) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$3(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$3(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div1, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$7($$self, $$props, $$invalidate) {
  let { options = [null, 1, 5, 15, 20, 30] } = $$props;
  let selected = null;
  const click_handler = (option) => $$invalidate(1, selected = option);
  $$self.$$set = ($$props2) => {
    if ("options" in $$props2)
      $$invalidate(0, options = $$props2.options);
  };
  return [options, selected, click_handler];
}
class Duration extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, { options: 0 });
  }
}
function get_each_context$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[23] = list[i];
  return child_ctx;
}
function create_catch_block_1(ctx) {
  let t;
  return {
    c() {
      t = text("could not load channel information");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_then_block$2(ctx) {
  let await_block_anchor;
  let promise;
  let current;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block_1,
    then: create_then_block_1,
    catch: create_catch_block$2,
    value: 22,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$vote*/
  ctx[1], info);
  return {
    c() {
      await_block_anchor = empty();
      info.block.c();
    },
    m(target, anchor) {
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$vote*/
      2 && promise !== (promise = /*$vote*/
      ctx[1]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(await_block_anchor);
      }
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function create_catch_block$2(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_then_block_1(ctx) {
  let current_block_type_index;
  let if_block;
  let if_block_anchor;
  let current;
  const if_block_creators = [create_if_block$5, create_else_block$2];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*vote*/
      ctx2[22]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if_blocks[current_block_type_index].m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(if_block_anchor.parentNode, if_block_anchor);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if_blocks[current_block_type_index].d(detaching);
    }
  };
}
function create_else_block$2(ctx) {
  let box0;
  let t0;
  let box1;
  let t1;
  let div0;
  let t2;
  let button;
  let t3;
  let button_class_value;
  let button_disabled_value;
  let t4;
  let div1;
  let current;
  let mounted;
  let dispose;
  box0 = new Box({
    props: {
      $$slots: { default: [create_default_slot_3$1] },
      $$scope: { ctx }
    }
  });
  box1 = new Box({
    props: {
      $$slots: { default: [create_default_slot_2$1] },
      $$scope: { ctx }
    }
  });
  let if_block = (
    /*filteredShips*/
    ctx[0].length && create_if_block_2$2(ctx)
  );
  let each_value = ensure_array_like(
    /*filteredShips*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      create_component(box0.$$.fragment);
      t0 = space();
      create_component(box1.$$.fragment);
      t1 = space();
      div0 = element("div");
      if (if_block)
        if_block.c();
      t2 = space();
      button = element("button");
      t3 = text("Remove all");
      t4 = space();
      div1 = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(button, "class", button_class_value = "text-gray-300 px-4 py-2 rounded-md bg-zinc-700 " + /*$selectedShips*/
      (ctx[2].length ? "hover:text-gray-100 hover:bg-cyan-500" : "") + " transition font-medium");
      button.disabled = button_disabled_value = !/*$selectedShips*/
      ctx[2].length;
      toggle_class(button, "text-gray-500", !/*$selectedShips*/
      ctx[2].length);
      toggle_class(button, "bg-transparent", !/*$selectedShips*/
      ctx[2].length);
      attr(div0, "class", "sticky bottom-0 flex justify-between");
      attr(div1, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      mount_component(box0, target, anchor);
      insert(target, t0, anchor);
      mount_component(box1, target, anchor);
      insert(target, t1, anchor);
      insert(target, div0, anchor);
      if (if_block)
        if_block.m(div0, null);
      append(div0, t2);
      append(div0, button);
      append(button, t3);
      insert(target, t4, anchor);
      insert(target, div1, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div1, null);
        }
      }
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_3*/
          ctx[17]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      const box0_changes = {};
      if (dirty & /*$$scope, $selectedShips*/
      67108868) {
        box0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box0.$set(box0_changes);
      const box1_changes = {};
      if (dirty & /*$$scope, $channel, filteredShips*/
      67108873) {
        box1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box1.$set(box1_changes);
      if (
        /*filteredShips*/
        ctx2[0].length
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
        } else {
          if_block = create_if_block_2$2(ctx2);
          if_block.c();
          if_block.m(div0, t2);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_class_value !== (button_class_value = "text-gray-300 px-4 py-2 rounded-md bg-zinc-700 " + /*$selectedShips*/
      (ctx2[2].length ? "hover:text-gray-100 hover:bg-cyan-500" : "") + " transition font-medium")) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_disabled_value !== (button_disabled_value = !/*$selectedShips*/
      ctx2[2].length)) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "text-gray-500", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "bg-transparent", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (dirty & /*removeShip, filteredShips, $selectedShips, addShip*/
      389) {
        each_value = ensure_array_like(
          /*filteredShips*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$2(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(div1, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(box0.$$.fragment, local);
      transition_in(box1.$$.fragment, local);
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(box0.$$.fragment, local);
      transition_out(box1.$$.fragment, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(div0);
        detach(t4);
        detach(div1);
      }
      destroy_component(box0, detaching);
      destroy_component(box1, detaching);
      if (if_block)
        if_block.d();
      destroy_each(each_blocks, detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_if_block$5(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope*/
      67108864) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_if_block_4(ctx) {
  let t;
  return {
    c() {
      t = text("s");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_3$1(ctx) {
  let h2;
  let t1;
  let div3;
  let div0;
  let duration;
  let t2;
  let div2;
  let t4;
  let div4;
  let button;
  let t5;
  let t6_value = (
    /*$selectedShips*/
    ctx[2].length + ""
  );
  let t6;
  let t7;
  let button_class_value;
  let button_disabled_value;
  let current;
  let mounted;
  let dispose;
  duration = new Duration({});
  let if_block = (
    /*$selectedShips*/
    ctx[2].length !== 1 && create_if_block_4()
  );
  return {
    c() {
      h2 = element("h2");
      h2.textContent = "New Vote";
      t1 = space();
      div3 = element("div");
      div0 = element("div");
      create_component(duration.$$.fragment);
      t2 = space();
      div2 = element("div");
      div2.innerHTML = `<div>Coming (back) soon</div>`;
      t4 = space();
      div4 = element("div");
      button = element("button");
      t5 = text("Start vote with ");
      t6 = text(t6_value);
      t7 = text(" ship");
      if (if_block)
        if_block.c();
      attr(h2, "class", "text-gray-200 text-xl font-medium");
      attr(div0, "class", "p-4");
      attr(div2, "class", "absolute left-0 top-0 w-full h-full bg-gray-800/90 rounded flex items-center justify-center");
      attr(div3, "class", "relative");
      attr(button, "class", button_class_value = "px-8 py-4 rounded-md " + /*$selectedShips*/
      (ctx[2].length ? "hover:bg-cyan-400 active:bg-cyan-600 active:ring-2 active:ring-cyan-400" : "text-cyan-200/50") + " transition font-medium");
      button.disabled = button_disabled_value = !/*$selectedShips*/
      ctx[2].length;
      toggle_class(
        button,
        "text-gray-800",
        /*$selectedShips*/
        ctx[2].length
      );
      toggle_class(button, "bg-cyan-900", !/*$selectedShips*/
      ctx[2].length);
      toggle_class(
        button,
        "bg-cyan-500",
        /*$selectedShips*/
        ctx[2].length
      );
      attr(div4, "class", "mt-8 flex justify-around items-center");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      insert(target, t1, anchor);
      insert(target, div3, anchor);
      append(div3, div0);
      mount_component(duration, div0, null);
      append(div3, t2);
      append(div3, div2);
      insert(target, t4, anchor);
      insert(target, div4, anchor);
      append(div4, button);
      append(button, t5);
      append(button, t6);
      append(button, t7);
      if (if_block)
        if_block.m(button, null);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_1*/
          ctx[14]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if ((!current || dirty & /*$selectedShips*/
      4) && t6_value !== (t6_value = /*$selectedShips*/
      ctx2[2].length + ""))
        set_data(t6, t6_value);
      if (
        /*$selectedShips*/
        ctx2[2].length !== 1
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block_4();
          if_block.c();
          if_block.m(button, null);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_class_value !== (button_class_value = "px-8 py-4 rounded-md " + /*$selectedShips*/
      (ctx2[2].length ? "hover:bg-cyan-400 active:bg-cyan-600 active:ring-2 active:ring-cyan-400" : "text-cyan-200/50") + " transition font-medium")) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*$selectedShips*/
      4 && button_disabled_value !== (button_disabled_value = !/*$selectedShips*/
      ctx2[2].length)) {
        button.disabled = button_disabled_value;
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(
          button,
          "text-gray-800",
          /*$selectedShips*/
          ctx2[2].length
        );
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(button, "bg-cyan-900", !/*$selectedShips*/
        ctx2[2].length);
      }
      if (!current || dirty & /*$selectedShips, $selectedShips*/
      4) {
        toggle_class(
          button,
          "bg-cyan-500",
          /*$selectedShips*/
          ctx2[2].length
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(duration.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(duration.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t1);
        detach(div3);
        detach(t4);
        detach(div4);
      }
      destroy_component(duration);
      if (if_block)
        if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot_2$1(ctx) {
  let shipfilters;
  let updating_filteredShips;
  let current;
  function shipfilters_filteredShips_binding(value) {
    ctx[15](value);
  }
  let shipfilters_props = { ships: (
    /*channel*/
    ctx[11].ships
  ) };
  if (
    /*filteredShips*/
    ctx[0] !== void 0
  ) {
    shipfilters_props.filteredShips = /*filteredShips*/
    ctx[0];
  }
  shipfilters = new ShipFilters({ props: shipfilters_props });
  binding_callbacks.push(() => bind(shipfilters, "filteredShips", shipfilters_filteredShips_binding));
  return {
    c() {
      create_component(shipfilters.$$.fragment);
    },
    m(target, anchor) {
      mount_component(shipfilters, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const shipfilters_changes = {};
      if (dirty & /*$channel*/
      8)
        shipfilters_changes.ships = /*channel*/
        ctx2[11].ships;
      if (!updating_filteredShips && dirty & /*filteredShips*/
      1) {
        updating_filteredShips = true;
        shipfilters_changes.filteredShips = /*filteredShips*/
        ctx2[0];
        add_flush_callback(() => updating_filteredShips = false);
      }
      shipfilters.$set(shipfilters_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(shipfilters.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(shipfilters.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(shipfilters, detaching);
    }
  };
}
function create_if_block_2$2(ctx) {
  let button;
  let mounted;
  let dispose;
  function select_block_type_1(ctx2, dirty) {
    if (
      /*filteredShips*/
      ctx2[0].length === 1
    )
      return create_if_block_3;
    return create_else_block_2;
  }
  let current_block_type = select_block_type_1(ctx);
  let if_block = current_block_type(ctx);
  return {
    c() {
      button = element("button");
      if_block.c();
      attr(button, "class", "text-gray-200 px-4 py-2 rounded-md bg-cyan-800/50 hover:text-gray-100 hover:bg-cyan-700 transition font-medium");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if_block.m(button, null);
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler_2*/
          ctx[16]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (current_block_type === (current_block_type = select_block_type_1(ctx2)) && if_block) {
        if_block.p(ctx2, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx2);
        if (if_block) {
          if_block.c();
          if_block.m(button, null);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if_block.d();
      mounted = false;
      dispose();
    }
  };
}
function create_else_block_2(ctx) {
  let t0;
  let t1_value = (
    /*filteredShips*/
    ctx[0].length + ""
  );
  let t1;
  let t2;
  return {
    c() {
      t0 = text("Add ");
      t1 = text(t1_value);
      t2 = text(" Ships");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
      insert(target, t2, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*filteredShips*/
      ctx2[0].length + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
        detach(t2);
      }
    }
  };
}
function create_if_block_3(ctx) {
  let t0;
  let t1_value = (
    /*filteredShips*/
    ctx[0][0].name + ""
  );
  let t1;
  return {
    c() {
      t0 = text("Add ");
      t1 = text(t1_value);
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, t1, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*filteredShips*/
      ctx2[0][0].name + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(t1);
      }
    }
  };
}
function create_else_block_1(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_5() {
    return (
      /*click_handler_5*/
      ctx[19](
        /*ship*/
        ctx[23]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.textContent = "+";
      attr(button, "class", "bg-cyan-900 drop-shadow-sm hover:bg-cyan-700 transition font-medium py-2 px-4 rounded");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_5);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block_1$2(ctx) {
  let button;
  let mounted;
  let dispose;
  function click_handler_4() {
    return (
      /*click_handler_4*/
      ctx[18](
        /*ship*/
        ctx[23]
      )
    );
  }
  return {
    c() {
      button = element("button");
      button.textContent = "-";
      attr(button, "class", "bg-cyan-900 drop-shadow-sm hover:bg-cyan-700 transition font-medium py-2 px-4 rounded");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (!mounted) {
        dispose = listen(button, "click", click_handler_4);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot_1$1(ctx) {
  let div;
  let img;
  let img_alt_value;
  let img_src_value;
  let t0;
  let span;
  let t1_value = (
    /*ship*/
    ctx[23].name + ""
  );
  let t1;
  let t2;
  let show_if;
  let t3;
  function func(...args) {
    return (
      /*func*/
      ctx[12](
        /*ship*/
        ctx[23],
        ...args
      )
    );
  }
  function select_block_type_2(ctx2, dirty) {
    if (dirty & /*$selectedShips, filteredShips*/
    5)
      show_if = null;
    if (show_if == null)
      show_if = !!/*$selectedShips*/
      ctx2[2].find(func);
    if (show_if)
      return create_if_block_1$2;
    return create_else_block_1;
  }
  let current_block_type = select_block_type_2(ctx, -1);
  let if_block = current_block_type(ctx);
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span = element("span");
      t1 = text(t1_value);
      t2 = space();
      if_block.c();
      t3 = space();
      attr(img, "class", "w-16 h-10");
      attr(img, "alt", img_alt_value = /*ship*/
      ctx[23].name);
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[23].image))
        attr(img, "src", img_src_value);
      attr(span, "class", "text-lg flex-grow");
      attr(div, "class", "flex items-center gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span);
      append(span, t1);
      append(div, t2);
      if_block.m(div, null);
      insert(target, t3, anchor);
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*filteredShips*/
      1 && img_alt_value !== (img_alt_value = /*ship*/
      ctx[23].name)) {
        attr(img, "alt", img_alt_value);
      }
      if (dirty & /*filteredShips*/
      1 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx[23].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*filteredShips*/
      1 && t1_value !== (t1_value = /*ship*/
      ctx[23].name + ""))
        set_data(t1, t1_value);
      if (current_block_type === (current_block_type = select_block_type_2(ctx, dirty)) && if_block) {
        if_block.p(ctx, dirty);
      } else {
        if_block.d(1);
        if_block = current_block_type(ctx);
        if (if_block) {
          if_block.c();
          if_block.m(div, null);
        }
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
        detach(t3);
      }
      if_block.d();
    }
  };
}
function create_each_block$2(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const box_changes = {};
      if (dirty & /*$$scope, filteredShips, $selectedShips*/
      67108869) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function create_default_slot$3(ctx) {
  let t;
  return {
    c() {
      t = text("There is already an open vote");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_pending_block_1(ctx) {
  return {
    c: noop,
    m: noop,
    p: noop,
    i: noop,
    o: noop,
    d: noop
  };
}
function create_pending_block$2(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.textContent = "loading...";
      attr(div, "class", "text-gray-500");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_fragment$6(ctx) {
  let div1;
  let div0;
  let a;
  let t1;
  let promise;
  let current;
  let mounted;
  let dispose;
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: true,
    pending: create_pending_block$2,
    then: create_then_block$2,
    catch: create_catch_block_1,
    value: 11,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$channel*/
  ctx[3], info);
  return {
    c() {
      div1 = element("div");
      div0 = element("div");
      a = element("a");
      a.innerHTML = `<svg class="w-4 h-4 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
      Go back`;
      t1 = space();
      info.block.c();
      attr(a, "class", "text-gray-300 hover:bg-gray-800 rounded hover:drop-shadow-xl transition font-medium p-4 inline-flex items-center gap-2");
      attr(a, "href", "#live_config");
      attr(div1, "class", "flex flex-col gap-8");
    },
    m(target, anchor) {
      insert(target, div1, anchor);
      append(div1, div0);
      append(div0, a);
      append(div1, t1);
      info.block.m(div1, info.anchor = null);
      info.mount = () => div1;
      info.anchor = null;
      current = true;
      if (!mounted) {
        dispose = listen(
          a,
          "click",
          /*click_handler*/
          ctx[13]
        );
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      info.ctx = ctx;
      if (dirty & /*$channel*/
      8 && promise !== (promise = /*$channel*/
      ctx[3]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(info.block);
      current = true;
    },
    o(local) {
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div1);
      }
      info.block.d();
      info.token = null;
      info = null;
      mounted = false;
      dispose();
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let $vote;
  let $selectedShips;
  let $api;
  let $channel;
  component_subscribe($$self, vote, ($$value) => $$invalidate(1, $vote = $$value));
  component_subscribe($$self, api, ($$value) => $$invalidate(20, $api = $$value));
  const dispatch = createEventDispatcher();
  const channel = writable();
  component_subscribe($$self, channel, (value) => $$invalidate(3, $channel = value));
  api.subscribe(($api2) => {
    if (!$api2) {
      return;
    }
    channel.set($api2.broadcasterGetChannel());
  });
  let selectedShips = writable([]);
  component_subscribe($$self, selectedShips, (value) => $$invalidate(2, $selectedShips = value));
  let filteredShips = [];
  function addShips(ships) {
    set_store_value(selectedShips, $selectedShips = [...$selectedShips, ...ships.filter((s) => !$selectedShips.includes(s))], $selectedShips);
  }
  function addShip(ship) {
    if ($selectedShips.includes(ship)) {
      return;
    }
    set_store_value(selectedShips, $selectedShips = [...$selectedShips, ship], $selectedShips);
  }
  function removeShip(ship) {
    set_store_value(selectedShips, $selectedShips = $selectedShips.filter((s) => s !== ship), $selectedShips);
  }
  function removeAllShips() {
    set_store_value(selectedShips, $selectedShips = [], $selectedShips);
  }
  async function openVote() {
    set_store_value(vote, $vote = await $api.openVote($selectedShips.map((s) => s.id)), $vote);
    dispatch("vote_opened");
  }
  const func = (ship, s) => s.id === ship.id;
  const click_handler = () => dispatch("back");
  const click_handler_1 = () => openVote();
  function shipfilters_filteredShips_binding(value) {
    filteredShips = value;
    $$invalidate(0, filteredShips);
  }
  const click_handler_2 = () => addShips(filteredShips);
  const click_handler_3 = () => removeAllShips();
  const click_handler_4 = (ship) => removeShip(ship);
  const click_handler_5 = (ship) => addShip(ship);
  return [
    filteredShips,
    $vote,
    $selectedShips,
    $channel,
    dispatch,
    selectedShips,
    addShips,
    addShip,
    removeShip,
    removeAllShips,
    openVote,
    channel,
    func,
    click_handler,
    click_handler_1,
    shipfilters_filteredShips_binding,
    click_handler_2,
    click_handler_3,
    click_handler_4,
    click_handler_5
  ];
}
class NewVote extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, {});
  }
}
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  child_ctx[7] = i;
  return child_ctx;
}
const get_title_slot_changes$1 = (dirty) => ({});
const get_title_slot_context$1 = (ctx) => ({});
function fallback_block$1(ctx) {
  let t;
  return {
    c() {
      t = text("Results");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_catch_block$1(ctx) {
  return { c: noop, m: noop, p: noop, d: noop };
}
function create_then_block$1(ctx) {
  let t;
  let each_1_anchor;
  let if_block = (
    /*ships*/
    ctx[1].length === 0 && create_if_block$4()
  );
  let each_value = ensure_array_like(
    /*ships*/
    ctx[1]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  return {
    c() {
      if (if_block)
        if_block.c();
      t = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, t, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
    },
    p(ctx2, dirty) {
      if (
        /*ships*/
        ctx2[1].length === 0
      ) {
        if (if_block)
          ;
        else {
          if_block = create_if_block$4();
          if_block.c();
          if_block.m(t.parentNode, t);
        }
      } else if (if_block) {
        if_block.d(1);
        if_block = null;
      }
      if (dirty & /*$ships*/
      1) {
        each_value = ensure_array_like(
          /*ships*/
          ctx2[1]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(t);
        detach(each_1_anchor);
      }
      if (if_block)
        if_block.d(detaching);
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_if_block$4(ctx) {
  let li;
  return {
    c() {
      li = element("li");
      li.innerHTML = `<div class="h-10 text-center flex items-center">No voted ships</div>`;
      attr(li, "class", "bg-gray-700 hover:bg-gray-600 transition drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-4");
    },
    m(target, anchor) {
      insert(target, li, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_each_block$1(ctx) {
  let li;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t3;
  let span1;
  let t4_value = (
    /*ship*/
    ctx[5].name + ""
  );
  let t4;
  let t5;
  let span2;
  let t6_value = (
    /*ship*/
    ctx[5].votes + ""
  );
  let t6;
  let t7;
  return {
    c() {
      li = element("li");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = `${/*rank*/
      ctx[7] + 1}.`;
      t3 = space();
      span1 = element("span");
      t4 = text(t4_value);
      t5 = space();
      span2 = element("span");
      t6 = text(t6_value);
      t7 = space();
      attr(img, "alt", "ship");
      attr(img, "class", "h-10 w-16");
      if (!src_url_equal(img.src, img_src_value = /*ship*/
      ctx[5].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-lg font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-lg");
      attr(span2, "class", "pr-4 font-medium");
      attr(li, "class", "bg-gray-700 hover:bg-gray-600 transition drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-4");
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, img);
      append(li, t0);
      append(li, span0);
      append(li, t3);
      append(li, span1);
      append(span1, t4);
      append(li, t5);
      append(li, span2);
      append(span2, t6);
      append(li, t7);
    },
    p(ctx2, dirty) {
      if (dirty & /*$ships*/
      1 && !src_url_equal(img.src, img_src_value = /*ship*/
      ctx2[5].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$ships*/
      1 && t4_value !== (t4_value = /*ship*/
      ctx2[5].name + ""))
        set_data(t4, t4_value);
      if (dirty & /*$ships*/
      1 && t6_value !== (t6_value = /*ship*/
      ctx2[5].votes + ""))
        set_data(t6, t6_value);
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_pending_block$1(ctx) {
  let li;
  return {
    c() {
      li = element("li");
      li.innerHTML = `<div class="h-10"></div>`;
      attr(li, "class", "bg-gray-700 hover:bg-gray-600 transition drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-4");
    },
    m(target, anchor) {
      insert(target, li, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(li);
      }
    }
  };
}
function create_fragment$5(ctx) {
  let h2;
  let t;
  let ul;
  let promise;
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[4].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[3],
    get_title_slot_context$1
  );
  const title_slot_or_fallback = title_slot || fallback_block$1();
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: false,
    pending: create_pending_block$1,
    then: create_then_block$1,
    catch: create_catch_block$1,
    value: 1
  };
  handle_promise(promise = /*$ships*/
  ctx[0], info);
  return {
    c() {
      h2 = element("h2");
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
      t = space();
      ul = element("ul");
      info.block.c();
      attr(h2, "class", "text-xl mt-2");
      attr(ul, "class", "px-4");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(h2, null);
      }
      insert(target, t, anchor);
      insert(target, ul, anchor);
      info.block.m(ul, info.anchor = null);
      info.mount = () => ul;
      info.anchor = null;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        8)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx,
            /*$$scope*/
            ctx[3],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[3]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx[3],
              dirty,
              get_title_slot_changes$1
            ),
            get_title_slot_context$1
          );
        }
      }
      info.ctx = ctx;
      if (dirty & /*$ships*/
      1 && promise !== (promise = /*$ships*/
      ctx[0]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t);
        detach(ul);
      }
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
      info.block.d();
      info.token = null;
      info = null;
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let $ships;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { votes } = $$props;
  const ships = writable([]);
  component_subscribe($$self, ships, (value) => $$invalidate(0, $ships = value));
  $$self.$$set = ($$props2) => {
    if ("votes" in $$props2)
      $$invalidate(2, votes = $$props2.votes);
    if ("$$scope" in $$props2)
      $$invalidate(3, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*votes*/
    4) {
      {
        warships.subscribe(async ($warships) => {
          if (!$warships) {
            return;
          }
          const currentWarships = await $warships;
          ships.set(Object.entries(votes).map(([key, value]) => {
            return { ...currentWarships[key], votes: value };
          }).sort((a, b) => a.votes > b.votes ? -1 : a.votes === b.votes ? 0 : 1).slice(0, 4));
        });
      }
    }
  };
  return [$ships, ships, votes, $$scope, slots];
}
class VoteResults extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, { votes: 2 });
  }
}
function create_else_block$1(ctx) {
  let t;
  return {
    c() {
      t = text("closed");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_2$1(ctx) {
  let t;
  return {
    c() {
      t = text("open");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_if_block_1$1(ctx) {
  let div;
  let button;
  let t;
  let button_disabled_value;
  let mounted;
  let dispose;
  return {
    c() {
      div = element("div");
      button = element("button");
      t = text("Close vote");
      attr(button, "class", "px-8 py-4 rounded-md active:bg-cyan-600 active:ring-2 active:ring-cyan-400 transition font-medium");
      button.disabled = button_disabled_value = /*$vote*/
      ctx[0] === void 0;
      toggle_class(
        button,
        "text-gray-800",
        /*$vote*/
        ctx[0] !== void 0
      );
      toggle_class(
        button,
        "text-gray-200",
        /*$vote*/
        ctx[0] === void 0
      );
      toggle_class(
        button,
        "bg-gray-700",
        /*$vote*/
        ctx[0] === void 0
      );
      toggle_class(
        button,
        "bg-cyan-500",
        /*$vote*/
        ctx[0] !== void 0
      );
      toggle_class(
        button,
        "hover:bg-cyan-400",
        /*$vote*/
        ctx[0] !== void 0
      );
      attr(div, "class", "flex justify-around mt-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, button);
      append(button, t);
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[2]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (dirty & /*$vote*/
      1 && button_disabled_value !== (button_disabled_value = /*$vote*/
      ctx2[0] === void 0)) {
        button.disabled = button_disabled_value;
      }
      if (dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "text-gray-800",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
      if (dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "text-gray-200",
          /*$vote*/
          ctx2[0] === void 0
        );
      }
      if (dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "bg-gray-700",
          /*$vote*/
          ctx2[0] === void 0
        );
      }
      if (dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "bg-cyan-500",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
      if (dirty & /*$vote, undefined*/
      1) {
        toggle_class(
          button,
          "hover:bg-cyan-400",
          /*$vote*/
          ctx2[0] !== void 0
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_if_block$3(ctx) {
  let voteresults;
  let current;
  voteresults = new VoteResults({ props: { votes: (
    /*$vote*/
    ctx[0].votes
  ) } });
  return {
    c() {
      create_component(voteresults.$$.fragment);
    },
    m(target, anchor) {
      mount_component(voteresults, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const voteresults_changes = {};
      if (dirty & /*$vote*/
      1)
        voteresults_changes.votes = /*$vote*/
        ctx2[0].votes;
      voteresults.$set(voteresults_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(voteresults.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(voteresults.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(voteresults, detaching);
    }
  };
}
function create_default_slot$2(ctx) {
  let t0;
  let span;
  let t1;
  let t2;
  let div;
  let current;
  function select_block_type(ctx2, dirty) {
    if (
      /*$vote*/
      ctx2[0]
    )
      return create_if_block_2$1;
    return create_else_block$1;
  }
  let current_block_type = select_block_type(ctx);
  let if_block0 = current_block_type(ctx);
  let if_block1 = (
    /*$vote*/
    ctx[0] && /*$vote*/
    ctx[0].status === "open" && create_if_block_1$1(ctx)
  );
  let if_block2 = (
    /*$vote*/
    ctx[0] && /*$vote*/
    ctx[0].status === "open" && create_if_block$3(ctx)
  );
  return {
    c() {
      t0 = text("The vote is currently\n\n    ");
      span = element("span");
      if_block0.c();
      t1 = space();
      if (if_block1)
        if_block1.c();
      t2 = space();
      div = element("div");
      if (if_block2)
        if_block2.c();
      attr(span, "class", "font-medium");
    },
    m(target, anchor) {
      insert(target, t0, anchor);
      insert(target, span, anchor);
      if_block0.m(span, null);
      insert(target, t1, anchor);
      if (if_block1)
        if_block1.m(target, anchor);
      insert(target, t2, anchor);
      insert(target, div, anchor);
      if (if_block2)
        if_block2.m(div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (current_block_type !== (current_block_type = select_block_type(ctx2))) {
        if_block0.d(1);
        if_block0 = current_block_type(ctx2);
        if (if_block0) {
          if_block0.c();
          if_block0.m(span, null);
        }
      }
      if (
        /*$vote*/
        ctx2[0] && /*$vote*/
        ctx2[0].status === "open"
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block_1$1(ctx2);
          if_block1.c();
          if_block1.m(t2.parentNode, t2);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (
        /*$vote*/
        ctx2[0] && /*$vote*/
        ctx2[0].status === "open"
      ) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
          if (dirty & /*$vote*/
          1) {
            transition_in(if_block2, 1);
          }
        } else {
          if_block2 = create_if_block$3(ctx2);
          if_block2.c();
          transition_in(if_block2, 1);
          if_block2.m(div, null);
        }
      } else if (if_block2) {
        group_outros();
        transition_out(if_block2, 1, 1, () => {
          if_block2 = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block2);
      current = true;
    },
    o(local) {
      transition_out(if_block2);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t0);
        detach(span);
        detach(t1);
        detach(t2);
        detach(div);
      }
      if_block0.d();
      if (if_block1)
        if_block1.d(detaching);
      if (if_block2)
        if_block2.d();
    }
  };
}
function create_fragment$4(ctx) {
  let main;
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      main = element("main");
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      insert(target, main, anchor);
      mount_component(box, main, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const box_changes = {};
      if (dirty & /*$$scope, $vote*/
      65) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(main);
      }
      destroy_component(box);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let $vote;
  let $api;
  component_subscribe($$self, vote, ($$value) => $$invalidate(0, $vote = $$value));
  component_subscribe($$self, api, ($$value) => $$invalidate(3, $api = $$value));
  const dispatch = createEventDispatcher();
  async function closeVote() {
    await $api.closeVote($vote.id);
    dispatch("close", { id: $vote.id });
    $api.getOpenVote().then((v) => set_store_value(vote, $vote = v, $vote));
  }
  const click_handler = () => closeVote();
  return [$vote, closeVote, click_handler];
}
class VoteStatus extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {});
  }
}
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[7] = list[i];
  return child_ctx;
}
const get_title_slot_changes = (dirty) => ({});
const get_title_slot_context = (ctx) => ({});
function fallback_block(ctx) {
  let t;
  return {
    c() {
      t = text("Previous Votes");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_catch_block(ctx) {
  let t;
  return {
    c() {
      t = text("error");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_then_block(ctx) {
  let div;
  let div_transition;
  let current;
  let each_value = ensure_array_like(
    /*$voteStats*/
    ctx[2]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  return {
    c() {
      div = element("div");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
    },
    m(target, anchor) {
      insert(target, div, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(div, null);
        }
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4) {
        each_value = ensure_array_like(
          /*$voteStats*/
          ctx2[2]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(div, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i(local) {
      if (current)
        return;
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, {}, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, {}, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_each(each_blocks, detaching);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block_2(ctx) {
  let div;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t2;
  let span1;
  let t3_value = (
    /*vote*/
    ctx[7].votedShips[0].name + ""
  );
  let t3;
  let t4;
  let span2;
  let t5_value = (
    /*vote*/
    ctx[7].votedShips[0].votes + ""
  );
  let t5;
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = "1.";
      t2 = space();
      span1 = element("span");
      t3 = text(t3_value);
      t4 = space();
      span2 = element("span");
      t5 = text(t5_value);
      attr(img, "alt", "ship");
      attr(img, "class", "h-6 w-10");
      if (!src_url_equal(img.src, img_src_value = /*vote*/
      ctx[7].votedShips[0].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-lg font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-lg");
      attr(span2, "class", "text-gray-400");
      attr(div, "class", "bg-gray-700 hover:bg-gray-600 transition text-gray-200 drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span0);
      append(div, t2);
      append(div, span1);
      append(span1, t3);
      append(div, t4);
      append(div, span2);
      append(span2, t5);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && !src_url_equal(img.src, img_src_value = /*vote*/
      ctx2[7].votedShips[0].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$voteStats*/
      4 && t3_value !== (t3_value = /*vote*/
      ctx2[7].votedShips[0].name + ""))
        set_data(t3, t3_value);
      if (dirty & /*$voteStats*/
      4 && t5_value !== (t5_value = /*vote*/
      ctx2[7].votedShips[0].votes + ""))
        set_data(t5, t5_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_if_block_1(ctx) {
  let div2;
  let div0;
  let span0;
  let t1;
  let span1;
  let t2_value = (
    /*vote*/
    ctx[7].votedShips[1].name + ""
  );
  let t2;
  let t3;
  let span2;
  let t4_value = (
    /*vote*/
    ctx[7].votedShips[0].votes + ""
  );
  let t4;
  let t5;
  let div1;
  let span3;
  let t7;
  let span4;
  let t8_value = (
    /*vote*/
    ctx[7].votedShips[2].name + ""
  );
  let t8;
  return {
    c() {
      div2 = element("div");
      div0 = element("div");
      span0 = element("span");
      span0.textContent = "2.";
      t1 = space();
      span1 = element("span");
      t2 = text(t2_value);
      t3 = space();
      span2 = element("span");
      t4 = text(t4_value);
      t5 = space();
      div1 = element("div");
      span3 = element("span");
      span3.textContent = "3.";
      t7 = space();
      span4 = element("span");
      t8 = text(t8_value);
      attr(span0, "class", "text-xs font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-xs");
      attr(span2, "class", "text-gray-400");
      attr(span3, "class", "text-xs font-medium text-gray-400");
      attr(span4, "class", "text-xs");
      attr(div2, "class", "flex flex-col items-start pl-4");
    },
    m(target, anchor) {
      insert(target, div2, anchor);
      append(div2, div0);
      append(div0, span0);
      append(div0, t1);
      append(div0, span1);
      append(span1, t2);
      append(div0, t3);
      append(div0, span2);
      append(span2, t4);
      append(div2, t5);
      append(div2, div1);
      append(div1, span3);
      append(div1, t7);
      append(div1, span4);
      append(span4, t8);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && t2_value !== (t2_value = /*vote*/
      ctx2[7].votedShips[1].name + ""))
        set_data(t2, t2_value);
      if (dirty & /*$voteStats*/
      4 && t4_value !== (t4_value = /*vote*/
      ctx2[7].votedShips[0].votes + ""))
        set_data(t4, t4_value);
      if (dirty & /*$voteStats*/
      4 && t8_value !== (t8_value = /*vote*/
      ctx2[7].votedShips[2].name + ""))
        set_data(t8, t8_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div2);
      }
    }
  };
}
function create_if_block$2(ctx) {
  let div;
  let img;
  let img_src_value;
  let t0;
  let span0;
  let t2;
  let span1;
  let t3_value = (
    /*vote*/
    ctx[7].votedShips[1].name + ""
  );
  let t3;
  return {
    c() {
      div = element("div");
      img = element("img");
      t0 = space();
      span0 = element("span");
      span0.textContent = "2.";
      t2 = space();
      span1 = element("span");
      t3 = text(t3_value);
      attr(img, "alt", "ship");
      attr(img, "class", "h-4 w-8");
      if (!src_url_equal(img.src, img_src_value = /*vote*/
      ctx[7].votedShips[1].image))
        attr(img, "src", img_src_value);
      attr(span0, "class", "text-md font-medium text-gray-400");
      attr(span1, "class", "flex-grow text-md");
      attr(div, "class", "text-gray-200 drop-shadow-md rounded my-2 p-2 flex justify-around items-center gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      append(div, img);
      append(div, t0);
      append(div, span0);
      append(div, t2);
      append(div, span1);
      append(span1, t3);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && !src_url_equal(img.src, img_src_value = /*vote*/
      ctx2[7].votedShips[1].image)) {
        attr(img, "src", img_src_value);
      }
      if (dirty & /*$voteStats*/
      4 && t3_value !== (t3_value = /*vote*/
      ctx2[7].votedShips[1].name + ""))
        set_data(t3, t3_value);
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_each_block(ctx) {
  let div3;
  let h5;
  let div1;
  let div0;
  let span0;
  let t1;
  let t2_value = (
    /*vote*/
    ctx[7].id + ""
  );
  let t2;
  let t3;
  let span1;
  let t4_value = (
    /*vote*/
    ctx[7].updated_at + ""
  );
  let t4;
  let t5;
  let div2;
  let t6;
  let t7;
  let t8;
  let if_block0 = (
    /*vote*/
    ctx[7].votedShips.length > 0 && create_if_block_2(ctx)
  );
  let if_block1 = (
    /*vote*/
    ctx[7].votedShips.length > 2 && create_if_block_1(ctx)
  );
  let if_block2 = (
    /*vote*/
    ctx[7].votedShips.length === 2 && create_if_block$2(ctx)
  );
  return {
    c() {
      div3 = element("div");
      h5 = element("h5");
      div1 = element("div");
      div0 = element("div");
      span0 = element("span");
      span0.textContent = "#";
      t1 = space();
      t2 = text(t2_value);
      t3 = space();
      span1 = element("span");
      t4 = text(t4_value);
      t5 = space();
      div2 = element("div");
      if (if_block0)
        if_block0.c();
      t6 = space();
      if (if_block1)
        if_block1.c();
      t7 = space();
      if (if_block2)
        if_block2.c();
      t8 = space();
      attr(span0, "class", "text-gray-300");
      attr(div0, "class", "flex-grow");
      attr(span1, "class", "text-gray-500 text-xs");
      attr(div1, "class", "flex items-center");
      attr(h5, "class", "text-md font-medium text-gray-100");
      attr(div2, "class", "px-4 grid grid-cols-2 gap-2 items-center");
      attr(div3, "class", "p-2");
    },
    m(target, anchor) {
      insert(target, div3, anchor);
      append(div3, h5);
      append(h5, div1);
      append(div1, div0);
      append(div0, span0);
      append(div0, t1);
      append(div0, t2);
      append(div1, t3);
      append(div1, span1);
      append(span1, t4);
      append(div3, t5);
      append(div3, div2);
      if (if_block0)
        if_block0.m(div2, null);
      append(div2, t6);
      if (if_block1)
        if_block1.m(div2, null);
      append(div2, t7);
      if (if_block2)
        if_block2.m(div2, null);
      append(div3, t8);
    },
    p(ctx2, dirty) {
      if (dirty & /*$voteStats*/
      4 && t2_value !== (t2_value = /*vote*/
      ctx2[7].id + ""))
        set_data(t2, t2_value);
      if (dirty & /*$voteStats*/
      4 && t4_value !== (t4_value = /*vote*/
      ctx2[7].updated_at + ""))
        set_data(t4, t4_value);
      if (
        /*vote*/
        ctx2[7].votedShips.length > 0
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
        } else {
          if_block0 = create_if_block_2(ctx2);
          if_block0.c();
          if_block0.m(div2, t6);
        }
      } else if (if_block0) {
        if_block0.d(1);
        if_block0 = null;
      }
      if (
        /*vote*/
        ctx2[7].votedShips.length > 2
      ) {
        if (if_block1) {
          if_block1.p(ctx2, dirty);
        } else {
          if_block1 = create_if_block_1(ctx2);
          if_block1.c();
          if_block1.m(div2, t7);
        }
      } else if (if_block1) {
        if_block1.d(1);
        if_block1 = null;
      }
      if (
        /*vote*/
        ctx2[7].votedShips.length === 2
      ) {
        if (if_block2) {
          if_block2.p(ctx2, dirty);
        } else {
          if_block2 = create_if_block$2(ctx2);
          if_block2.c();
          if_block2.m(div2, null);
        }
      } else if (if_block2) {
        if_block2.d(1);
        if_block2 = null;
      }
    },
    d(detaching) {
      if (detaching) {
        detach(div3);
      }
      if (if_block0)
        if_block0.d();
      if (if_block1)
        if_block1.d();
      if (if_block2)
        if_block2.d();
    }
  };
}
function create_pending_block(ctx) {
  let t;
  return {
    c() {
      t = text("loading...");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$3(ctx) {
  let h2;
  let t;
  let await_block_anchor;
  let promise;
  let current;
  const title_slot_template = (
    /*#slots*/
    ctx[6].title
  );
  const title_slot = create_slot(
    title_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    get_title_slot_context
  );
  const title_slot_or_fallback = title_slot || fallback_block();
  let info = {
    ctx,
    current: null,
    token: null,
    hasCatch: true,
    pending: create_pending_block,
    then: create_then_block,
    catch: create_catch_block,
    blocks: [, , ,]
  };
  handle_promise(promise = /*$votes*/
  ctx[1], info);
  return {
    c() {
      h2 = element("h2");
      if (title_slot_or_fallback)
        title_slot_or_fallback.c();
      t = space();
      await_block_anchor = empty();
      info.block.c();
      attr(h2, "class", "text-xl mt-2");
    },
    m(target, anchor) {
      insert(target, h2, anchor);
      if (title_slot_or_fallback) {
        title_slot_or_fallback.m(h2, null);
      }
      insert(target, t, anchor);
      insert(target, await_block_anchor, anchor);
      info.block.m(target, info.anchor = anchor);
      info.mount = () => await_block_anchor.parentNode;
      info.anchor = await_block_anchor;
      current = true;
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (title_slot) {
        if (title_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            title_slot,
            title_slot_template,
            ctx,
            /*$$scope*/
            ctx[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[5]
            ) : get_slot_changes(
              title_slot_template,
              /*$$scope*/
              ctx[5],
              dirty,
              get_title_slot_changes
            ),
            get_title_slot_context
          );
        }
      }
      info.ctx = ctx;
      if (dirty & /*$votes*/
      2 && promise !== (promise = /*$votes*/
      ctx[1]) && handle_promise(promise, info))
        ;
      else {
        update_await_block_branch(info, ctx, dirty);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(title_slot_or_fallback, local);
      transition_in(info.block);
      current = true;
    },
    o(local) {
      transition_out(title_slot_or_fallback, local);
      for (let i = 0; i < 3; i += 1) {
        const block = info.blocks[i];
        transition_out(block);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(h2);
        detach(t);
        detach(await_block_anchor);
      }
      if (title_slot_or_fallback)
        title_slot_or_fallback.d(detaching);
      info.block.d(detaching);
      info.token = null;
      info = null;
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let $votes, $$unsubscribe_votes = noop, $$subscribe_votes = () => ($$unsubscribe_votes(), $$unsubscribe_votes = subscribe(votes, ($$value) => $$invalidate(1, $votes = $$value)), votes);
  let $warships;
  let $voteStats;
  component_subscribe($$self, warships, ($$value) => $$invalidate(4, $warships = $$value));
  $$self.$$.on_destroy.push(() => $$unsubscribe_votes());
  let { $$slots: slots = {}, $$scope } = $$props;
  let { votes } = $$props;
  $$subscribe_votes();
  const voteStats = writable([]);
  component_subscribe($$self, voteStats, (value) => $$invalidate(2, $voteStats = value));
  $$self.$$set = ($$props2) => {
    if ("votes" in $$props2)
      $$subscribe_votes($$invalidate(0, votes = $$props2.votes));
    if ("$$scope" in $$props2)
      $$invalidate(5, $$scope = $$props2.$$scope);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$warships, $votes*/
    18) {
      {
        if ($warships && $votes) {
          $warships.then(async (warships2) => {
            const votes2 = await $votes;
            return { votes: votes2, warships: warships2 };
          }).then(({ votes: votes2, warships: warships2 }) => {
            voteStats.set(votes2.map((vote2) => {
              return {
                ...vote2,
                votedShips: Object.entries(vote2.votes).map(([key, value]) => {
                  return { ...warships2[key], votes: value };
                }).sort((a, b) => a.votes > b.votes ? -1 : a.votes === b.votes ? 0 : 1).slice(0, 4)
              };
            }).sort((a, b) => a.id > b.id ? -1 : 1));
          });
        }
      }
    }
  };
  return [votes, $votes, $voteStats, voteStats, $warships, $$scope, slots];
}
class VoteHistory extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, { votes: 0 });
  }
}
function create_fragment$2(ctx) {
  let button;
  let div;
  let t;
  let svg;
  let path;
  let button_class_value;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[6].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    null
  );
  return {
    c() {
      button = element("button");
      div = element("div");
      if (default_slot)
        default_slot.c();
      t = space();
      svg = svg_element("svg");
      path = svg_element("path");
      attr(path, "stroke-linecap", "round");
      attr(path, "stroke-linejoin", "round");
      attr(path, "stroke-width", "2");
      attr(path, "d", "M17 8l4 4m0 0l-4 4m4-4H3");
      attr(svg, "class", "w-6 h-6");
      attr(svg, "fill", "none");
      attr(svg, "stroke", "currentColor");
      attr(svg, "viewBox", "0 0 24 24");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
      attr(div, "class", "flex space-around items-center gap-4");
      attr(button, "class", button_class_value = "text-gray-100 bg-gray-800 overflow-hidden drop-shadow-xl rounded-lg px-4 py-5 sm:p-6 transition " + /*disabled*/
      (ctx[2] ? (
        /*disabledClasses*/
        ctx[1]
      ) : (
        /*classes*/
        ctx[0]
      )));
      button.disabled = /*disabled*/
      ctx[2];
      toggle_class(button, "hover:cursor-pointer", !/*disabled*/
      ctx[2]);
      toggle_class(button, "hover:bg-gray-700", !/*disabled*/
      ctx[2]);
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, div);
      if (default_slot) {
        default_slot.m(div, null);
      }
      append(div, t);
      append(div, svg);
      append(svg, path);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*navigate*/
          ctx[3]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[5]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[5],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*disabled, disabledClasses, classes*/
      7 && button_class_value !== (button_class_value = "text-gray-100 bg-gray-800 overflow-hidden drop-shadow-xl rounded-lg px-4 py-5 sm:p-6 transition " + /*disabled*/
      (ctx2[2] ? (
        /*disabledClasses*/
        ctx2[1]
      ) : (
        /*classes*/
        ctx2[0]
      )))) {
        attr(button, "class", button_class_value);
      }
      if (!current || dirty & /*disabled*/
      4) {
        button.disabled = /*disabled*/
        ctx2[2];
      }
      if (!current || dirty & /*disabled, disabledClasses, classes, disabled*/
      7) {
        toggle_class(button, "hover:cursor-pointer", !/*disabled*/
        ctx2[2]);
      }
      if (!current || dirty & /*disabled, disabledClasses, classes, disabled*/
      7) {
        toggle_class(button, "hover:bg-gray-700", !/*disabled*/
        ctx2[2]);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { name } = $$props;
  let { classes } = $$props;
  let { disabledClasses = "" } = $$props;
  let { disabled = false } = $$props;
  const dispatch = createEventDispatcher();
  async function navigate() {
    dispatch("navigate", { name });
  }
  $$self.$$set = ($$props2) => {
    if ("name" in $$props2)
      $$invalidate(4, name = $$props2.name);
    if ("classes" in $$props2)
      $$invalidate(0, classes = $$props2.classes);
    if ("disabledClasses" in $$props2)
      $$invalidate(1, disabledClasses = $$props2.disabledClasses);
    if ("disabled" in $$props2)
      $$invalidate(2, disabled = $$props2.disabled);
    if ("$$scope" in $$props2)
      $$invalidate(5, $$scope = $$props2.$$scope);
  };
  return [classes, disabledClasses, disabled, navigate, name, $$scope, slots];
}
class Link extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, {
      name: 4,
      classes: 0,
      disabledClasses: 1,
      disabled: 2
    });
  }
}
function create_if_block$1(ctx) {
  let div;
  let div_intro;
  let div_outro;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[2].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  return {
    c() {
      div = element("div");
      if (default_slot)
        default_slot.c();
      attr(div, "class", "mt-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if (default_slot) {
        default_slot.m(div, null);
      }
      current = true;
    },
    p(ctx2, dirty) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (div_outro)
            div_outro.end(1);
          div_intro = create_in_transition(div, slide, {});
          div_intro.start();
        });
      }
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      if (div_intro)
        div_intro.invalidate();
      if (local) {
        div_outro = create_out_transition(div, slide, {});
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (detaching && div_outro)
        div_outro.end();
    }
  };
}
function create_default_slot$1(ctx) {
  let button;
  let svg;
  let path;
  let path_d_value;
  let t0;
  let t1;
  let t2;
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*expanded*/
    ctx[1] && create_if_block$1(ctx)
  );
  return {
    c() {
      button = element("button");
      svg = svg_element("svg");
      path = svg_element("path");
      t0 = space();
      t1 = text(
        /*title*/
        ctx[0]
      );
      t2 = space();
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
      attr(path, "stroke-linecap", "round");
      attr(path, "stroke-linejoin", "round");
      attr(path, "stroke-width", "2");
      attr(path, "d", path_d_value = /*expanded*/
      ctx[1] ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7");
      attr(svg, "class", "w-6 h-6");
      attr(svg, "fill", "none");
      attr(svg, "stroke", "currentColor");
      attr(svg, "viewBox", "0 0 24 24");
      attr(button, "class", "flex items-center gap-2 cursor-pointer");
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, svg);
      append(svg, path);
      append(button, t0);
      append(button, t1);
      insert(target, t2, anchor);
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*click_handler*/
          ctx[3]
        );
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*expanded*/
      2 && path_d_value !== (path_d_value = /*expanded*/
      ctx2[1] ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7")) {
        attr(path, "d", path_d_value);
      }
      if (!current || dirty & /*title*/
      1)
        set_data(
          t1,
          /*title*/
          ctx2[0]
        );
      if (
        /*expanded*/
        ctx2[1]
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*expanded*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
        detach(t2);
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function create_fragment$1(ctx) {
  let box;
  let current;
  box = new Box({
    props: {
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(box.$$.fragment);
    },
    m(target, anchor) {
      mount_component(box, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const box_changes = {};
      if (dirty & /*$$scope, expanded, title*/
      19) {
        box_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box.$set(box_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(box.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(box.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(box, detaching);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { title } = $$props;
  let expanded = false;
  const click_handler = () => $$invalidate(1, expanded = !expanded);
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("$$scope" in $$props2)
      $$invalidate(4, $$scope = $$props2.$$scope);
  };
  return [title, expanded, slots, click_handler, $$scope];
}
class ExpandableBox extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, { title: 0 });
  }
}
function create_else_block(ctx) {
  let div;
  let link;
  let t0;
  let votestatus;
  let t1;
  let box0;
  let t2;
  let expandablebox;
  let t3;
  let box1;
  let div_transition;
  let current;
  link = new Link({
    props: {
      name: "new_vote",
      classes: "bg-cyan-900 hover:bg-cyan-800",
      disabled: (
        /*$vote*/
        ctx[3] !== void 0
      ),
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  link.$on(
    "navigate",
    /*navigate*/
    ctx[5]
  );
  votestatus = new VoteStatus({});
  votestatus.$on(
    "close",
    /*close_handler*/
    ctx[8]
  );
  box0 = new Box({
    props: {
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  expandablebox = new ExpandableBox({
    props: {
      title: "Changelog",
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  box1 = new Box({
    props: {
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(link.$$.fragment);
      t0 = space();
      create_component(votestatus.$$.fragment);
      t1 = space();
      create_component(box0.$$.fragment);
      t2 = space();
      create_component(expandablebox.$$.fragment);
      t3 = space();
      create_component(box1.$$.fragment);
      attr(div, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(link, div, null);
      append(div, t0);
      mount_component(votestatus, div, null);
      append(div, t1);
      mount_component(box0, div, null);
      append(div, t2);
      mount_component(expandablebox, div, null);
      append(div, t3);
      mount_component(box1, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const link_changes = {};
      if (dirty & /*$vote*/
      8)
        link_changes.disabled = /*$vote*/
        ctx2[3] !== void 0;
      if (dirty & /*$$scope*/
      1024) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
      const box0_changes = {};
      if (dirty & /*$$scope*/
      1024) {
        box0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box0.$set(box0_changes);
      const expandablebox_changes = {};
      if (dirty & /*$$scope*/
      1024) {
        expandablebox_changes.$$scope = { dirty, ctx: ctx2 };
      }
      expandablebox.$set(expandablebox_changes);
      const box1_changes = {};
      if (dirty & /*$$scope*/
      1024) {
        box1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      box1.$set(box1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(link.$$.fragment, local);
      transition_in(votestatus.$$.fragment, local);
      transition_in(box0.$$.fragment, local);
      transition_in(expandablebox.$$.fragment, local);
      transition_in(box1.$$.fragment, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, { duration: 100 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(link.$$.fragment, local);
      transition_out(votestatus.$$.fragment, local);
      transition_out(box0.$$.fragment, local);
      transition_out(expandablebox.$$.fragment, local);
      transition_out(box1.$$.fragment, local);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, { duration: 100 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(link);
      destroy_component(votestatus);
      destroy_component(box0);
      destroy_component(expandablebox);
      destroy_component(box1);
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function create_if_block(ctx) {
  let newvote;
  let current;
  newvote = new NewVote({});
  newvote.$on(
    "back",
    /*back_handler*/
    ctx[6]
  );
  newvote.$on(
    "vote_opened",
    /*vote_opened_handler*/
    ctx[7]
  );
  return {
    c() {
      create_component(newvote.$$.fragment);
    },
    m(target, anchor) {
      mount_component(newvote, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(newvote.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(newvote.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(newvote, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let t;
  return {
    c() {
      t = text("New Vote");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot_2(ctx) {
  let votehistory;
  let current;
  votehistory = new VoteHistory({ props: { votes: (
    /*closedVotes*/
    ctx[4]
  ) } });
  return {
    c() {
      create_component(votehistory.$$.fragment);
    },
    m(target, anchor) {
      mount_component(votehistory, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(votehistory.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(votehistory.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(votehistory, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let div;
  return {
    c() {
      div = element("div");
      div.innerHTML = `<h3 class="font-bold text-xl">v3.0.0</h3> <span class="text-gray-400 prose">This version is a complete rewrite of the previous interface. It
            hopefully lays some groundwork for upcoming improvements. This
            version is more or less on par with the previous version
            feature-wise, although I had to remove the timer functionality for
            now.</span>`;
      attr(div, "class", "flex flex-col gap-2");
    },
    m(target, anchor) {
      insert(target, div, anchor);
    },
    p: noop,
    d(detaching) {
      if (detaching) {
        detach(div);
      }
    }
  };
}
function create_default_slot(ctx) {
  let creatorbanner;
  let current;
  creatorbanner = new CreatorBanner({});
  return {
    c() {
      create_component(creatorbanner.$$.fragment);
    },
    m(target, anchor) {
      mount_component(creatorbanner, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(creatorbanner.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(creatorbanner.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(creatorbanner, detaching);
    }
  };
}
function create_fragment(ctx) {
  let div;
  let current_block_type_index;
  let if_block;
  let div_transition;
  let current;
  const if_block_creators = [create_if_block, create_else_block];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*showNewVote*/
      ctx2[1]
    )
      return 0;
    return 1;
  }
  current_block_type_index = select_block_type(ctx);
  if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  return {
    c() {
      div = element("div");
      if_block.c();
      attr(div, "class", "flex flex-col gap-4");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      if_blocks[current_block_type_index].m(div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if_blocks[current_block_type_index].p(ctx2, dirty);
      } else {
        group_outros();
        transition_out(if_blocks[previous_block_index], 1, 1, () => {
          if_blocks[previous_block_index] = null;
        });
        check_outros();
        if_block = if_blocks[current_block_type_index];
        if (!if_block) {
          if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
          if_block.c();
        } else {
          if_block.p(ctx2, dirty);
        }
        transition_in(if_block, 1);
        if_block.m(div, null);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div_transition)
            div_transition = create_bidirectional_transition(div, slide, { duration: 300 }, true);
          div_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(if_block);
      if (local) {
        if (!div_transition)
          div_transition = create_bidirectional_transition(div, slide, { duration: 300 }, false);
        div_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      if_blocks[current_block_type_index].d();
      if (detaching && div_transition)
        div_transition.end();
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $api;
  let $closedVotes;
  let $vote;
  component_subscribe($$self, api, ($$value) => $$invalidate(0, $api = $$value));
  component_subscribe($$self, vote, ($$value) => $$invalidate(3, $vote = $$value));
  let showNewVote = false;
  onMount(() => {
    registerPubSubHandler();
    return () => {
    };
  });
  const closedVotes = writable(new Promise(() => {
  }));
  component_subscribe($$self, closedVotes, (value) => $$invalidate(2, $closedVotes = value));
  function navigate(e) {
    e.preventDefault();
    if (e.detail.name === "new_vote") {
      $$invalidate(1, showNewVote = true);
    }
  }
  const back_handler = () => $$invalidate(1, showNewVote = false);
  const vote_opened_handler = () => $$invalidate(1, showNewVote = false);
  const close_handler = async () => set_store_value(closedVotes, $closedVotes = await $api.getClosedVotes(), $closedVotes);
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$api*/
    1) {
      if ($api) {
        $api.getOpenVote().then((v) => set_store_value(vote, $vote = v, $vote));
        set_store_value(closedVotes, $closedVotes = $api.getClosedVotes(), $closedVotes);
      }
    }
  };
  return [
    $api,
    showNewVote,
    $closedVotes,
    $vote,
    closedVotes,
    navigate,
    back_handler,
    vote_opened_handler,
    close_handler
  ];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
new App({
  target: document.getElementById("app")
});
